!function(){"use strict";
/**
   * @license
   * Copyright 2019 Google LLC
   * SPDX-License-Identifier: BSD-3-Clause
   */const e=globalThis,t=e.ShadowRoot&&(void 0===e.ShadyCSS||e.ShadyCSS.nativeShadow)&&"adoptedStyleSheets"in Document.prototype&&"replace"in CSSStyleSheet.prototype,i=Symbol(),o=new WeakMap;let r=class{constructor(e,t,o){if(this._$cssResult$=!0,o!==i)throw Error("CSSResult is not constructable. Use `unsafeCSS` or `css` instead.");this.cssText=e,this.t=t}get styleSheet(){let e=this.o;const i=this.t;if(t&&void 0===e){const t=void 0!==i&&1===i.length;t&&(e=o.get(i)),void 0===e&&((this.o=e=new CSSStyleSheet).replaceSync(this.cssText),t&&o.set(i,e))}return e}toString(){return this.cssText}};const a=(e,...t)=>{const o=1===e.length?e[0]:t.reduce((t,i,o)=>t+(e=>{if(!0===e._$cssResult$)return e.cssText;if("number"==typeof e)return e;throw Error("Value passed to 'css' function must be a 'css' function result: "+e+". Use 'unsafeCSS' to pass non-literal values, but take care to ensure page security.")})(i)+e[o+1],e[0]);return new r(o,e,i)},s=t?e=>e:e=>e instanceof CSSStyleSheet?(e=>{let t="";for(const i of e.cssRules)t+=i.cssText;return(e=>new r("string"==typeof e?e:e+"",void 0,i))(t)})(e):e,{is:n,defineProperty:l,getOwnPropertyDescriptor:c,getOwnPropertyNames:d,getOwnPropertySymbols:p,getPrototypeOf:h}=Object,g=globalThis,u=g.trustedTypes,f=u?u.emptyScript:"",m=g.reactiveElementPolyfillSupport,b=(e,t)=>e,v={toAttribute(e,t){switch(t){case Boolean:e=e?f:null;break;case Object:case Array:e=null==e?e:JSON.stringify(e)}return e},fromAttribute(e,t){let i=e;switch(t){case Boolean:i=null!==e;break;case Number:i=null===e?null:Number(e);break;case Object:case Array:try{i=JSON.parse(e)}catch(e){i=null}}return i}},x=(e,t)=>!n(e,t),y={attribute:!0,type:String,converter:v,reflect:!1,useDefault:!1,hasChanged:x};
/**
   * @license
   * Copyright 2017 Google LLC
   * SPDX-License-Identifier: BSD-3-Clause
   */Symbol.metadata??=Symbol("metadata"),g.litPropertyMetadata??=new WeakMap;let _=class extends HTMLElement{static addInitializer(e){this._$Ei(),(this.l??=[]).push(e)}static get observedAttributes(){return this.finalize(),this._$Eh&&[...this._$Eh.keys()]}static createProperty(e,t=y){if(t.state&&(t.attribute=!1),this._$Ei(),this.prototype.hasOwnProperty(e)&&((t=Object.create(t)).wrapped=!0),this.elementProperties.set(e,t),!t.noAccessor){const i=Symbol(),o=this.getPropertyDescriptor(e,i,t);void 0!==o&&l(this.prototype,e,o)}}static getPropertyDescriptor(e,t,i){const{get:o,set:r}=c(this.prototype,e)??{get(){return this[t]},set(e){this[t]=e}};return{get:o,set(t){const a=o?.call(this);r?.call(this,t),this.requestUpdate(e,a,i)},configurable:!0,enumerable:!0}}static getPropertyOptions(e){return this.elementProperties.get(e)??y}static _$Ei(){if(this.hasOwnProperty(b("elementProperties")))return;const e=h(this);e.finalize(),void 0!==e.l&&(this.l=[...e.l]),this.elementProperties=new Map(e.elementProperties)}static finalize(){if(this.hasOwnProperty(b("finalized")))return;if(this.finalized=!0,this._$Ei(),this.hasOwnProperty(b("properties"))){const e=this.properties,t=[...d(e),...p(e)];for(const i of t)this.createProperty(i,e[i])}const e=this[Symbol.metadata];if(null!==e){const t=litPropertyMetadata.get(e);if(void 0!==t)for(const[e,i]of t)this.elementProperties.set(e,i)}this._$Eh=new Map;for(const[e,t]of this.elementProperties){const i=this._$Eu(e,t);void 0!==i&&this._$Eh.set(i,e)}this.elementStyles=this.finalizeStyles(this.styles)}static finalizeStyles(e){const t=[];if(Array.isArray(e)){const i=new Set(e.flat(1/0).reverse());for(const e of i)t.unshift(s(e))}else void 0!==e&&t.push(s(e));return t}static _$Eu(e,t){const i=t.attribute;return!1===i?void 0:"string"==typeof i?i:"string"==typeof e?e.toLowerCase():void 0}constructor(){super(),this._$Ep=void 0,this.isUpdatePending=!1,this.hasUpdated=!1,this._$Em=null,this._$Ev()}_$Ev(){this._$ES=new Promise(e=>this.enableUpdating=e),this._$AL=new Map,this._$E_(),this.requestUpdate(),this.constructor.l?.forEach(e=>e(this))}addController(e){(this._$EO??=new Set).add(e),void 0!==this.renderRoot&&this.isConnected&&e.hostConnected?.()}removeController(e){this._$EO?.delete(e)}_$E_(){const e=new Map,t=this.constructor.elementProperties;for(const i of t.keys())this.hasOwnProperty(i)&&(e.set(i,this[i]),delete this[i]);e.size>0&&(this._$Ep=e)}createRenderRoot(){const i=this.shadowRoot??this.attachShadow(this.constructor.shadowRootOptions);return((i,o)=>{if(t)i.adoptedStyleSheets=o.map(e=>e instanceof CSSStyleSheet?e:e.styleSheet);else for(const t of o){const o=document.createElement("style"),r=e.litNonce;void 0!==r&&o.setAttribute("nonce",r),o.textContent=t.cssText,i.appendChild(o)}})(i,this.constructor.elementStyles),i}connectedCallback(){this.renderRoot??=this.createRenderRoot(),this.enableUpdating(!0),this._$EO?.forEach(e=>e.hostConnected?.())}enableUpdating(e){}disconnectedCallback(){this._$EO?.forEach(e=>e.hostDisconnected?.())}attributeChangedCallback(e,t,i){this._$AK(e,i)}_$ET(e,t){const i=this.constructor.elementProperties.get(e),o=this.constructor._$Eu(e,i);if(void 0!==o&&!0===i.reflect){const r=(void 0!==i.converter?.toAttribute?i.converter:v).toAttribute(t,i.type);this._$Em=e,null==r?this.removeAttribute(o):this.setAttribute(o,r),this._$Em=null}}_$AK(e,t){const i=this.constructor,o=i._$Eh.get(e);if(void 0!==o&&this._$Em!==o){const e=i.getPropertyOptions(o),r="function"==typeof e.converter?{fromAttribute:e.converter}:void 0!==e.converter?.fromAttribute?e.converter:v;this._$Em=o;const a=r.fromAttribute(t,e.type);this[o]=a??this._$Ej?.get(o)??a,this._$Em=null}}requestUpdate(e,t,i,o=!1,r){if(void 0!==e){const a=this.constructor;if(!1===o&&(r=this[e]),i??=a.getPropertyOptions(e),!((i.hasChanged??x)(r,t)||i.useDefault&&i.reflect&&r===this._$Ej?.get(e)&&!this.hasAttribute(a._$Eu(e,i))))return;this.C(e,t,i)}!1===this.isUpdatePending&&(this._$ES=this._$EP())}C(e,t,{useDefault:i,reflect:o,wrapped:r},a){i&&!(this._$Ej??=new Map).has(e)&&(this._$Ej.set(e,a??t??this[e]),!0!==r||void 0!==a)||(this._$AL.has(e)||(this.hasUpdated||i||(t=void 0),this._$AL.set(e,t)),!0===o&&this._$Em!==e&&(this._$Eq??=new Set).add(e))}async _$EP(){this.isUpdatePending=!0;try{await this._$ES}catch(e){Promise.reject(e)}const e=this.scheduleUpdate();return null!=e&&await e,!this.isUpdatePending}scheduleUpdate(){return this.performUpdate()}performUpdate(){if(!this.isUpdatePending)return;if(!this.hasUpdated){if(this.renderRoot??=this.createRenderRoot(),this._$Ep){for(const[e,t]of this._$Ep)this[e]=t;this._$Ep=void 0}const e=this.constructor.elementProperties;if(e.size>0)for(const[t,i]of e){const{wrapped:e}=i,o=this[t];!0!==e||this._$AL.has(t)||void 0===o||this.C(t,void 0,i,o)}}let e=!1;const t=this._$AL;try{e=this.shouldUpdate(t),e?(this.willUpdate(t),this._$EO?.forEach(e=>e.hostUpdate?.()),this.update(t)):this._$EM()}catch(t){throw e=!1,this._$EM(),t}e&&this._$AE(t)}willUpdate(e){}_$AE(e){this._$EO?.forEach(e=>e.hostUpdated?.()),this.hasUpdated||(this.hasUpdated=!0,this.firstUpdated(e)),this.updated(e)}_$EM(){this._$AL=new Map,this.isUpdatePending=!1}get updateComplete(){return this.getUpdateComplete()}getUpdateComplete(){return this._$ES}shouldUpdate(e){return!0}update(e){this._$Eq&&=this._$Eq.forEach(e=>this._$ET(e,this[e])),this._$EM()}updated(e){}firstUpdated(e){}};_.elementStyles=[],_.shadowRootOptions={mode:"open"},_[b("elementProperties")]=new Map,_[b("finalized")]=new Map,m?.({ReactiveElement:_}),(g.reactiveElementVersions??=[]).push("2.1.2");
/**
   * @license
   * Copyright 2017 Google LLC
   * SPDX-License-Identifier: BSD-3-Clause
   */
const w=globalThis,$=e=>e,k=w.trustedTypes,S=k?k.createPolicy("lit-html",{createHTML:e=>e}):void 0,z="$lit$",C=`lit$${Math.random().toFixed(9).slice(2)}$`,A="?"+C,R=`<${A}>`,T=document,E=()=>T.createComment(""),D=e=>null===e||"object"!=typeof e&&"function"!=typeof e,I=Array.isArray,F="[ \t\n\f\r]",L=/<(?:(!--|\/[^a-zA-Z])|(\/?[a-zA-Z][^>\s]*)|(\/?$))/g,O=/-->/g,M=/>/g,N=RegExp(`>|${F}(?:([^\\s"'>=/]+)(${F}*=${F}*(?:[^ \t\n\f\r"'\`<>=]|("|')|))|$)`,"g"),U=/'/g,B=/"/g,P=/^(?:script|style|textarea|title)$/i,H=(e=>(t,...i)=>({_$litType$:e,strings:t,values:i}))(1),j=Symbol.for("lit-noChange"),V=Symbol.for("lit-nothing"),q=new WeakMap,G=T.createTreeWalker(T,129);function W(e,t){if(!I(e)||!e.hasOwnProperty("raw"))throw Error("invalid template strings array");return void 0!==S?S.createHTML(t):t}const Y=(e,t)=>{const i=e.length-1,o=[];let r,a=2===t?"<svg>":3===t?"<math>":"",s=L;for(let t=0;t<i;t++){const i=e[t];let n,l,c=-1,d=0;for(;d<i.length&&(s.lastIndex=d,l=s.exec(i),null!==l);)d=s.lastIndex,s===L?"!--"===l[1]?s=O:void 0!==l[1]?s=M:void 0!==l[2]?(P.test(l[2])&&(r=RegExp("</"+l[2],"g")),s=N):void 0!==l[3]&&(s=N):s===N?">"===l[0]?(s=r??L,c=-1):void 0===l[1]?c=-2:(c=s.lastIndex-l[2].length,n=l[1],s=void 0===l[3]?N:'"'===l[3]?B:U):s===B||s===U?s=N:s===O||s===M?s=L:(s=N,r=void 0);const p=s===N&&e[t+1].startsWith("/>")?" ":"";a+=s===L?i+R:c>=0?(o.push(n),i.slice(0,c)+z+i.slice(c)+C+p):i+C+(-2===c?t:p)}return[W(e,a+(e[i]||"<?>")+(2===t?"</svg>":3===t?"</math>":"")),o]};class J{constructor({strings:e,_$litType$:t},i){let o;this.parts=[];let r=0,a=0;const s=e.length-1,n=this.parts,[l,c]=Y(e,t);if(this.el=J.createElement(l,i),G.currentNode=this.el.content,2===t||3===t){const e=this.el.content.firstChild;e.replaceWith(...e.childNodes)}for(;null!==(o=G.nextNode())&&n.length<s;){if(1===o.nodeType){if(o.hasAttributes())for(const e of o.getAttributeNames())if(e.endsWith(z)){const t=c[a++],i=o.getAttribute(e).split(C),s=/([.?@])?(.*)/.exec(t);n.push({type:1,index:r,name:s[2],strings:i,ctor:"."===s[1]?ee:"?"===s[1]?te:"@"===s[1]?ie:Q}),o.removeAttribute(e)}else e.startsWith(C)&&(n.push({type:6,index:r}),o.removeAttribute(e));if(P.test(o.tagName)){const e=o.textContent.split(C),t=e.length-1;if(t>0){o.textContent=k?k.emptyScript:"";for(let i=0;i<t;i++)o.append(e[i],E()),G.nextNode(),n.push({type:2,index:++r});o.append(e[t],E())}}}else if(8===o.nodeType)if(o.data===A)n.push({type:2,index:r});else{let e=-1;for(;-1!==(e=o.data.indexOf(C,e+1));)n.push({type:7,index:r}),e+=C.length-1}r++}}static createElement(e,t){const i=T.createElement("template");return i.innerHTML=e,i}}function X(e,t,i=e,o){if(t===j)return t;let r=void 0!==o?i._$Co?.[o]:i._$Cl;const a=D(t)?void 0:t._$litDirective$;return r?.constructor!==a&&(r?._$AO?.(!1),void 0===a?r=void 0:(r=new a(e),r._$AT(e,i,o)),void 0!==o?(i._$Co??=[])[o]=r:i._$Cl=r),void 0!==r&&(t=X(e,r._$AS(e,t.values),r,o)),t}class Z{constructor(e,t){this._$AV=[],this._$AN=void 0,this._$AD=e,this._$AM=t}get parentNode(){return this._$AM.parentNode}get _$AU(){return this._$AM._$AU}u(e){const{el:{content:t},parts:i}=this._$AD,o=(e?.creationScope??T).importNode(t,!0);G.currentNode=o;let r=G.nextNode(),a=0,s=0,n=i[0];for(;void 0!==n;){if(a===n.index){let t;2===n.type?t=new K(r,r.nextSibling,this,e):1===n.type?t=new n.ctor(r,n.name,n.strings,this,e):6===n.type&&(t=new oe(r,this,e)),this._$AV.push(t),n=i[++s]}a!==n?.index&&(r=G.nextNode(),a++)}return G.currentNode=T,o}p(e){let t=0;for(const i of this._$AV)void 0!==i&&(void 0!==i.strings?(i._$AI(e,i,t),t+=i.strings.length-2):i._$AI(e[t])),t++}}class K{get _$AU(){return this._$AM?._$AU??this._$Cv}constructor(e,t,i,o){this.type=2,this._$AH=V,this._$AN=void 0,this._$AA=e,this._$AB=t,this._$AM=i,this.options=o,this._$Cv=o?.isConnected??!0}get parentNode(){let e=this._$AA.parentNode;const t=this._$AM;return void 0!==t&&11===e?.nodeType&&(e=t.parentNode),e}get startNode(){return this._$AA}get endNode(){return this._$AB}_$AI(e,t=this){e=X(this,e,t),D(e)?e===V||null==e||""===e?(this._$AH!==V&&this._$AR(),this._$AH=V):e!==this._$AH&&e!==j&&this._(e):void 0!==e._$litType$?this.$(e):void 0!==e.nodeType?this.T(e):(e=>I(e)||"function"==typeof e?.[Symbol.iterator])(e)?this.k(e):this._(e)}O(e){return this._$AA.parentNode.insertBefore(e,this._$AB)}T(e){this._$AH!==e&&(this._$AR(),this._$AH=this.O(e))}_(e){this._$AH!==V&&D(this._$AH)?this._$AA.nextSibling.data=e:this.T(T.createTextNode(e)),this._$AH=e}$(e){const{values:t,_$litType$:i}=e,o="number"==typeof i?this._$AC(e):(void 0===i.el&&(i.el=J.createElement(W(i.h,i.h[0]),this.options)),i);if(this._$AH?._$AD===o)this._$AH.p(t);else{const e=new Z(o,this),i=e.u(this.options);e.p(t),this.T(i),this._$AH=e}}_$AC(e){let t=q.get(e.strings);return void 0===t&&q.set(e.strings,t=new J(e)),t}k(e){I(this._$AH)||(this._$AH=[],this._$AR());const t=this._$AH;let i,o=0;for(const r of e)o===t.length?t.push(i=new K(this.O(E()),this.O(E()),this,this.options)):i=t[o],i._$AI(r),o++;o<t.length&&(this._$AR(i&&i._$AB.nextSibling,o),t.length=o)}_$AR(e=this._$AA.nextSibling,t){for(this._$AP?.(!1,!0,t);e!==this._$AB;){const t=$(e).nextSibling;$(e).remove(),e=t}}setConnected(e){void 0===this._$AM&&(this._$Cv=e,this._$AP?.(e))}}class Q{get tagName(){return this.element.tagName}get _$AU(){return this._$AM._$AU}constructor(e,t,i,o,r){this.type=1,this._$AH=V,this._$AN=void 0,this.element=e,this.name=t,this._$AM=o,this.options=r,i.length>2||""!==i[0]||""!==i[1]?(this._$AH=Array(i.length-1).fill(new String),this.strings=i):this._$AH=V}_$AI(e,t=this,i,o){const r=this.strings;let a=!1;if(void 0===r)e=X(this,e,t,0),a=!D(e)||e!==this._$AH&&e!==j,a&&(this._$AH=e);else{const o=e;let s,n;for(e=r[0],s=0;s<r.length-1;s++)n=X(this,o[i+s],t,s),n===j&&(n=this._$AH[s]),a||=!D(n)||n!==this._$AH[s],n===V?e=V:e!==V&&(e+=(n??"")+r[s+1]),this._$AH[s]=n}a&&!o&&this.j(e)}j(e){e===V?this.element.removeAttribute(this.name):this.element.setAttribute(this.name,e??"")}}class ee extends Q{constructor(){super(...arguments),this.type=3}j(e){this.element[this.name]=e===V?void 0:e}}class te extends Q{constructor(){super(...arguments),this.type=4}j(e){this.element.toggleAttribute(this.name,!!e&&e!==V)}}class ie extends Q{constructor(e,t,i,o,r){super(e,t,i,o,r),this.type=5}_$AI(e,t=this){if((e=X(this,e,t,0)??V)===j)return;const i=this._$AH,o=e===V&&i!==V||e.capture!==i.capture||e.once!==i.once||e.passive!==i.passive,r=e!==V&&(i===V||o);o&&this.element.removeEventListener(this.name,this,i),r&&this.element.addEventListener(this.name,this,e),this._$AH=e}handleEvent(e){"function"==typeof this._$AH?this._$AH.call(this.options?.host??this.element,e):this._$AH.handleEvent(e)}}class oe{constructor(e,t,i){this.element=e,this.type=6,this._$AN=void 0,this._$AM=t,this.options=i}get _$AU(){return this._$AM._$AU}_$AI(e){X(this,e)}}const re=w.litHtmlPolyfillSupport;re?.(J,K),(w.litHtmlVersions??=[]).push("3.3.3");const ae=globalThis;
/**
   * @license
   * Copyright 2017 Google LLC
   * SPDX-License-Identifier: BSD-3-Clause
   */let se=class extends _{constructor(){super(...arguments),this.renderOptions={host:this},this._$Do=void 0}createRenderRoot(){const e=super.createRenderRoot();return this.renderOptions.renderBefore??=e.firstChild,e}update(e){const t=this.render();this.hasUpdated||(this.renderOptions.isConnected=this.isConnected),super.update(e),this._$Do=((e,t,i)=>{const o=i?.renderBefore??t;let r=o._$litPart$;if(void 0===r){const e=i?.renderBefore??null;o._$litPart$=r=new K(t.insertBefore(E(),e),e,void 0,i??{})}return r._$AI(e),r})(t,this.renderRoot,this.renderOptions)}connectedCallback(){super.connectedCallback(),this._$Do?.setConnected(!0)}disconnectedCallback(){super.disconnectedCallback(),this._$Do?.setConnected(!1)}render(){return j}};se._$litElement$=!0,se.finalized=!0,ae.litElementHydrateSupport?.({LitElement:se});const ne=ae.litElementPolyfillSupport;ne?.({LitElement:se}),(ae.litElementVersions??=[]).push("4.2.2");const le="/api/hacs_vision";const ce=new class{constructor(){this._token=null,this._hassRef=null}setHass(e){this._hassRef=e;try{e?.auth?.data?.access_token?this._token=e.auth.data.access_token:e?.authToken?this._token=e.authToken:e?.connection?.accessToken?this._token=e.connection.accessToken:e?.config?.authToken&&(this._token=e.config.authToken)}catch(e){}}_getHeaders(){const e={"Content-Type":"application/json"};if(!this._token)try{this._hassRef?.auth?.data?.access_token&&(this._token=this._hassRef.auth.data.access_token)}catch(e){}if(!this._token)try{const e=window.parent?.document;if(e){const t=e.querySelector("home-assistant"),i=t?.hass;i?.auth?.data?.access_token&&(this._token=i.auth.data.access_token)}}catch(e){}if(!this._token)try{const e=document.querySelector("home-assistant"),t=e?.hass;t?.auth?.data?.access_token&&(this._token=t.auth.data.access_token)}catch(e){}return this._token&&(e.Authorization=`Bearer ${this._token}`),e}async request(e,t,i){const o={method:e,headers:this._getHeaders(),credentials:"include"};i&&(o.body=JSON.stringify(i));try{const e=await fetch(`${le}/${t}`,o);if(!e.ok){const t=new Error(`API error: ${e.status}`);throw t.status=e.status,this._onNetworkStatus&&(429===e.status?this._onNetworkStatus("rate_limited"):e.status>=500&&this._onNetworkStatus("server_error")),t}return this._onNetworkStatus&&this._onNetworkStatus("online"),e.json()}catch(e){throw!navigator.onLine&&this._onNetworkStatus&&this._onNetworkStatus("offline"),e}}get(e){return this.request("GET",e)}post(e,t){return this.request("POST",e,t)}delete(e,t){return this.request("DELETE",e,t)}listRepositories(e={}){const t=new URLSearchParams;return e.search&&t.set("search",e.search),e.category&&t.set("category",e.category),e.sort&&t.set("sort",e.sort),e.sortDir&&t.set("sortDir",e.sortDir),e.status&&t.set("status",e.status),e.page&&t.set("page",String(e.page)),e.limit&&t.set("limit",String(e.limit)),this.get(`repositories?${t}`)}getRepository(e){return this.get(`repositories/${e}`)}getInstalled(){return this.get("installed")}getStats(){return this.get("installed/stats")}getUpdates(){return this.get("updates")}install(e,t){return this.post("install",{repository:e,category:t})}update(e){return this.post("update",{repository_ids:e})}remove(e){return this.post("remove",{repository:e})}getConfig(){return this.get("config")}updateConfig(e){return this.post("config",e)}getCustomRepos(){return this.get("config/custom")}addCustomRepo(e,t){return this.post("config/custom",{repository:e,category:t})}removeCustomRepo(e){return this.delete("config/custom",{repository:e})}removeArchivedRepo(e){return this.post("management/remove_archived",{repository:e})}removeRenamedRepo(e){return this.post("management/remove_renamed",{old_name:e})}replaceRenamedRepo(e,t){return this.post("management/replace_renamed",{old_name:e,new_name:t})}exportBackup(){return this.get("backup/export")}importBackup(e){return this.post("backup/import",e)}checkDependencies(){return this.get("dependencies")}refresh(){return this.post("refresh")}restartHA(){return this.post("restart")}getSettings(){return this.get("settings")}updateSettings(e){return this.post("settings",e)}getConfigEntries(){return this.get("config_entries")}getVersion(){return this.get("version")}batchInstall(e){return this.post("batch/install",{repositories:e})}batchRemove(e){return this.post("batch/remove",{repositories:e})}checkUpdatesWithNotify(){return this.post("check_updates")}getFlowHandlers(){return this.get("config_flow/handlers")}startConfigFlow(e){return this.post("config_flow/start",{handler:e})}stepConfigFlow(e,t){return this.post(`config_flow/step/${e}`,t)}cancelConfigFlow(e){return this.request("DELETE",`config_flow/flow/${e}`)}startOptionsFlow(e){return this.post("config_flow/options/start",{handler:e})}stepOptionsFlow(e,t){return this.post(`config_flow/options/step/${e}`,t)}startSubentryFlow(e,t,i){return this.post("config_flow/subentry/start",{handler:[e,t],...i})}stepSubentryFlow(e,t){return this.post(`config_flow/subentry/step/${e}`,t)}cancelSubentryFlow(e){return this.request("DELETE",`config_flow/subentry/flow/${e}`)}getSubentries(e){return this.request("GET",`config_entries/subentries/${e}`)}getTranslations(e,t){const i=t||"zh-Hans";return this.get(`translations/${encodeURIComponent(e)}?lang=${encodeURIComponent(i)}`)}getRepoStatus(e){return this.get(`repos/status/${encodeURIComponent(e)}`)}getFavorites(){return this.get("favorites")}setFavorites(e){return this.post("favorites",{favorites:e})}getRepoReleases(e){return this._fetch(`/repos/releases?id=${encodeURIComponent(e)}`)}installVersion(e,t){return this._post("/repos/install_version",{id:e,version:t})}async _fetch(e){const t={method:"GET",headers:this._getHeaders(),credentials:"include"};try{const i=await fetch(`${le}${e}`,t);if(!i.ok){const e=new Error(`API error: ${i.status}`);throw e.status=i.status,e}return i.json()}catch(e){throw!navigator.onLine&&this._onNetworkStatus&&this._onNetworkStatus("offline"),e}}async _post(e,t){const i={method:"POST",headers:this._getHeaders(),credentials:"include",body:JSON.stringify(t)};try{const t=await fetch(`${le}${e}`,i);if(!t.ok){const e=new Error(`API error: ${t.status}`);throw e.status=t.status,this._onNetworkStatus&&(429===t.status?this._onNetworkStatus("rate_limited"):t.status>=500&&this._onNetworkStatus("server_error")),e}return this._onNetworkStatus&&this._onNetworkStatus("online"),t.json()}catch(e){throw!navigator.onLine&&this._onNetworkStatus&&this._onNetworkStatus("offline"),e}}async getChangelog(e){const t=`hacs_changelog_${e}`;try{const e=localStorage.getItem(t);if(e){const{data:t,timestamp:i}=JSON.parse(e);if(Date.now()-i<36e5)return t}}catch(e){}try{const i=await this.get(`changelog/${e}`);try{localStorage.setItem(t,JSON.stringify({data:i,timestamp:Date.now()}))}catch(e){}return i}catch(e){return console.error("Changelog fetch failed:",e),null}}async getReadme(e){const t=`hacs_readme_${e}`;try{const e=localStorage.getItem(t);if(e){const{html:t,timestamp:i}=JSON.parse(e);if(Date.now()-i<36e5)return t}}catch(e){}try{const i=await fetch(`${le}/readme/${e}`,{headers:this._getHeaders(),credentials:"include"});if(i.ok){const e=await i.text();try{localStorage.setItem(t,JSON.stringify({html:e,timestamp:Date.now()}))}catch(e){}return e}return null}catch(e){return console.error("Failed to fetch README:",e),null}}},de=e=>class extends e{static properties={_themeReady:{type:Boolean,state:!0}};constructor(){super(),this._themeReady=!1}connectedCallback(){super.connectedCallback(),requestAnimationFrame(()=>{this._applyTheme(),this._themeReady=!0}),this._setupThemeObserver()}disconnectedCallback(){super.disconnectedCallback?.(),this._themeObserver&&(this._themeObserver.disconnect(),this._themeObserver=null)}_getHAVar(e,t=""){try{const t=document.querySelector("home-assistant")?.shadowRoot||document.querySelector("ha-app")?.shadowRoot||document.documentElement,i=[this.renderRoot?.host,t,document.documentElement,document.body];for(const t of i)if(t)try{const i=getComputedStyle(t).getPropertyValue(e).trim();if(i)return i}catch(e){}try{if(window.parent&&window.parent!==window){const t=window.parent.document.querySelector("home-assistant")?.shadowRoot||window.parent.document.documentElement;if(t){const i=getComputedStyle(t).getPropertyValue(e).trim();if(i)return i}}}catch(e){}}catch(e){}return t}_applyTheme(){const e=this.renderRoot?.host||this,t=this._isDarkMode(),i={"--primary-background-color":t?"#111111":"#f5f5f5","--secondary-background-color":t?"#1c1c1c":"#e0e0e0","--primary-text-color":t?"#e1e1e1":"#212121","--secondary-text-color":t?"#9e9e9e":"#727272","--card-background-color":t?"#1c1c1c":"#ffffff","--divider-color":t?"#333333":"#e0e0e0","--primary-color":"#03a9f4","--rgb-primary-color":"3, 169, 244","--ha-card-border-radius":"12px"};for(const[t,o]of Object.entries(i)){const i=this._getHAVar(t);if(e.style.setProperty(t,i||o),"--primary-color"===t&&!i){const t=this._hexToRgb(o);t&&e.style.setProperty("--rgb-primary-color",t)}}const o=e.style.getPropertyValue("--primary-color").trim()||i["--primary-color"],r=this._getHAVar("--rgb-primary-color")||this._hexToRgb(o)||"3, 169, 244";e.style.setProperty("--rgb-primary-color",r)}_isDarkMode(){try{const e=document.documentElement.getAttribute("data-theme");if(e&&e.includes("dark"))return!0;const t=this._getHAVar("--primary-background-color");if(t){const e=this._parseColor(t);if(e){return.299*e.r+.587*e.g+.114*e.b<128}}const i=document.body?.getAttribute("data-theme");if(i&&i.includes("dark"))return!0}catch(e){}try{return window.matchMedia("(prefers-color-scheme: dark)").matches}catch(e){return!1}}_parseColor(e){const t=e.match(/^#([0-9a-f]{3,8})$/i);if(t){let e=t[1];if(3===e.length&&(e=e[0]+e[0]+e[1]+e[1]+e[2]+e[2]),e.length>=6){const t=parseInt(e.substring(0,2),16),i=parseInt(e.substring(2,4),16),o=parseInt(e.substring(4,6),16);if(!isNaN(t+i+o))return{r:t,g:i,b:o}}}const i=e.match(/rgba?\(\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)/);return i?{r:parseInt(i[1]),g:parseInt(i[2]),b:parseInt(i[3])}:null}_hexToRgb(e){const t=e.match(/rgba?\((\d+)\s*,\s*(\d+)\s*,\s*(\d+)/);if(t)return`${t[1]}, ${t[2]}, ${t[3]}`;if(3===(e=e.replace(/^#/,"")).length&&(e=e[0]+e[0]+e[1]+e[1]+e[2]+e[2]),6!==e.length)return null;const i=parseInt(e.substring(0,2),16),o=parseInt(e.substring(2,4),16),r=parseInt(e.substring(4,6),16);return isNaN(i+o+r)?null:`${i}, ${o}, ${r}`}_setupThemeObserver(){try{const e=document.querySelector("home-assistant")||document.querySelector("ha-app")||document.documentElement;e&&(this._themeObserver=new MutationObserver(()=>{this._themeObserver?._debounce||(this._themeObserver._debounce=!0,setTimeout(()=>{this._themeObserver&&(this._themeObserver._debounce=!1),this._applyTheme()},200))}),this._themeObserver.observe(e,{attributes:!0,attributeFilter:["class","style"],subtree:!0}))}catch(e){}}};let pe=(()=>{try{const e=window.top||window.parent,t=e?.document?.querySelector("home-assistant");if(t?.hass?.language)return 0===t.hass.language.indexOf("zh")?"zh":"en";return 0===(e?.document?.documentElement?.lang||"").indexOf("zh")?"zh":"en"}catch(e){}try{return 0===navigator.language?.indexOf("zh")?"zh":"en"}catch(e){return"en"}})();const he={storeTitle:{zh:"HACS Vision",en:"HACS Vision"},storeSubtitle:{zh:"浏览、管理和更新 HACS 仓库",en:"Browse, manage and update HACS repositories"},statInstalled:{zh:"已安装",en:"Installed"},statUpdates:{zh:"可更新",en:"Updates"},statFavorites:{zh:"收藏",en:"Favorites"},statCustom:{zh:"自定义",en:"Custom"},statRepos:{zh:"仓库数",en:"Repos"},tabBrowse:{zh:"商店",en:"Store"},tabFavorites:{zh:"收藏",en:"Favorites"},tabCustom:{zh:"自定义",en:"Custom"},tabInstalled:{zh:"已安装",en:"Installed"},tabUpdates:{zh:"更新",en:"Updates"},tabConfig:{zh:"配置",en:"Config"},tabBackup:{zh:"备份",en:"Backup"},tabManagement:{zh:"仓库管理",en:"Repository"},tabIntegrations:{zh:"集成管理",en:"Integrations"},searchPlaceholder:{zh:"搜索仓库...",en:"Search repositories..."},searchInstalled:{zh:"搜索已安装...",en:"Search installed..."},searchUpdates:{zh:"搜索可更新的仓库...",en:"Search for updates..."},filterStatus:{zh:"状态",en:"Status"},filterType:{zh:"类型",en:"Type"},filterTags:{zh:"标记",en:"Tags"},statusAll:{zh:"全部",en:"All"},statusInstalled:{zh:"已安装",en:"Installed"},statusNotInstalled:{zh:"未安装",en:"Not Installed"},statusUpdateAvailable:{zh:"可更新",en:"Update Available"},statusPendingRestart:{zh:"待重启",en:"Pending Restart"},statusPendingUpgrade:{zh:"可更新",en:"Update Available"},statusDefault:{zh:"未安装",en:"Available"},typeAll:{zh:"全部",en:"All"},typeIntegration:{zh:"集成",en:"Integration"},typePlugin:{zh:"插件",en:"Plugin"},typeTheme:{zh:"主题",en:"Theme"},typeTemplate:{zh:"模板",en:"Template"},sortByStars:{zh:"按星数",en:"By Stars"},sortByUpdated:{zh:"最近更新",en:"Recently Updated"},sortByName:{zh:"按名称",en:"By Name"},catAll:{zh:"全部",en:"All"},catIntegration:{zh:"集成",en:"Integration"},catPlugin:{zh:"插件",en:"Plugin"},catTheme:{zh:"主题",en:"Theme"},catTemplate:{zh:"模板",en:"Template"},catDashboard:{zh:"卡片",en:"Cards"},catAppDaemon:{zh:"AppDaemon",en:"AppDaemon"},catNetDaemon:{zh:"NetDaemon",en:"NetDaemon"},catPythonScript:{zh:"Python 脚本",en:"Python Script"},catCustom:{zh:"自定义",en:"Custom"},totalRepos:{zh:"个仓库",en:"repositories"},noMatch:{zh:"没有匹配的仓库",en:"No matching repositories"},noData:{zh:"暂无仓库数据",en:"No repository data"},loading:{zh:"加载中...",en:"Loading..."},prevPage:{zh:"← 上一页",en:"← Previous"},nextPage:{zh:"下一页 →",en:"Next →"},page:{zh:"第",en:"Page"},of:{zh:"/ ",en:" / "},installed:{zh:"已安装",en:"Installed"},install:{zh:"安装",en:"Install"},update:{zh:"更新",en:"Update"},remove:{zh:"卸载",en:"Uninstall"},detail:{zh:"详情",en:"Detail"},noDesc:{zh:"暂无描述",en:"No description"},favOn:{zh:"已收藏",en:"Favorited"},favOff:{zh:"收藏",en:"Favorite"},tagFavorites:{zh:"收藏",en:"Favorites"},tagNew:{zh:"新发现",en:"New"},tagCustom:{zh:"自定义",en:"Custom"},badgeConfigured:{zh:"已配置",en:"Configured"},badgeLoadFailed:{zh:"加载失败",en:"Load Failed"},canUpdate:{zh:"可更新",en:"Updatable"},allTypes:{zh:"全部类型",en:"All Types"},refresh:{zh:"刷新",en:"Refresh"},noInstalled:{zh:"暂无已安装仓库",en:"No installed repositories"},noMatchInstalled:{zh:"没有匹配的已安装仓库",en:"No matching installed repos"},totalInstalled:{zh:"个已安装仓库",en:"installed repositories"},confirmRemove:{zh:"确定要卸载",en:"Are you sure to uninstall"},removed:{zh:"已卸载",en:"Uninstalled"},removeFailed:{zh:"卸载失败",en:"Uninstall failed"},updating:{zh:"更新中...",en:"Updating..."},checkingUpdates:{zh:"检查更新...",en:"Checking updates..."},allUpToDate:{zh:"所有仓库已是最新版本",en:"All repositories are up to date"},totalUpdates:{zh:"个可更新仓库",en:"repositories can be updated"},updateAll:{zh:"全部更新",en:"Update All"},updateSelected:{zh:"更新已选",en:"Update Selected"},updateAllNow:{zh:"全部更新",en:"Update All"},currentVersion:{zh:"当前版本",en:"Current"},latestVersion:{zh:"最新版本",en:"Latest"},updateNow:{zh:"立即更新",en:"Update Now"},confirmUpdateAll:{zh:"确定要更新全部",en:"Update all"},allUpdatesStarted:{zh:"全部更新已开始",en:"All updates started"},updateStarted:{zh:"已开始更新",en:"Update started"},updateFailed:{zh:"更新失败",en:"Update failed"},selectAll:{zh:"全选",en:"Select All"},customRepos:{zh:"自定义仓库",en:"Custom Repositories"},noCustomRepos:{zh:"暂无自定义仓库",en:"No custom repositories"},noCustomReposHint:{zh:"点击下方按钮添加自定义仓库，或从浏览页安装",en:"Click below to add a custom repo, or install from Browse"},customReposDesc:{zh:"管理 HACS 自定义仓库列表。添加后可在商店中搜索到。",en:"Manage custom repository list. Once added, they become searchable in Store."},addRepo:{zh:"添加仓库",en:"Add Repository"},addSuccess:{zh:"添加成功",en:"Added successfully"},invalidRepoUrl:{zh:"无效的仓库地址，请输入 owner/repo 格式或 GitHub URL",en:"Invalid repository URL, use owner/repo format or GitHub URL"},addCustomRepo:{zh:"添加自定义仓库",en:"Add Custom Repository"},repoUrl:{zh:"仓库 URL (如: https://github.com/user/repo)",en:"Repository URL (e.g. https://github.com/user/repo)"},add:{zh:"添加",en:"Add"},cancel:{zh:"取消",en:"Cancel"},addFailed:{zh:"添加失败",en:"Add failed"},removeRepo:{zh:"移除",en:"Remove"},confirmRemoveRepo:{zh:"确定要移除自定义仓库",en:"Remove custom repository"},removeRepoFailed:{zh:"移除失败",en:"Remove failed"},notInstalled:{zh:"未安装",en:"Not installed"},alreadyExists:{zh:"已在列表中",en:"already exists"},customBadge:{zh:"自定义",en:"Custom"},archivedRepos:{zh:"已归档仓库",en:"Archived Repositories"},noArchived:{zh:"暂无归档仓库",en:"No archived repositories"},renamedRepos:{zh:"已重命名仓库",en:"Renamed Repositories"},noRenamed:{zh:"暂无重命名仓库",en:"No renamed repositories"},ignoredRepos:{zh:"已忽略仓库",en:"Ignored Repositories"},noIgnored:{zh:"暂无忽略仓库",en:"No ignored repositories"},removeArchived:{zh:"移除归档",en:"Remove Archived"},removeRenamed:{zh:"移除重命名",en:"Remove Renamed"},replace:{zh:"替换",en:"Replace"},viewDetail:{zh:"查看详情",en:"View Detail"},confirmRemoveArchived:{zh:"将永久清除归档仓库的全部数据记录",en:"Permanently clear all data records for this archived repo"},confirmRemoveRenamed:{zh:"将永久清除重命名记录的全部数据记录",en:"Permanently clear all data records for this renamed repo"},confirmReplaceRenamed:{zh:"将替换仓库",en:"Replace repository"},replaceRenamedWarning:{zh:"（将卸载旧仓库并安装新仓库）",en:" (will uninstall old, install new)"},viewOnGithub:{zh:"在 GitHub 中查看",en:"View on GitHub"},exportBackup:{zh:"导出备份",en:"Export Backup"},exportDesc:{zh:"将 HACS 配置、已安装仓库列表和自定义仓库设置导出为 JSON 文件。导出后可在新环境中导入恢复。",en:"Export HACS config, installed repositories and custom repo settings as JSON. Can be imported in new environments."},exportBtn:{zh:"导出备份",en:"Export Backup"},exporting:{zh:"导出中...",en:"Exporting..."},exportSuccess:{zh:"备份导出成功",en:"Backup exported successfully"},exportFailed:{zh:"导出失败",en:"Export failed"},importBackup:{zh:"导入备份",en:"Import Backup"},importDesc:{zh:"从之前导出的 JSON 备份文件恢复 HACS 配置。注意：导入会覆盖当前配置。",en:"Restore HACS config from a previously exported JSON backup. Note: Import will overwrite current config."},importBtn:{zh:"导入备份",en:"Import Backup"},importing:{zh:"导入中...",en:"Importing..."},importSuccess:{zh:"备份导入成功",en:"Backup imported successfully"},importFailed:{zh:"导入失败",en:"Import failed"},depCheck:{zh:"依赖检查",en:"Dependency Check"},depDesc:{zh:"检查 HACS Vision 的系统依赖是否完整安装。",en:"Check if HACS Vision system dependencies are fully installed."},checkDep:{zh:"检查依赖",en:"Check Dependencies"},depOk:{zh:"所有依赖正常",en:"All dependencies OK"},depMissing:{zh:"部分依赖缺失",en:"Some dependencies missing"},checkFailed:{zh:"检查失败",en:"Check failed"},noFavorites:{zh:"暂无收藏",en:"No favorites yet"},noFavoritesHint:{zh:"在浏览页点击卡片右上角的 ☆ 收藏仓库",en:"Click ☆ on the top-right of cards to favorite repositories"},clearAll:{zh:"清空收藏",en:"Clear All"},confirmClear:{zh:"确定要清空所有收藏吗？",en:"Clear all favorites?"},favoritesCleared:{zh:"已清空收藏",en:"Favorites cleared"},openGithub:{zh:"在 GitHub 中打开",en:"Open in GitHub"},description:{zh:"描述",en:"Description"},version:{zh:"版本",en:"Version"},downloads:{zh:"下载量",en:"Downloads"},stars:{zh:"星数",en:"Stars"},category:{zh:"分类",en:"Category"},close:{zh:"关闭",en:"Close"},unknown:{zh:"未知",en:"unknown"},search:{zh:"搜索",en:"Search"},refreshTitle:{zh:"刷新",en:"Refresh"},totalPrefix:{zh:"共",en:"Total"},connectFailed:{zh:"连接 HACS 失败",en:"Failed to connect to HACS"},waitingHA:{zh:"等待 HA 连接...",en:"Waiting for HA connection..."},confirm:{zh:"确认",en:"Confirm"},confirmDelete:{zh:"确认删除",en:"Confirm Delete"},confirmUpdate:{zh:"确认更新",en:"Confirm Update"},enabled:{zh:"启用",en:"Enabled"},disabled:{zh:"禁用",en:"Disabled"},save:{zh:"保存",en:"Save"},loadingReadme:{zh:"加载 README...",en:"Loading README..."},readmeLoadFailed:{zh:"README 加载失败",en:"README load failed"},readmeTitle:{zh:"说明文档",en:"README"},dblZoomHint:{zh:"双击放大",en:"Double-click to expand"},networkOffline:{zh:"网络连接已断开，请检查网络",en:"Network disconnected — check your connection"},networkRestored:{zh:"网络已恢复",en:"Network restored"},haRestarting:{zh:"Home Assistant 正在重启，请稍候...",en:"Home Assistant is restarting, please wait..."},rateLimited:{zh:"GitHub API 限流，请稍后重试",en:"GitHub API rate limited — try again later"},restartHA:{zh:"重启",en:"Restart"},restartHATitle:{zh:"重启 Home Assistant",en:"Restart Home Assistant"},restartConfirm:{zh:"确定要重启 Home Assistant 吗？面板将暂时不可用。",en:"Restart Home Assistant? The panel will be temporarily unavailable."},restartFailed:{zh:"重启失败",en:"Restart failed"},installing:{zh:"安装中…",en:"Installing…"},installComplete:{zh:"已安装",en:"Installed"},installFailed:{zh:"安装失败",en:"Install failed"},updatingProgress:{zh:"更新中…",en:"Updating…"},updateComplete:{zh:"已更新",en:"Updated"},quickInstall:{zh:"快捷安装",en:"Quick Install"},quickInstallPlaceholder:{zh:"粘贴 GitHub URL 或 owner/repo",en:"Paste GitHub URL or owner/repo"},quickInstallCategory:{zh:"分类",en:"Category"},quickInstallUrl:{zh:"仓库 URL",en:"Repository URL"},installRepo:{zh:"安装仓库",en:"Install Repository"},changelogTitle:{zh:"更新内容",en:"What's New"},viewFullChangelog:{zh:"查看完整更新日志",en:"View full changelog"},noChangelog:{zh:"暂无更新日志",en:"No changelog available"},changelogShowMore:{zh:"展开",en:"Show more"},changelogShowLess:{zh:"收起",en:"Show less"},viewCard:{zh:"卡片",en:"Cards"},viewList:{zh:"列表",en:"List"},list:{zh:"列表",en:"List"},groupBy:{zh:"分组",en:"Group By"},groupNone:{zh:"不分组",en:"No Grouping"},groupStatus:{zh:"按状态",en:"By Status"},groupType:{zh:"按类型",en:"By Type"},selectVersion:{zh:"选择版本",en:"Select Version"},availableVersion:{zh:"可用版本",en:"Available Version"},installVersion:{zh:"安装此版本",en:"Install This Version"},prerelease:{zh:"预发布",en:"Pre-release"},noReleases:{zh:"暂无发布版本",en:"No releases available"},publishedAt:{zh:"发布于",en:"Published"},tools:{zh:"工具",en:"Tools"},toolsDesc:{zh:"导出、导入和依赖检查",en:"Export, import and dependency check"},colName:{zh:"名称",en:"Name"},colDownloads:{zh:"下载",en:"Downloads"},colStars:{zh:"星数",en:"Stars"},colLastUpdated:{zh:"更新",en:"Updated"},colInstalledVer:{zh:"已安装",en:"Installed"},colAvailableVer:{zh:"可用",en:"Available"},colStatus:{zh:"状态",en:"Status"},colInstalledAt:{zh:"安装时间",en:"Installed At"},installedAt:{zh:"安装时间",en:"Installed At"},today:{zh:"今天",en:"Today"},yesterday:{zh:"昨天",en:"Yesterday"},tabSettings:{zh:"设置",en:"Settings"},settingsTitle:{zh:"设置",en:"Settings"},settingsDesc:{zh:"自定义 HACS Vision 的显示和行为",en:"Customize HACS Vision look and behavior"},settingsRefreshInterval:{zh:"刷新间隔（秒）",en:"Refresh interval (s)"},settingsDefaultView:{zh:"默认视图",en:"Default view"},settingsNotifyUpdates:{zh:"推送更新通知",en:"Push update notifications"},settingsNotifyRestart:{zh:"推送重启提醒",en:"Push restart reminders"},settingsLanguage:{zh:"语言",en:"Language"},settingsSaved:{zh:"设置已保存",en:"Settings saved"},settingsSaveFailed:{zh:"设置保存失败",en:"Settings save failed"},batchSelect:{zh:"批量选择",en:"Batch select"},batchInstall:{zh:"批量安装",en:"Batch install"},batchRemove:{zh:"批量卸载",en:"Batch uninstall"},batchUpdate:{zh:"批量更新",en:"Batch update"},batchSelected:{zh:"已选 {n} 个",en:"{n} selected"},batchInstallConfirm:{zh:"确定要批量安装 {n} 个仓库吗？",en:"Install {n} repositories?"},batchRemoveConfirm:{zh:"确定要批量卸载 {n} 个仓库吗？",en:"Uninstall {n} repositories?"},batchInProgress:{zh:"批量操作进行中…",en:"Batch operation in progress…"},batchComplete:{zh:"批量操作完成",en:"Batch complete"},quickInstallTitle:{zh:"快捷安装",en:"Quick Install"},quickInstallDetected:{zh:"检测到 GitHub URL",en:"Detected GitHub URL"},quickInstallDetectedDesc:{zh:"是否要安装此仓库？",en:"Install this repository?"},quickInstallAuto:{zh:"自动识别",en:"Auto detect"},addIntegration:{zh:"配置",en:"Configure"},addIntegrationHint:{zh:"配置此 HA 集成",en:"Configure this HA integration"},addHAIntegration:{zh:"添加 HA 集成",en:"Add HA Integration"},addHAIntegrationDesc:{zh:"搜索并添加 Home Assistant 内置或自定义集成",en:"Search and add Home Assistant built-in or custom integrations"},searchIntegration:{zh:"搜索集成...",en:"Search integration..."},noIntegrationMatch:{zh:"没有匹配的集成",en:"No matching integration"},integrationCount:{zh:"个可用集成",en:"available integrations"},filterAll:{zh:"全部",en:"All"},filterLoaded:{zh:"已加载",en:"Loaded"},filterFailed:{zh:"加载失败",en:"Failed"},filterDisabled:{zh:"已禁用",en:"Disabled"},entryCount:{zh:"个条目",en:" entries"},entryTitle:{zh:"ID: {id}",en:"ID: {id}"},detailEntries:{zh:"{count} 个条目 · 点击 ⚙ 配置",en:"{count} entries · Click ⚙ to configure"},reloadDomain:{zh:"重载此集成全部条目",en:"Reload all entries"},configureEntry:{zh:"配置此条目",en:"Configure this entry"},reloadEntry:{zh:"重载此条目",en:"Reload this entry"},removeEntry:{zh:"删除此条目",en:"Remove this entry"},entryDisabled:{zh:"已禁用",en:"Disabled"},viewDetail:{zh:"查看详情",en:"View details"},loadFailed:{zh:"加载集成列表失败",en:"Failed to load integrations"},reloaded:{zh:"已重载",en:"Reloaded"},reloadFailed:{zh:"重载失败",en:"Reload failed"},checkUpdates:{zh:"检查更新",en:"Check Updates"},checkUpdatesNotify:{zh:"检查并通知",en:"Check & Notify"},updatesChecked:{zh:"检查完成，{n} 个可更新",en:"Check done, {n} updates"},noUpdatesFound:{zh:"所有仓库已是最新",en:"All repositories up to date"},notifySent:{zh:"通知已发送",en:"Notification sent"},flowTitle:{zh:"配置 HA 集成",en:"Configure HA Integration"},flowTitleOptions:{zh:"选项配置",en:"Options Configuration"},subentryTitle:{zh:"子项配置",en:"Subentry Configuration"},subentrySelectDesc:{zh:"请选择要配置的子项类型：",en:"Select a subentry type to configure:"},subentryExisting:{zh:"已有子项",en:"Existing Subentries"},subentryAddNew:{zh:"添加新子项",en:"Add New Subentry"},subentryAddPrefix:{zh:"添加",en:"Add"},subentryReconfigure:{zh:"配置",en:"Configure"},subentryConversation:{zh:"对话",en:"Conversation"},subentryTts:{zh:"语音合成",en:"Text-to-Speech"},subentryStt:{zh:"语音识别",en:"Speech-to-Text"},subentryTranslation:{zh:"翻译",en:"Translation"},subentryAiTaskData:{zh:"AI 任务数据",en:"AI Task Data"},subentryDevice:{zh:"MQTT 设备",en:"MQTT Device"},subentryWecom:{zh:"企业微信",en:"WeCom"},subentryWechat:{zh:"微信",en:"WeChat"},subentryQq:{zh:"QQ",en:"QQ"},subentryFeishu:{zh:"飞书",en:"Feishu"},subentryDingtalk:{zh:"钉钉",en:"DingTalk"},subentryXiaoyi:{zh:"小懿",en:"XiaoYi"},subentryCustom:{zh:"自定义",en:"Custom"},flowProcessing:{zh:"处理中...",en:"Processing..."},flowStarting:{zh:"启动配置流程...",en:"Starting configuration..."},flowSubmit:{zh:"提交",en:"Submit"},flowSelectOption:{zh:"--- 请选择 ---",en:"--- Select ---"},flowOptionsNotSupported:{zh:"此集成无需配置",en:"This integration does not require configuration"},flowHandlerNotFound:{zh:"未找到此集成的配置流程",en:"Configuration handler not found"},flowAuthError:{zh:"认证失败，请刷新页面后重试",en:"Authentication failed. Please refresh and try again"},flowTimeout:{zh:"配置超时，请重试",en:"Configuration timed out, please try again"},selectEntryTitle:{zh:"选择集成实例",en:"Select Entry"},selectEntrySubtitle:{zh:"此集成有多个实例，请选择要配置的实例",en:"Multiple instances found, please select one to configure"},currentEntry:{zh:"当前",en:"Current"},flowSubmitFailed:{zh:"提交失败",en:"Submit failed"},flowUnknownType:{zh:"集成返回了未知流程类型（{type}），请前往设备与服务完成配置。",en:"Unknown flow type ({type}). Please configure in Devices & Services."},flowExternalAuth:{zh:"此集成需要外部认证，请在打开的页面中完成授权。",en:"This integration requires external authentication. Please complete authorization in the opened page."},flowStepNext:{zh:"下一步",en:"Next"},flowStepFinish:{zh:"完成",en:"Finish"},flowCancel:{zh:"取消",en:"Cancel"},flowBack:{zh:"← 返回",en:"← Back"},flowClose:{zh:"关闭",en:"Close"},flowDone:{zh:"完成",en:"Done"},flowGotIt:{zh:"知道了",en:"Got it"},flowResultCreated:{zh:"配置完成",en:"Setup Complete"},flowResultCreatedDesc:{zh:"集成已成功添加到设备与服务",en:"Integration has been added to Devices & Services"},flowResultAborted:{zh:"无需配置",en:"Skipped"},flowResultAbortedDesc:{zh:"该集成已被跳过",en:"Integration was skipped"},flowResultExternal:{zh:"外部认证",en:"External Authentication"},flowResultExternalDesc:{zh:"请在外部页面完成授权。",en:"Please authorize in the external page."},flowResultFailed:{zh:"配置失败",en:"Setup Failed"},flowResultFailedDesc:{zh:"请稍后在设备与服务中重试",en:"Please retry in Devices & Services"},flowAbortAlreadyConfigured:{zh:"该集成已在设备与服务中配置",en:"Already configured in Devices & Services"},flowAbortSingleInstance:{zh:"此集成只允许配置一次",en:"Only one instance allowed"},flowAbortNoDevices:{zh:"未找到可配置的设备",en:"No devices found"},flowAbortInProgress:{zh:"已有进行中的流程",en:"Flow already in progress"},flowOpenAuthPage:{zh:"打开认证页面 ↗",en:"Open auth page ↗"}};function ge(e,t){const i=he[e];if(!i)return e;let o=i[pe]||i.zh||i.en||e;if(t)for(const[e,i]of Object.entries(t))o=o.replace(new RegExp(`\\{${e}\\}`,"g"),i);return o}const ue={integration:"#1565c0",plugin:"#7b1fa2",theme:"#2e7d32",appdaemon:"#e65100",netdaemon:"#00838f",python_script:"#f9a825",template:"#6a1b9a",dashboard:"#f57f17"};function fe(e){return ue[e]||"#03a9f4"}function me(){return a`
  /* ===== Loading ===== */
  .loading {
    text-align: center; padding: 60px 20px;
    color: var(--secondary-text-color, #727272);
  }
  .spinner {
    width: 36px; height: 36px;
    border: 3px solid var(--divider-color, #e0e0e0);
    border-top-color: var(--primary-color, #03a9f4);
    border-radius: 50%;
    animation: spin 1s linear infinite;
    margin: 0 auto 16px;
  }
  .spinner-sm {
    width: 20px; height: 20px;
    border: 2px solid var(--divider-color, #e0e0e0);
    border-top-color: var(--primary-color, #03a9f4);
    border-radius: 50%;
    animation: spin 1s linear infinite;
    margin: 0 auto 8px;
  }
  @keyframes spin {
    from { transform: rotate(0deg); }
    to { transform: rotate(360deg); }
  }

  /* ===== Empty ===== */
  .empty {
    text-align: center; padding: 60px 20px;
    color: var(--secondary-text-color, #727272);
  }
  .empty svg { width: 60px; height: 60px; margin-bottom: 16px; opacity: 0.3; }

  /* ===== Info Bar ===== */
  .info-bar {
    display: flex; justify-content: space-between; align-items: center;
    margin-bottom: 12px; padding: 8px 14px;
    background: var(--secondary-background-color, #f0f0f0);
    border-radius: 8px;
    font-size: 13px; color: var(--secondary-text-color, #727272);
  }
  .info-bar .count { font-weight: 600; color: var(--primary-text-color, #212121); }

  /* ===== Buttons ===== */
  .btn {
    padding: 6px 12px;
    border: 1px solid var(--divider-color, #e0e0e0);
    border-radius: 8px;
    background: var(--card-background-color, #fff);
    color: var(--primary-text-color, #212121);
    cursor: pointer; font-size: 12px;
    transition: all 0.2s; white-space: nowrap;
    touch-action: manipulation;
  }
  .btn:hover { border-color: var(--primary-color, #03a9f4); color: var(--primary-color, #03a9f4); }
  .btn.primary { background: var(--primary-color, #03a9f4); border-color: var(--primary-color, #03a9f4); color: #fff; }
  .btn.primary:hover { opacity: 0.9; }
  .btn.danger { color: #f44336; border-color: #f44336; }
  .btn.danger:hover { background: #f44336; color: #fff; }
  .btn:disabled { opacity: 0.5; cursor: not-allowed; }

  /* ===== Search ===== */
  .search { flex: 1; min-width: 120px; position: relative; }
  .search input {
    width: 100%; box-sizing: border-box; padding: 10px 36px 10px 40px;
    border: 1px solid var(--divider-color, #e0e0e0);
    border-radius: 10px; font-size: 14px;
    background: var(--card-background-color, #fff);
    color: var(--primary-text-color, #212121);
    outline: none; transition: border-color 0.2s;
  }
  .search input:focus { border-color: var(--primary-color, #03a9f4); }
  .search input::placeholder { color: var(--secondary-text-color, #727272); }
  .search-icon {
    position: absolute; left: 12px; top: 50%; transform: translateY(-50%);
    width: 16px; height: 16px; color: var(--secondary-text-color, #727272);
  }
  .search-clear {
    position: absolute; right: 10px; top: 50%; transform: translateY(-50%);
    width: 20px; height: 20px; border-radius: 50%; border: none;
    background: var(--divider-color, #e0e0e0);
    color: var(--secondary-text-color, #727272);
    cursor: pointer; display: flex; align-items: center; justify-content: center;
    font-size: 12px; transition: all 0.2s;
  }
  .search-clear:hover { background: var(--primary-color, #03a9f4); color: #fff; }

  /* ===== Controls ===== */
  .controls {
    display: flex; align-items: center; gap: 10px;
    margin-bottom: 14px; flex-wrap: wrap;
  }

  /* ===== Grid ===== */
  .grid {
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
    gap: 14px;
  }

  /* ===== Responsive ===== */
  @media (max-width: 768px) {
    .grid { grid-template-columns: 1fr; gap: 10px; }
    .controls { gap: 4px; flex-wrap: wrap; }
    .search input { padding: 7px 10px 7px 34px; font-size: 13px; border-radius: 8px; }
    .search-icon { width: 14px; height: 14px; left: 8px; }
    .btn { min-height: 44px; display: flex; align-items: center; justify-content: center; }
  }

  @media (max-width: 480px) {
    .grid { grid-template-columns: 1fr; gap: 8px; }
    .controls { flex-wrap: wrap; gap: 4px; }
    .info-bar { flex-wrap: wrap; gap: 4px; font-size: 12px; }
  }

  /* ===== Skeleton Loading ===== */
  .skeleton-grid {
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(280px, 1fr));
    gap: 14px;
  }
  .skeleton-card {
    border-radius: 14px; overflow: hidden;
    background: var(--card-background-color, #fff);
    border: 1px solid var(--divider-color, #e0e0e0);
  }
  .skeleton-card-img {
    height: 100px;
    background: var(--secondary-background-color, #f0f0f0);
  }
  .skeleton-card-body {
    padding: 16px;
  }
  .skeleton-line {
    height: 14px; border-radius: 6px; margin-bottom: 12px;
    background: linear-gradient(90deg,
      var(--secondary-background-color, #eee) 25%,
      var(--divider-color, #ddd) 50%,
      var(--secondary-background-color, #eee) 75%);
    background-size: 200% 100%;
    animation: shimmer 1.5s infinite;
  }
  .skeleton-line:last-child { width: 60%; }
  .skeleton-line.wide { width: 100%; }
  .skeleton-line.medium { width: 75%; }
  @keyframes shimmer {
    0% { background-position: 200% 0; }
    100% { background-position: -200% 0; }
  }
`}
/*! @license DOMPurify 3.4.8 | (c) Cure53 and other contributors | Released under the Apache license 2.0 and Mozilla Public License 2.0 | github.com/cure53/DOMPurify/blob/3.4.8/LICENSE */function be(e,t){(null==t||t>e.length)&&(t=e.length);for(var i=0,o=Array(t);i<t;i++)o[i]=e[i];return o}function ve(e,t){return function(e){if(Array.isArray(e))return e}(e)||function(e,t){var i=null==e?null:"undefined"!=typeof Symbol&&e[Symbol.iterator]||e["@@iterator"];if(null!=i){var o,r,a,s,n=[],l=!0,c=!1;try{if(a=(i=i.call(e)).next,0===t);else for(;!(l=(o=a.call(i)).done)&&(n.push(o.value),n.length!==t);l=!0);}catch(e){c=!0,r=e}finally{try{if(!l&&null!=i.return&&(s=i.return(),Object(s)!==s))return}finally{if(c)throw r}}return n}}(e,t)||function(e,t){if(e){if("string"==typeof e)return be(e,t);var i={}.toString.call(e).slice(8,-1);return"Object"===i&&e.constructor&&(i=e.constructor.name),"Map"===i||"Set"===i?Array.from(e):"Arguments"===i||/^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(i)?be(e,t):void 0}}(e,t)||function(){throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.")}()}const xe=Object.entries,ye=Object.setPrototypeOf,_e=Object.isFrozen,we=Object.getPrototypeOf,$e=Object.getOwnPropertyDescriptor;let ke=Object.freeze,Se=Object.seal,ze=Object.create,Ce="undefined"!=typeof Reflect&&Reflect,Ae=Ce.apply,Re=Ce.construct;ke||(ke=function(e){return e}),Se||(Se=function(e){return e}),Ae||(Ae=function(e,t){for(var i=arguments.length,o=new Array(i>2?i-2:0),r=2;r<i;r++)o[r-2]=arguments[r];return e.apply(t,o)}),Re||(Re=function(e){for(var t=arguments.length,i=new Array(t>1?t-1:0),o=1;o<t;o++)i[o-1]=arguments[o];return new e(...i)});const Te=Ze(Array.prototype.forEach),Ee=Ze(Array.prototype.lastIndexOf),De=Ze(Array.prototype.pop),Ie=Ze(Array.prototype.push),Fe=Ze(Array.prototype.splice),Le=Array.isArray,Oe=Ze(String.prototype.toLowerCase),Me=Ze(String.prototype.toString),Ne=Ze(String.prototype.match),Ue=Ze(String.prototype.replace),Be=Ze(String.prototype.indexOf),Pe=Ze(String.prototype.trim),He=Ze(Number.prototype.toString),je=Ze(Boolean.prototype.toString),Ve="undefined"==typeof BigInt?null:Ze(BigInt.prototype.toString),qe="undefined"==typeof Symbol?null:Ze(Symbol.prototype.toString),Ge=Ze(Object.prototype.hasOwnProperty),We=Ze(Object.prototype.toString),Ye=Ze(RegExp.prototype.test),Je=(Xe=TypeError,function(){for(var e=arguments.length,t=new Array(e),i=0;i<e;i++)t[i]=arguments[i];return Re(Xe,t)});var Xe;function Ze(e){return function(t){t instanceof RegExp&&(t.lastIndex=0);for(var i=arguments.length,o=new Array(i>1?i-1:0),r=1;r<i;r++)o[r-1]=arguments[r];return Ae(e,t,o)}}function Ke(e,t){let i=arguments.length>2&&void 0!==arguments[2]?arguments[2]:Oe;if(ye&&ye(e,null),!Le(t))return e;let o=t.length;for(;o--;){let r=t[o];if("string"==typeof r){const e=i(r);e!==r&&(_e(t)||(t[o]=e),r=e)}e[r]=!0}return e}function Qe(e){for(let t=0;t<e.length;t++){Ge(e,t)||(e[t]=null)}return e}function et(e){const t=ze(null);for(const o of xe(e)){var i=ve(o,2);const r=i[0],a=i[1];Ge(e,r)&&(Le(a)?t[r]=Qe(a):a&&"object"==typeof a&&a.constructor===Object?t[r]=et(a):t[r]=a)}return t}function tt(e,t){for(;null!==e;){const i=$e(e,t);if(i){if(i.get)return Ze(i.get);if("function"==typeof i.value)return Ze(i.value)}e=we(e)}return function(){return null}}const it=ke(["a","abbr","acronym","address","area","article","aside","audio","b","bdi","bdo","big","blink","blockquote","body","br","button","canvas","caption","center","cite","code","col","colgroup","content","data","datalist","dd","decorator","del","details","dfn","dialog","dir","div","dl","dt","element","em","fieldset","figcaption","figure","font","footer","form","h1","h2","h3","h4","h5","h6","head","header","hgroup","hr","html","i","img","input","ins","kbd","label","legend","li","main","map","mark","marquee","menu","menuitem","meter","nav","nobr","ol","optgroup","option","output","p","picture","pre","progress","q","rp","rt","ruby","s","samp","search","section","select","shadow","slot","small","source","spacer","span","strike","strong","style","sub","summary","sup","table","tbody","td","template","textarea","tfoot","th","thead","time","tr","track","tt","u","ul","var","video","wbr"]),ot=ke(["svg","a","altglyph","altglyphdef","altglyphitem","animatecolor","animatemotion","animatetransform","circle","clippath","defs","desc","ellipse","enterkeyhint","exportparts","filter","font","g","glyph","glyphref","hkern","image","inputmode","line","lineargradient","marker","mask","metadata","mpath","part","path","pattern","polygon","polyline","radialgradient","rect","stop","style","switch","symbol","text","textpath","title","tref","tspan","view","vkern"]),rt=ke(["feBlend","feColorMatrix","feComponentTransfer","feComposite","feConvolveMatrix","feDiffuseLighting","feDisplacementMap","feDistantLight","feDropShadow","feFlood","feFuncA","feFuncB","feFuncG","feFuncR","feGaussianBlur","feImage","feMerge","feMergeNode","feMorphology","feOffset","fePointLight","feSpecularLighting","feSpotLight","feTile","feTurbulence"]),at=ke(["animate","color-profile","cursor","discard","font-face","font-face-format","font-face-name","font-face-src","font-face-uri","foreignobject","hatch","hatchpath","mesh","meshgradient","meshpatch","meshrow","missing-glyph","script","set","solidcolor","unknown","use"]),st=ke(["math","menclose","merror","mfenced","mfrac","mglyph","mi","mlabeledtr","mmultiscripts","mn","mo","mover","mpadded","mphantom","mroot","mrow","ms","mspace","msqrt","mstyle","msub","msup","msubsup","mtable","mtd","mtext","mtr","munder","munderover","mprescripts"]),nt=ke(["maction","maligngroup","malignmark","mlongdiv","mscarries","mscarry","msgroup","mstack","msline","msrow","semantics","annotation","annotation-xml","mprescripts","none"]),lt=ke(["#text"]),ct=ke(["accept","action","align","alt","autocapitalize","autocomplete","autopictureinpicture","autoplay","background","bgcolor","border","capture","cellpadding","cellspacing","checked","cite","class","clear","color","cols","colspan","command","commandfor","controls","controlslist","coords","crossorigin","datetime","decoding","default","dir","disabled","disablepictureinpicture","disableremoteplayback","download","draggable","enctype","enterkeyhint","exportparts","face","for","headers","height","hidden","high","href","hreflang","id","inert","inputmode","integrity","ismap","kind","label","lang","list","loading","loop","low","max","maxlength","media","method","min","minlength","multiple","muted","name","nonce","noshade","novalidate","nowrap","open","optimum","part","pattern","placeholder","playsinline","popover","popovertarget","popovertargetaction","poster","preload","pubdate","radiogroup","readonly","rel","required","rev","reversed","role","rows","rowspan","spellcheck","scope","selected","shape","size","sizes","slot","span","srclang","start","src","srcset","step","style","summary","tabindex","title","translate","type","usemap","valign","value","width","wrap","xmlns"]),dt=ke(["accent-height","accumulate","additive","alignment-baseline","amplitude","ascent","attributename","attributetype","azimuth","basefrequency","baseline-shift","begin","bias","by","class","clip","clippathunits","clip-path","clip-rule","color","color-interpolation","color-interpolation-filters","color-profile","color-rendering","cx","cy","d","dx","dy","diffuseconstant","direction","display","divisor","dur","edgemode","elevation","end","exponent","fill","fill-opacity","fill-rule","filter","filterunits","flood-color","flood-opacity","font-family","font-size","font-size-adjust","font-stretch","font-style","font-variant","font-weight","fx","fy","g1","g2","glyph-name","glyphref","gradientunits","gradienttransform","height","href","id","image-rendering","in","in2","intercept","k","k1","k2","k3","k4","kerning","keypoints","keysplines","keytimes","lang","lengthadjust","letter-spacing","kernelmatrix","kernelunitlength","lighting-color","local","marker-end","marker-mid","marker-start","markerheight","markerunits","markerwidth","maskcontentunits","maskunits","max","mask","mask-type","media","method","mode","min","name","numoctaves","offset","operator","opacity","order","orient","orientation","origin","overflow","paint-order","path","pathlength","patterncontentunits","patterntransform","patternunits","points","preservealpha","preserveaspectratio","primitiveunits","r","rx","ry","radius","refx","refy","repeatcount","repeatdur","restart","result","rotate","scale","seed","shape-rendering","slope","specularconstant","specularexponent","spreadmethod","startoffset","stddeviation","stitchtiles","stop-color","stop-opacity","stroke-dasharray","stroke-dashoffset","stroke-linecap","stroke-linejoin","stroke-miterlimit","stroke-opacity","stroke","stroke-width","style","surfacescale","systemlanguage","tabindex","tablevalues","targetx","targety","transform","transform-origin","text-anchor","text-decoration","text-rendering","textlength","type","u1","u2","unicode","values","viewbox","visibility","version","vert-adv-y","vert-origin-x","vert-origin-y","width","word-spacing","wrap","writing-mode","xchannelselector","ychannelselector","x","x1","x2","xmlns","y","y1","y2","z","zoomandpan"]),pt=ke(["accent","accentunder","align","bevelled","close","columnalign","columnlines","columnspacing","columnspan","denomalign","depth","dir","display","displaystyle","encoding","fence","frame","height","href","id","largeop","length","linethickness","lquote","lspace","mathbackground","mathcolor","mathsize","mathvariant","maxsize","minsize","movablelimits","notation","numalign","open","rowalign","rowlines","rowspacing","rowspan","rspace","rquote","scriptlevel","scriptminsize","scriptsizemultiplier","selection","separator","separators","stretchy","subscriptshift","supscriptshift","symmetric","voffset","width","xmlns"]),ht=ke(["xlink:href","xml:id","xlink:title","xml:space","xmlns:xlink"]),gt=Se(/{{[\w\W]*|^[\w\W]*}}/g),ut=Se(/<%[\w\W]*|^[\w\W]*%>/g),ft=Se(/\${[\w\W]*/g),mt=Se(/^data-[\-\w.\u00B7-\uFFFF]+$/),bt=Se(/^aria-[\-\w]+$/),vt=Se(/^(?:(?:(?:f|ht)tps?|mailto|tel|callto|sms|cid|xmpp|matrix):|[^a-z]|[a-z+.\-]+(?:[^a-z+.\-:]|$))/i),xt=Se(/^(?:\w+script|data):/i),yt=Se(/[\u0000-\u0020\u00A0\u1680\u180E\u2000-\u2029\u205F\u3000]/g),_t=Se(/^html$/i),wt=Se(/^[a-z][.\w]*(-[.\w]+)+$/i),$t=1,kt=3,St=7,zt=8,Ct=9,At=11,Rt=function(){return"undefined"==typeof window?null:window};var Tt=function e(){let t=arguments.length>0&&void 0!==arguments[0]?arguments[0]:Rt();const i=t=>e(t);if(i.version="3.4.8",i.removed=[],!t||!t.document||t.document.nodeType!==Ct||!t.Element)return i.isSupported=!1,i;let o=t.document;const r=o,a=r.currentScript;t.DocumentFragment;const s=t.HTMLTemplateElement,n=t.Node,l=t.Element,c=t.NodeFilter,d=t.NamedNodeMap;void 0===d&&(t.NamedNodeMap||t.MozNamedAttrMap),t.HTMLFormElement;const p=t.DOMParser,h=t.trustedTypes,g=l.prototype,u=tt(g,"cloneNode"),f=tt(g,"remove"),m=tt(g,"nextSibling"),b=tt(g,"childNodes"),v=tt(g,"parentNode"),x=tt(g,"shadowRoot"),y=tt(g,"attributes"),_=n&&n.prototype?tt(n.prototype,"nodeType"):null,w=n&&n.prototype?tt(n.prototype,"nodeName"):null;if("function"==typeof s){const e=o.createElement("template");e.content&&e.content.ownerDocument&&(o=e.content.ownerDocument)}let $,k="",S=0;const z=function(e){if(S>0)throw Je('The configured TRUSTED_TYPES_POLICY.createHTML must not call DOMPurify.sanitize, as that causes infinite recursion. Do not pass a policy whose createHTML wraps DOMPurify as TRUSTED_TYPES_POLICY; see the "DOMPurify and Trusted Types" section of the README.');S++;try{return $.createHTML(e)}finally{S--}},C=o,A=C.implementation,R=C.createNodeIterator,T=C.createDocumentFragment,E=C.getElementsByTagName,D=r.importNode;let I={afterSanitizeAttributes:[],afterSanitizeElements:[],afterSanitizeShadowDOM:[],beforeSanitizeAttributes:[],beforeSanitizeElements:[],beforeSanitizeShadowDOM:[],uponSanitizeAttribute:[],uponSanitizeElement:[],uponSanitizeShadowNode:[]};i.isSupported="function"==typeof xe&&"function"==typeof v&&A&&void 0!==A.createHTMLDocument;const F=gt,L=ut,O=ft,M=mt,N=bt,U=xt,B=yt,P=wt;let H=vt,j=null;const V=Ke({},[...it,...ot,...rt,...st,...lt]);let q=null;const G=Ke({},[...ct,...dt,...pt,...ht]);let W=Object.seal(ze(null,{tagNameCheck:{writable:!0,configurable:!1,enumerable:!0,value:null},attributeNameCheck:{writable:!0,configurable:!1,enumerable:!0,value:null},allowCustomizedBuiltInElements:{writable:!0,configurable:!1,enumerable:!0,value:!1}})),Y=null,J=null;const X=Object.seal(ze(null,{tagCheck:{writable:!0,configurable:!1,enumerable:!0,value:null},attributeCheck:{writable:!0,configurable:!1,enumerable:!0,value:null}}));let Z=!0,K=!0,Q=!1,ee=!0,te=!1,ie=!0,oe=!1,re=!1,ae=!1,se=!1,ne=!1,le=!1,ce=!0,de=!1;const pe="user-content-";let he=!0,ge=!1,ue={},fe=null;const me=Ke({},["annotation-xml","audio","colgroup","desc","foreignobject","head","iframe","math","mi","mn","mo","ms","mtext","noembed","noframes","noscript","plaintext","script","style","svg","template","thead","title","video","xmp"]);let be=null;const ve=Ke({},["audio","video","img","source","image","track"]);let ye=null;const _e=Ke({},["alt","class","for","id","label","name","pattern","placeholder","role","summary","title","value","style","xmlns"]),we="http://www.w3.org/1998/Math/MathML",$e="http://www.w3.org/2000/svg",Se="http://www.w3.org/1999/xhtml";let Ce=Se,Ae=!1,Re=null;const Xe=Ke({},[we,$e,Se],Me);let Ze=Ke({},["mi","mo","mn","ms","mtext"]),Qe=Ke({},["annotation-xml"]);const Tt=Ke({},["title","style","font","a","script"]);let Et=null;const Dt=["application/xhtml+xml","text/html"];let It=null,Ft=null;const Lt=o.createElement("form"),Ot=function(e){return e instanceof RegExp||e instanceof Function},Mt=function(){let e=arguments.length>0&&void 0!==arguments[0]?arguments[0]:{};if(Ft&&Ft===e)return;e&&"object"==typeof e||(e={}),e=et(e),Et=-1===Dt.indexOf(e.PARSER_MEDIA_TYPE)?"text/html":e.PARSER_MEDIA_TYPE,It="application/xhtml+xml"===Et?Me:Oe,j=Ge(e,"ALLOWED_TAGS")&&Le(e.ALLOWED_TAGS)?Ke({},e.ALLOWED_TAGS,It):V,q=Ge(e,"ALLOWED_ATTR")&&Le(e.ALLOWED_ATTR)?Ke({},e.ALLOWED_ATTR,It):G,Re=Ge(e,"ALLOWED_NAMESPACES")&&Le(e.ALLOWED_NAMESPACES)?Ke({},e.ALLOWED_NAMESPACES,Me):Xe,ye=Ge(e,"ADD_URI_SAFE_ATTR")&&Le(e.ADD_URI_SAFE_ATTR)?Ke(et(_e),e.ADD_URI_SAFE_ATTR,It):_e,be=Ge(e,"ADD_DATA_URI_TAGS")&&Le(e.ADD_DATA_URI_TAGS)?Ke(et(ve),e.ADD_DATA_URI_TAGS,It):ve,fe=Ge(e,"FORBID_CONTENTS")&&Le(e.FORBID_CONTENTS)?Ke({},e.FORBID_CONTENTS,It):me,Y=Ge(e,"FORBID_TAGS")&&Le(e.FORBID_TAGS)?Ke({},e.FORBID_TAGS,It):et({}),J=Ge(e,"FORBID_ATTR")&&Le(e.FORBID_ATTR)?Ke({},e.FORBID_ATTR,It):et({}),ue=!!Ge(e,"USE_PROFILES")&&(e.USE_PROFILES&&"object"==typeof e.USE_PROFILES?et(e.USE_PROFILES):e.USE_PROFILES),Z=!1!==e.ALLOW_ARIA_ATTR,K=!1!==e.ALLOW_DATA_ATTR,Q=e.ALLOW_UNKNOWN_PROTOCOLS||!1,ee=!1!==e.ALLOW_SELF_CLOSE_IN_ATTR,te=e.SAFE_FOR_TEMPLATES||!1,ie=!1!==e.SAFE_FOR_XML,oe=e.WHOLE_DOCUMENT||!1,se=e.RETURN_DOM||!1,ne=e.RETURN_DOM_FRAGMENT||!1,le=e.RETURN_TRUSTED_TYPE||!1,ae=e.FORCE_BODY||!1,ce=!1!==e.SANITIZE_DOM,de=e.SANITIZE_NAMED_PROPS||!1,he=!1!==e.KEEP_CONTENT,ge=e.IN_PLACE||!1,H=function(e){try{return Ye(e,""),!0}catch(e){return!1}}(e.ALLOWED_URI_REGEXP)?e.ALLOWED_URI_REGEXP:vt,Ce="string"==typeof e.NAMESPACE?e.NAMESPACE:Se,Ze=Ge(e,"MATHML_TEXT_INTEGRATION_POINTS")&&e.MATHML_TEXT_INTEGRATION_POINTS&&"object"==typeof e.MATHML_TEXT_INTEGRATION_POINTS?et(e.MATHML_TEXT_INTEGRATION_POINTS):Ke({},["mi","mo","mn","ms","mtext"]),Qe=Ge(e,"HTML_INTEGRATION_POINTS")&&e.HTML_INTEGRATION_POINTS&&"object"==typeof e.HTML_INTEGRATION_POINTS?et(e.HTML_INTEGRATION_POINTS):Ke({},["annotation-xml"]);const t=Ge(e,"CUSTOM_ELEMENT_HANDLING")&&e.CUSTOM_ELEMENT_HANDLING&&"object"==typeof e.CUSTOM_ELEMENT_HANDLING?et(e.CUSTOM_ELEMENT_HANDLING):ze(null);if(W=ze(null),Ge(t,"tagNameCheck")&&Ot(t.tagNameCheck)&&(W.tagNameCheck=t.tagNameCheck),Ge(t,"attributeNameCheck")&&Ot(t.attributeNameCheck)&&(W.attributeNameCheck=t.attributeNameCheck),Ge(t,"allowCustomizedBuiltInElements")&&"boolean"==typeof t.allowCustomizedBuiltInElements&&(W.allowCustomizedBuiltInElements=t.allowCustomizedBuiltInElements),te&&(K=!1),ne&&(se=!0),ue&&(j=Ke({},lt),q=ze(null),!0===ue.html&&(Ke(j,it),Ke(q,ct)),!0===ue.svg&&(Ke(j,ot),Ke(q,dt),Ke(q,ht)),!0===ue.svgFilters&&(Ke(j,rt),Ke(q,dt),Ke(q,ht)),!0===ue.mathMl&&(Ke(j,st),Ke(q,pt),Ke(q,ht))),X.tagCheck=null,X.attributeCheck=null,Ge(e,"ADD_TAGS")&&("function"==typeof e.ADD_TAGS?X.tagCheck=e.ADD_TAGS:Le(e.ADD_TAGS)&&(j===V&&(j=et(j)),Ke(j,e.ADD_TAGS,It))),Ge(e,"ADD_ATTR")&&("function"==typeof e.ADD_ATTR?X.attributeCheck=e.ADD_ATTR:Le(e.ADD_ATTR)&&(q===G&&(q=et(q)),Ke(q,e.ADD_ATTR,It))),Ge(e,"ADD_URI_SAFE_ATTR")&&Le(e.ADD_URI_SAFE_ATTR)&&Ke(ye,e.ADD_URI_SAFE_ATTR,It),Ge(e,"FORBID_CONTENTS")&&Le(e.FORBID_CONTENTS)&&(fe===me&&(fe=et(fe)),Ke(fe,e.FORBID_CONTENTS,It)),Ge(e,"ADD_FORBID_CONTENTS")&&Le(e.ADD_FORBID_CONTENTS)&&(fe===me&&(fe=et(fe)),Ke(fe,e.ADD_FORBID_CONTENTS,It)),he&&(j["#text"]=!0),oe&&Ke(j,["html","head","body"]),j.table&&(Ke(j,["tbody"]),delete Y.tbody),e.TRUSTED_TYPES_POLICY){if("function"!=typeof e.TRUSTED_TYPES_POLICY.createHTML)throw Je('TRUSTED_TYPES_POLICY configuration option must provide a "createHTML" hook.');if("function"!=typeof e.TRUSTED_TYPES_POLICY.createScriptURL)throw Je('TRUSTED_TYPES_POLICY configuration option must provide a "createScriptURL" hook.');const t=$;$=e.TRUSTED_TYPES_POLICY;try{k=z("")}catch(e){throw $=t,e}}else void 0===$&&null!==e.TRUSTED_TYPES_POLICY&&($=function(e,t){if("object"!=typeof e||"function"!=typeof e.createPolicy)return null;let i=null;const o="data-tt-policy-suffix";t&&t.hasAttribute(o)&&(i=t.getAttribute(o));const r="dompurify"+(i?"#"+i:"");try{return e.createPolicy(r,{createHTML:e=>e,createScriptURL:e=>e})}catch(e){return console.warn("TrustedTypes policy "+r+" could not be created."),null}}(h,a)),$&&"string"==typeof k&&(k=z(""));(I.uponSanitizeElement.length>0||I.uponSanitizeAttribute.length>0)&&j===V&&(j=et(j)),I.uponSanitizeAttribute.length>0&&q===G&&(q=et(q)),ke&&ke(e),Ft=e},Nt=Ke({},[...ot,...rt,...at]),Ut=Ke({},[...st,...nt]),Bt=function(e){Ie(i.removed,{element:e});try{v(e).removeChild(e)}catch(t){f(e)}},Pt=function(e,t){try{Ie(i.removed,{attribute:t.getAttributeNode(e),from:t})}catch(e){Ie(i.removed,{attribute:null,from:t})}if(t.removeAttribute(e),"is"===e)if(se||ne)try{Bt(t)}catch(e){}else try{t.setAttribute(e,"")}catch(e){}},Ht=function(e){let t=null,i=null;if(ae)e="<remove></remove>"+e;else{const t=Ne(e,/^[\r\n\t ]+/);i=t&&t[0]}"application/xhtml+xml"===Et&&Ce===Se&&(e='<html xmlns="http://www.w3.org/1999/xhtml"><head></head><body>'+e+"</body></html>");const r=$?z(e):e;if(Ce===Se)try{t=(new p).parseFromString(r,Et)}catch(e){}if(!t||!t.documentElement){t=A.createDocument(Ce,"template",null);try{t.documentElement.innerHTML=Ae?k:r}catch(e){}}const a=t.body||t.documentElement;return e&&i&&a.insertBefore(o.createTextNode(i),a.childNodes[0]||null),Ce===Se?E.call(t,oe?"html":"body")[0]:oe?t.documentElement:a},jt=function(e){return R.call(e.ownerDocument||e,e,c.SHOW_ELEMENT|c.SHOW_COMMENT|c.SHOW_TEXT|c.SHOW_PROCESSING_INSTRUCTION|c.SHOW_CDATA_SECTION,null)},Vt=function(e){var t,i;e.normalize();const o=R.call(e.ownerDocument||e,e,c.SHOW_TEXT|c.SHOW_COMMENT|c.SHOW_CDATA_SECTION|c.SHOW_PROCESSING_INSTRUCTION,null);let r=o.nextNode();for(;r;){let e=r.data;Te([F,L,O],t=>{e=Ue(e,t," ")}),r.data=e,r=o.nextNode()}const a=null!==(t=null===(i=e.querySelectorAll)||void 0===i?void 0:i.call(e,"template"))&&void 0!==t?t:[];Te(Array.from(a),e=>{Gt(e.content)&&Vt(e.content)})},qt=function(e){const t=w?w(e):null;return"string"==typeof t&&("form"===It(t)&&("string"!=typeof e.nodeName||"string"!=typeof e.textContent||"function"!=typeof e.removeChild||e.attributes!==y(e)||"function"!=typeof e.removeAttribute||"function"!=typeof e.setAttribute||"string"!=typeof e.namespaceURI||"function"!=typeof e.insertBefore||"function"!=typeof e.hasChildNodes||e.nodeType!==_(e)||e.childNodes!==b(e)))},Gt=function(e){if(!_||"object"!=typeof e||null===e)return!1;try{return _(e)===At}catch(e){return!1}},Wt=function(e){if(!_||"object"!=typeof e||null===e)return!1;try{return"number"==typeof _(e)}catch(e){return!1}};function Yt(e,t,o){Te(e,e=>{e.call(i,t,o,Ft)})}const Jt=function(e){let t=null;if(Yt(I.beforeSanitizeElements,e,null),qt(e))return Bt(e),!0;const o=It(w?w(e):e.nodeName);if(Yt(I.uponSanitizeElement,e,{tagName:o,allowedTags:j}),ie&&e.hasChildNodes()&&!Wt(e.firstElementChild)&&Ye(/<[/\w!]/g,e.innerHTML)&&Ye(/<[/\w!]/g,e.textContent))return Bt(e),!0;if(ie&&e.namespaceURI===Se&&"style"===o&&Wt(e.firstElementChild))return Bt(e),!0;if(e.nodeType===St)return Bt(e),!0;if(ie&&e.nodeType===zt&&Ye(/<[/\w]/g,e.data))return Bt(e),!0;if(Y[o]||!(X.tagCheck instanceof Function&&X.tagCheck(o))&&!j[o]){if(!Y[o]&&Kt(o)){if(W.tagNameCheck instanceof RegExp&&Ye(W.tagNameCheck,o))return!1;if(W.tagNameCheck instanceof Function&&W.tagNameCheck(o))return!1}if(he&&!fe[o]){const t=v(e),i=b(e);if(i&&t){for(let o=i.length-1;o>=0;--o){const r=u(i[o],!0);t.insertBefore(r,m(e))}}}return Bt(e),!0}return((_?_(e):e.nodeType)!==$t||function(e){let t=v(e);t&&t.tagName||(t={namespaceURI:Ce,tagName:"template"});const i=Oe(e.tagName),o=Oe(t.tagName);return!!Re[e.namespaceURI]&&(e.namespaceURI===$e?t.namespaceURI===Se?"svg"===i:t.namespaceURI===we?"svg"===i&&("annotation-xml"===o||Ze[o]):Boolean(Nt[i]):e.namespaceURI===we?t.namespaceURI===Se?"math"===i:t.namespaceURI===$e?"math"===i&&Qe[o]:Boolean(Ut[i]):e.namespaceURI===Se?!(t.namespaceURI===$e&&!Qe[o])&&!(t.namespaceURI===we&&!Ze[o])&&!Ut[i]&&(Tt[i]||!Nt[i]):!("application/xhtml+xml"!==Et||!Re[e.namespaceURI]))}(e))&&("noscript"!==o&&"noembed"!==o&&"noframes"!==o||!Ye(/<\/no(script|embed|frames)/i,e.innerHTML))?(te&&e.nodeType===kt&&(t=e.textContent,Te([F,L,O],e=>{t=Ue(t,e," ")}),e.textContent!==t&&(Ie(i.removed,{element:e.cloneNode()}),e.textContent=t)),Yt(I.afterSanitizeElements,e,null),!1):(Bt(e),!0)},Xt=function(e,t,i){if(J[t])return!1;if(ce&&("id"===t||"name"===t)&&(i in o||i in Lt))return!1;const r=q[t]||X.attributeCheck instanceof Function&&X.attributeCheck(t,e);if(K&&!J[t]&&Ye(M,t));else if(Z&&Ye(N,t));else if(!r||J[t]){if(!(Kt(e)&&(W.tagNameCheck instanceof RegExp&&Ye(W.tagNameCheck,e)||W.tagNameCheck instanceof Function&&W.tagNameCheck(e))&&(W.attributeNameCheck instanceof RegExp&&Ye(W.attributeNameCheck,t)||W.attributeNameCheck instanceof Function&&W.attributeNameCheck(t,e))||"is"===t&&W.allowCustomizedBuiltInElements&&(W.tagNameCheck instanceof RegExp&&Ye(W.tagNameCheck,i)||W.tagNameCheck instanceof Function&&W.tagNameCheck(i))))return!1}else if(ye[t]);else if(Ye(H,Ue(i,B,"")));else if("src"!==t&&"xlink:href"!==t&&"href"!==t||"script"===e||0!==Be(i,"data:")||!be[e]){if(Q&&!Ye(U,Ue(i,B,"")));else if(i)return!1}else;return!0},Zt=Ke({},["annotation-xml","color-profile","font-face","font-face-format","font-face-name","font-face-src","font-face-uri","missing-glyph"]),Kt=function(e){return!Zt[Oe(e)]&&Ye(P,e)},Qt=function(e){Yt(I.beforeSanitizeAttributes,e,null);const t=e.attributes;if(!t||qt(e))return;const o={attrName:"",attrValue:"",keepAttr:!0,allowedAttributes:q,forceKeepAttr:void 0};let r=t.length;for(;r--;){const a=t[r],s=a.name,n=a.namespaceURI,l=a.value,c=It(s),d=l;let p="value"===s?d:Pe(d);if(o.attrName=c,o.attrValue=p,o.keepAttr=!0,o.forceKeepAttr=void 0,Yt(I.uponSanitizeAttribute,e,o),p=o.attrValue,!de||"id"!==c&&"name"!==c||0===Be(p,pe)||(Pt(s,e),p=pe+p),ie&&Ye(/((--!?|])>)|<\/(style|script|title|xmp|textarea|noscript|iframe|noembed|noframes)/i,p)){Pt(s,e);continue}if("attributename"===c&&Ne(p,"href")){Pt(s,e);continue}if(o.forceKeepAttr)continue;if(!o.keepAttr){Pt(s,e);continue}if(!ee&&Ye(/\/>/i,p)){Pt(s,e);continue}te&&Te([F,L,O],e=>{p=Ue(p,e," ")});const g=It(e.nodeName);if(Xt(g,c,p)){if($&&"object"==typeof h&&"function"==typeof h.getAttributeType)if(n);else switch(h.getAttributeType(g,c)){case"TrustedHTML":p=z(p);break;case"TrustedScriptURL":p=$.createScriptURL(p)}if(p!==d)try{n?e.setAttributeNS(n,s,p):e.setAttribute(s,p),qt(e)?Bt(e):De(i.removed)}catch(t){Pt(s,e)}}else Pt(s,e)}Yt(I.afterSanitizeAttributes,e,null)},ei=function(e){let t=null;const i=jt(e);for(Yt(I.beforeSanitizeShadowDOM,e,null);t=i.nextNode();){Yt(I.uponSanitizeShadowNode,t,null),Jt(t),Qt(t),Gt(t.content)&&ei(t.content);if((_?_(t):t.nodeType)===$t){const e=x?x(t):t.shadowRoot;Gt(e)&&(ti(e),ei(e))}}Yt(I.afterSanitizeShadowDOM,e,null)},ti=function(e){const t=_?_(e):e.nodeType;if(t===$t){const t=x?x(e):e.shadowRoot;Gt(t)&&(ti(t),ei(t))}const i=b?b(e):e.childNodes;if(!i)return;const o=[];Te(i,e=>{Ie(o,e)});for(const e of o)ti(e);if(t===$t){const t=w?w(e):null;if("string"==typeof t&&"template"===It(t)){const t=e.content;Gt(t)&&ti(t)}}};return i.sanitize=function(e){let t=arguments.length>1&&void 0!==arguments[1]?arguments[1]:{},o=null,a=null,s=null,n=null;if(Ae=!e,Ae&&(e="\x3c!--\x3e"),"string"!=typeof e&&!Wt(e)&&"string"!=typeof(e=function(e){switch(typeof e){case"string":return e;case"number":return He(e);case"boolean":return je(e);case"bigint":return Ve?Ve(e):"0";case"symbol":return qe?qe(e):"Symbol()";case"undefined":default:return We(e);case"function":case"object":{if(null===e)return We(e);const t=e,i=tt(t,"toString");if("function"==typeof i){const e=i(t);return"string"==typeof e?e:We(e)}return We(e)}}}(e)))throw Je("dirty is not a string, aborting");if(!i.isSupported)return e;if(re||Mt(t),i.removed=[],"string"==typeof e&&(ge=!1),ge){const t=w?w(e):e.nodeName;if("string"==typeof t){const e=It(t);if(!j[e]||Y[e])throw Je("root node is forbidden and cannot be sanitized in-place")}if(qt(e))throw Je("root node is clobbered and cannot be sanitized in-place");ti(e)}else if(Wt(e))o=Ht("\x3c!----\x3e"),a=o.ownerDocument.importNode(e,!0),a.nodeType===$t&&"BODY"===a.nodeName||"HTML"===a.nodeName?o=a:o.appendChild(a),ti(a);else{if(!se&&!te&&!oe&&-1===e.indexOf("<"))return $&&le?z(e):e;if(o=Ht(e),!o)return se?null:le?k:""}o&&ae&&Bt(o.firstChild);const l=jt(ge?e:o);for(;s=l.nextNode();)Jt(s),Qt(s),Gt(s.content)&&ei(s.content);if(ge)return te&&Vt(e),e;if(se){if(te&&Vt(o),ne)for(n=T.call(o.ownerDocument);o.firstChild;)n.appendChild(o.firstChild);else n=o;return(q.shadowroot||q.shadowrootmode)&&(n=D.call(r,n,!0)),n}let c=oe?o.outerHTML:o.innerHTML;return oe&&j["!doctype"]&&o.ownerDocument&&o.ownerDocument.doctype&&o.ownerDocument.doctype.name&&Ye(_t,o.ownerDocument.doctype.name)&&(c="<!DOCTYPE "+o.ownerDocument.doctype.name+">\n"+c),te&&Te([F,L,O],e=>{c=Ue(c,e," ")}),$&&le?z(c):c},i.setConfig=function(){Mt(arguments.length>0&&void 0!==arguments[0]?arguments[0]:{}),re=!0},i.clearConfig=function(){Ft=null,re=!1},i.isValidAttribute=function(e,t,i){Ft||Mt({});const o=It(e),r=It(t);return Xt(o,r,i)},i.addHook=function(e,t){"function"==typeof t&&Ie(I[e],t)},i.removeHook=function(e,t){if(void 0!==t){const i=Ee(I[e],t);return-1===i?void 0:Fe(I[e],i,1)[0]}return De(I[e])},i.removeHooks=function(e){I[e]=[]},i.removeAllHooks=function(){I={afterSanitizeAttributes:[],afterSanitizeElements:[],afterSanitizeShadowDOM:[],beforeSanitizeAttributes:[],beforeSanitizeElements:[],beforeSanitizeShadowDOM:[],uponSanitizeAttribute:[],uponSanitizeElement:[],uponSanitizeShadowNode:[]}},i}();class Et extends(de(se)){static properties={currentView:{type:String},stats:{type:Object},hass:{type:Object},narrow:{type:Boolean},_apiReady:{type:Boolean,state:!0},_error:{type:String,state:!0},_detailRepo:{type:Object,state:!0},_showDetail:{type:Boolean,state:!0},_favoriteCount:{type:Number,state:!0},_readmeHtml:{type:String,state:!0},_readmeLoading:{type:Boolean,state:!0},_viewTransition:{type:Boolean,state:!0},_networkStatus:{type:String,state:!0},_detailExpanded:{type:Boolean,state:!0},_showVersionSelector:{type:Boolean,state:!0},_releases:{type:Array,state:!0},_releasesLoading:{type:Boolean,state:!0},_installingVersion:{type:Boolean,state:!0},_changelogData:{type:Object,state:!0},_changelogLoading:{type:Boolean,state:!0},_presetFilter:{type:String,state:!0},_presetTag:{type:String,state:!0},_configFlowDomain:{type:String,state:!0},_configFlowEntryId:{type:String,state:!0},_showConfigFlow:{type:Boolean,state:!0},_configEntries:{type:Object,state:!0},_showEntrySelector:{type:Boolean,state:!0},_entrySelectorDomain:{type:String,state:!0},_entrySelectorEntries:{type:Array,state:!0},_entrySelectorCurrentId:{type:String,state:!0}};constructor(){super(),this.currentView="browse",this.stats={pendingRestart:0},this.narrow=window.innerWidth<768,this._apiReady=!1,this._error="",this._detailRepo=null,this._showDetail=!1,this._favoriteCount=0,this._readmeHtml=null,this._readmeLoading=!1,this._viewTransition=!1,this._networkStatus="online",this._detailExpanded=!1,this._showVersionSelector=!1,this._releases=[],this._releasesLoading=!1,this._installingVersion=!1,this._changelogData=null,this._changelogLoading=!1,this._presetFilter="",this._presetTag="",this._configFlowDomain="",this._configFlowEntryId=null,this._showConfigFlow=!1,this._configEntries=null,this._showEntrySelector=!1,this._entrySelectorDomain="",this._entrySelectorEntries=[],this._entrySelectorCurrentId=null,It(this),window.addEventListener("resize",()=>{this.narrow=window.innerWidth<768}),window.addEventListener("online",()=>{this._networkStatus="online"}),window.addEventListener("offline",()=>{this._networkStatus="offline"})}async _updateFavoriteCount(){try{const e=await ce.getFavorites(),t=Array.isArray(e)?e:e.favorites||[];this._favoriteCount=t.length}catch{this._favoriteCount=0}}willUpdate(e){var t;e.has("hass")&&this.hass&&(t=this.hass,t?.language&&(pe=0===t.language.indexOf("zh")?"zh":"en"),ce.setHass(this.hass),this._apiReady||(this._apiReady=!0,this._loadStats(),this._loadConfigEntries(),ce._onNetworkStatus=e=>{this._networkStatus=e}))}static styles=[me(),a`
    :host {
      display: block;
    }

    .store {
      padding: 16px;
      padding-bottom: calc(16px + env(safe-area-inset-bottom, 0px));
      min-height: 60vh;
      background: var(--primary-background-color, #f5f5f5);
      font-family: var(--paper-font-body1_-_font-family, 'Roboto', sans-serif);
    }

    /* ===== Error Banner ===== */
    .error-banner {
      margin-bottom: 12px; padding: 12px 16px;
      background: #fff3e0; border: 1px solid #ff9800; border-radius: 10px;
      color: #e65100; font-size: 13px;
    }
    .error-banner.error { background: #ffebee; border-color: #f44336; color: #c62828; }
    .error-banner code { background: rgba(0,0,0,0.06); padding: 2px 6px; border-radius: 4px; font-size: 12px; }

    /* ===== Header ===== */
    .header {
      display: flex; align-items: center; justify-content: space-between;
      margin-bottom: 12px; padding: 14px 20px;
      background: linear-gradient(135deg, rgba(var(--rgb-primary-color, 3,169,244), 0.08) 0%, rgba(var(--rgb-primary-color, 3,169,244), 0.03) 100%);
      border-radius: 16px; border: 1px solid var(--divider-color, #e0e0e0);
    }
    .header-left { display: flex; align-items: center; gap: 14px; }
    .header-icon {
      width: 44px; height: 44px; display: flex; align-items: center; justify-content: center;
      background: var(--primary-color, #03a9f4); border-radius: 12px; color: #fff;
      font-size: 22px; font-weight: 700;
    }
    .title-group h1 { font-size: 19px; font-weight: 700; color: var(--primary-text-color, #212121); margin: 0; }
    .title-group p { font-size: 12px; color: var(--secondary-text-color, #727272); margin: 4px 0 0; }
    .header-right { display: flex; gap: 24px; flex-wrap: wrap; }
    .stat { text-align: center; cursor: pointer; }
    .stat:hover .stat-num { opacity: 0.8; }
    .stat-num { font-size: 20px; font-weight: 700; color: var(--primary-color, #03a9f4); transition: opacity 0.15s; }
    .restart-btn {
      display: inline-flex; align-items: center; gap: 4px;
      padding: 4px 12px; border: 1px solid #f44336; border-radius: 4px;
      background: rgba(244,67,54,0.1); color: #f44336;
      cursor: pointer; font-size: 12px; font-weight: 600; white-space: nowrap;
      transition: background 0.15s;
    }
    .restart-btn:hover { background: rgba(244,67,54,0.25); }
    .restart-btn svg { width: 14px; height: 14px; flex-shrink: 0; }

    /* ===== Restart Bar (between header and content) ===== */
    .restart-bar {
      display: flex; align-items: center; gap: 8px; flex-wrap: wrap;
      padding: 10px 14px; margin: 0 0 6px;
      background: rgba(244,67,54,0.08); border: 1px solid rgba(244,67,54,0.25);
      border-radius: 10px; font-size: 13px;
    }
    .restart-bar span { font-weight: 600; color: #f44336; flex: 1; }
    .restart-bar-btn {
      padding: 6px 14px; border: none; border-radius: 8px;
      font-size: 12px; font-weight: 600; cursor: pointer; white-space: nowrap;
      background: #f44336; color: #fff; transition: opacity 0.15s;
    }
    .restart-bar-btn:hover { opacity: 0.85; }
    .restart-bar-btn.outline { background: transparent; border: 1px solid #f44336; color: #f44336; }
    .restart-bar-btn.outline:hover { background: rgba(244,67,54,0.1); }
    .restart-bar svg { flex-shrink: 0; }
    .stat-label { font-size: 11px; color: var(--secondary-text-color, #727272); margin-top: 2px; text-transform: uppercase; }

    /* ===== Sticky Tabs ===== */
    .sticky-header {
      position: sticky; top: 0; z-index: 100;
      background: var(--primary-background-color, #f5f5f5);
      margin: 0 -16px 12px; padding: 0 16px 12px;
      padding-top: env(safe-area-inset-top, 0px);
    }
    .tabs-wrapper { position: relative; }
    .tabs {
      display: flex; gap: 6px; overflow-x: auto;
      padding-bottom: 4px; border-bottom: 1px solid var(--divider-color, #e0e0e0);
      -webkit-overflow-scrolling: touch;
    }
    .tabs::-webkit-scrollbar { display: none; }
    /* Mobile scroll hint - gradient fade on right */
    .tabs-wrapper::after {
      content: ''; position: absolute; right: 0; top: 0; bottom: 4px; width: 30px;
      background: linear-gradient(to right, transparent, var(--primary-background-color, #f5f5f5));
      pointer-events: none; opacity: 0; transition: opacity 0.3s;
    }
    .tabs-wrapper.scrollable::after { opacity: 1; }
    .tab {
      padding: 10px 18px; border-radius: 10px 10px 0 0;
      background: transparent; border: none;
      color: var(--secondary-text-color, #727272); cursor: pointer;
      font-size: 13px; font-weight: 500; transition: all 0.2s;
      white-space: nowrap; position: relative;
      touch-action: manipulation;
    }
    .tab:hover { color: var(--primary-color, #03a9f4); background: rgba(var(--rgb-primary-color, 3,169,244), 0.05); }
    .tab.active { color: var(--primary-color, #03a9f4); font-weight: 600; }
    .tab.active::after {
      content: ''; position: absolute; bottom: -1px; left: 10px; right: 10px;
      height: 2px; background: var(--primary-color, #03a9f4); border-radius: 2px;
    }
    .tab .badge {
      display: inline-flex; align-items: center; justify-content: center;
      min-width: 18px; height: 18px; padding: 0 5px;
      background: var(--primary-color, #03a9f4); color: #fff;
      border-radius: 9px; font-size: 10px; font-weight: 600;
      margin-left: 6px; vertical-align: middle;
    }

    /* ===== Content with transition ===== */
    .content {
      transition: opacity 0.15s ease;
    }
    .content.transitioning { opacity: 0; }
    /* Force hidden views to not display (child :host display overrides [hidden]) */
    .content > [hidden] { display: none !important; }

    /* ===== Network Banner (F2) ===== */
    .network-banner {
      margin-bottom: 12px; padding: 12px 16px;
      border-radius: 10px; font-size: 13px; text-align: center;
      animation: slideDown 0.3s ease;
    }
    .network-banner.offline { background: #ffebee; border: 1px solid #f44336; color: #c62828; }
    .network-banner.warning { background: #fff3e0; border: 1px solid #ff9800; color: #e65100; }
    @keyframes slideDown { from { transform: translateY(-10px); opacity: 0; } to { transform: translateY(0); opacity: 1; } }

    /* ===== Toast Queue ===== */
    .toast-container {
      position: fixed;
      bottom: calc(30px + env(safe-area-inset-bottom, 0px));
      left: 50%; transform: translateX(-50%);
      z-index: 10000; display: flex; flex-direction: column-reverse; gap: 8px;
      pointer-events: none; max-width: calc(100vw - 32px);
    }
    .toast {
      background: var(--primary-color, #03a9f4); color: #fff;
      padding: 14px 26px; border-radius: 12px; font-size: 14px; font-weight: 500;
      opacity: 0; transform: translateY(20px);
      transition: all 0.35s; text-align: center;
      pointer-events: auto;
    }
    .toast.show { opacity: 1; transform: translateY(0); }
    .toast.success { background: #4caf50; }
    .toast.error { background: #f44336; }

    /* ===== Utility icons ===== */
    .mini-icon { width: 14px; height: 14px; vertical-align: -2px; display: inline; flex-shrink: 0; }
    .mini-icon.spin { animation: spin 1s linear infinite; }
    @keyframes spin { from { transform: rotate(0deg); } to { transform: rotate(360deg); } }
    .update-badge { background: var(--warning-color, #ff9800); color: #fff; padding: 1px 6px; border-radius: 8px; font-size: 10px; display: inline-flex; align-items: center; gap: 2px; }

    .action-btn-sm {
      display: inline-flex; align-items: center; gap: 3px;
      padding: 3px 10px; border: 1px solid var(--divider-color, #ccc);
      border-radius: 4px; background: var(--card-background-color);
      color: var(--primary-text-color); cursor: pointer;
      font-size: 11px; white-space: nowrap;
    }
    .action-btn-sm:hover { border-color: var(--primary-color); }

    /* ===== Detail Modal ===== */
    .modal-overlay {
      position: fixed; top: 0; left: 0; width: 100%; height: 100%;
      background: rgba(0,0,0,0.6); z-index: 9999;
      display: flex; align-items: center; justify-content: center;
      padding: 20px; box-sizing: border-box;
      animation: fadeIn 0.2s ease;
    }
    @keyframes fadeIn { from { opacity: 0; } to { opacity: 1; } }

    .modal {
      background: var(--card-background-color, #fff);
      border-radius: 16px; width: 100%; max-width: 720px;
      max-height: 90vh; min-width: 360px; min-height: 300px;
      display: flex; flex-direction: column;
      box-shadow: 0 20px 60px rgba(0,0,0,0.3);
      animation: slideUp 0.25s ease;
      position: relative; overflow: hidden;
      resize: both;
    }
    @keyframes slideUp { from { transform: translateY(30px); opacity: 0; } to { transform: translateY(0); opacity: 1; } }

    /* Resize handle indicator */
    .modal::after {
      content: ''; position: absolute; bottom: 4px; right: 4px;
      width: 14px; height: 14px; pointer-events: none; opacity: 0.3;
      border-right: 2px solid var(--secondary-text-color, #727272);
      border-bottom: 2px solid var(--secondary-text-color, #727272);
    }

    /* Expanded (double-click zoom) */
    .modal.expanded {
      max-width: 95vw; max-height: 95vh;
      width: 95vw; height: 95vh;
      transition: all 0.3s ease;
    }
    .modal:not(.expanded) {
      transition: all 0.3s ease;
    }

    /* Double-click hint */
    .modal-expand-hint {
      position: absolute; top: 8px; left: 50%; transform: translateX(-50%);
      font-size: 10px; color: var(--secondary-text-color, #727272);
      opacity: 0.5; pointer-events: none;
    }

    .modal-header {
      display: flex; align-items: center; justify-content: space-between;
      padding: 20px 24px 0; flex-shrink: 0;
    }
    .modal-title { font-size: 18px; font-weight: 700; color: var(--primary-text-color); flex: 1; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
    .modal-close {
      width: 36px; height: 36px; border-radius: 50%; border: none;
      background: var(--secondary-background-color, #f0f0f0);
      color: var(--secondary-text-color, #727272); cursor: pointer;
      display: flex; align-items: center; justify-content: center;
      font-size: 18px; transition: all 0.2s; flex-shrink: 0; margin-left: 12px;
      touch-action: manipulation;
    }
    .modal-close:hover { background: var(--divider-color, #e0e0e0); }

    .modal-body { padding: 16px 24px 24px; overflow-y: auto; flex: 1; }

    .detail-category {
      display: inline-block; padding: 4px 12px; border-radius: 6px;
      font-size: 11px; font-weight: 600; color: #fff; text-transform: uppercase;
      margin-bottom: 12px;
    }

    .detail-desc {
      font-size: 14px; color: var(--secondary-text-color); line-height: 1.6;
      margin-bottom: 16px;
    }

    .detail-authors {
      font-size: 12px; color: var(--secondary-text-color); margin-bottom: 12px;
    }
    .detail-authors svg { width: 14px; height: 14px; vertical-align: -2px; margin-right: 4px; }
    .detail-author-link { color: var(--primary-color); text-decoration: none; margin-right: 8px; }
    .detail-author-link:hover { text-decoration: underline; }

    .detail-topics {
      display: flex; flex-wrap: wrap; gap: 6px; margin-bottom: 16px;
    }
    .detail-topic-tag {
      display: inline-block; padding: 2px 10px; border-radius: 4px;
      font-size: 11px; background: var(--secondary-background-color);
      color: var(--secondary-text-color); border: 1px solid var(--divider-color);
    }

    .detail-stats {
      display: flex; gap: 16px; margin-bottom: 16px; flex-wrap: wrap;
    }
    .detail-stat {
      display: flex; align-items: center; gap: 6px;
      font-size: 13px; color: var(--secondary-text-color);
    }
    .detail-stat svg { width: 16px; height: 16px; }
    .detail-stat .val { font-weight: 600; color: var(--primary-text-color); }

    .detail-version {
      padding: 12px 16px; background: var(--secondary-background-color, #f0f0f0);
      border-radius: 10px; margin-bottom: 16px;
    }
    .detail-version-row { display: flex; justify-content: space-between; align-items: center; }
    .detail-version-label { font-size: 12px; color: var(--secondary-text-color); }
    .detail-version-value { font-size: 14px; font-weight: 600; color: var(--primary-text-color); }

    /* Version Selector */
    .version-selector {
      margin-bottom: 16px; border: 1px solid var(--divider-color);
      border-radius: 10px; overflow: hidden;
    }
    .version-selector-header {
      display: flex; align-items: center; justify-content: space-between;
      padding: 10px 14px; cursor: pointer; background: var(--secondary-background-color, #f0f0f0);
      font-size: 13px; font-weight: 600; color: var(--primary-text-color);
      touch-action: manipulation;
    }
    .version-selector-header:hover { background: var(--divider-color, #e0e0e0); }
    .version-selector-arrow { transition: transform 0.2s; font-size: 10px; }
    .version-selector-arrow.open { transform: rotate(180deg); }
    .version-selector-body {
      max-height: 300px; overflow-y: auto; border-top: 1px solid var(--divider-color);
    }
    .release-item {
      display: flex; align-items: center; justify-content: space-between;
      padding: 10px 14px; border-bottom: 1px solid var(--divider-color);
      font-size: 13px; transition: background 0.15s;
    }
    .release-item:last-child { border-bottom: none; }
    .release-item:hover { background: var(--secondary-background-color); }
    .release-info { flex: 1; min-width: 0; }
    .release-tag { font-weight: 600; color: var(--primary-text-color); display: flex; align-items: center; gap: 6px; }
    .release-tag .prerelease-badge {
      font-size: 9px; padding: 2px 6px; border-radius: 4px;
      background: #ff9800; color: #fff; font-weight: 600;
    }
    .release-date { font-size: 11px; color: var(--secondary-text-color); margin-top: 2px; }
    .release-install-btn {
      padding: 6px 12px; border-radius: 8px; font-size: 11px; font-weight: 600;
      border: 1px solid var(--primary-color); background: transparent;
      color: var(--primary-color); cursor: pointer; transition: all 0.2s;
      touch-action: manipulation; flex-shrink: 0;
    }
    .release-install-btn:hover { background: var(--primary-color); color: #fff; }
    .release-install-btn:disabled { opacity: 0.5; cursor: not-allowed; }
    .releases-loading { text-align: center; padding: 16px; color: var(--secondary-text-color); font-size: 13px; }
    .releases-empty { text-align: center; padding: 16px; color: var(--secondary-text-color); font-size: 13px; font-style: italic; }

    .modal-actions { display: flex; gap: 8px; flex-wrap: wrap; }
    .modal-btn {
      padding: 10px 18px; border-radius: 10px;
      font-size: 13px; font-weight: 600; cursor: pointer;
      border: 1px solid var(--divider-color, #e0e0e0);
      background: var(--card-background-color, #fff);
      color: var(--primary-text-color, #212121);
      transition: all 0.2s; display: inline-flex; align-items: center; gap: 6px;
      touch-action: manipulation;
    }
    .modal-btn:hover { border-color: var(--primary-color); color: var(--primary-color); }
    .modal-btn.primary { background: var(--primary-color); border-color: var(--primary-color); color: #fff; }
    .modal-btn.primary:hover { opacity: 0.9; }
    .modal-btn.danger { color: #f44336; border-color: #f44336; }
    .modal-btn.danger:hover { background: #f44336; color: #fff; }
    .modal-btn svg { width: 16px; height: 16px; }

    .detail-action-btn {
      display: inline-block; padding: 6px 14px; border-radius: 6px;
      background: var(--primary-color); color: #fff;
      border: none; cursor: pointer; font-size: 12px; font-weight: 600;
      margin: 4px 4px 0 0;
    }
    .detail-action-btn:hover { opacity: 0.9; }

    /* ===== Detail README — single scroll (no double scroll) ===== */
    .detail-changelog {
      margin-bottom: 16px; padding: 14px 16px;
      background: var(--secondary-background-color, #f0f0f0);
      border-radius: 10px; border-left: 3px solid var(--success-color, #0f9d58);
    }
    .detail-changelog-title {
      font-size: 14px; font-weight: 600;
      color: var(--primary-text-color); margin-bottom: 10px;
    }
    .changelog-body {
      font-size: 13px; color: var(--primary-text-color);
      line-height: 1.6; white-space: pre-wrap;
      max-height: 200px; overflow-y: auto;
    }
    .changelog-tag {
      font-size: 11px; color: var(--secondary-text-color);
      margin-top: 8px;
    }
    .changelog-link {
      display: inline-block; margin-top: 8px;
      font-size: 12px; color: var(--primary-color);
      text-decoration: none;
    }
    .changelog-link:hover { text-decoration: underline; }
    .changelog-empty {
      font-size: 13px; color: var(--secondary-text-color);
      font-style: italic;
    }

    .detail-readme {
      margin-top: 16px;
      border-top: 1px solid var(--divider-color, #e0e0e0);
      padding-top: 16px;
    }
    .detail-readme-title {
      font-size: 14px; font-weight: 600;
      color: var(--primary-text-color); margin-bottom: 12px;
    }
    .readme-content {
      font-size: 13px; line-height: 1.6;
      color: var(--primary-text-color); padding-right: 8px;
    }
    .readme-content img { max-width: 100%; height: auto; }
    .readme-content pre {
      background: var(--secondary-background-color, #f5f5f5);
      padding: 12px; border-radius: 8px;
      overflow-x: auto; font-size: 12px;
    }
    .readme-content code {
      background: var(--secondary-background-color, #f5f5f5);
      padding: 2px 6px; border-radius: 4px; font-size: 12px;
    }
    .readme-content h1, .readme-content h2, .readme-content h3 {
      margin-top: 16px; margin-bottom: 8px;
    }
    .readme-content table { border-collapse: collapse; width: 100%; }
    .readme-content th, .readme-content td {
      border: 1px solid var(--divider-color); padding: 8px; text-align: left;
    }
    .readme-loading {
      text-align: center; padding: 20px;
      color: var(--secondary-text-color);
    }
    .readme-error {
      text-align: center; padding: 20px;
      color: var(--secondary-text-color); font-style: italic;
    }

    /* ===== Responsive ===== */
    @media (max-width: 768px) {
      .store { padding: 8px 10px; padding-top: calc(8px + env(safe-area-inset-top, 0px)); padding-bottom: calc(8px + env(safe-area-inset-bottom, 0px)); }
      .header {
        flex-direction: row; align-items: center; justify-content: space-between;
        padding: 8px 12px; margin-bottom: 8px; border-radius: 12px;
      }
      .header-left { gap: 6px; align-items: center; }
      .header-icon { width: 28px; height: 28px; font-size: 14px; border-radius: 8px; flex-shrink: 0; }
      .title-group h1 { font-size: 14px; text-align: left; }
      .title-group p { display: none; }
      .restart-bar { font-size: 12px; padding: 8px 10px; }
      .restart-bar-btn { font-size: 11px; padding: 5px 10px; }
      .header-right { gap: 6px; justify-content: flex-end; flex-wrap: nowrap; }
      .stat { text-align: center; min-width: 32px; }
      .stat-num { font-size: 12px; }
      .stat-label { font-size: 8px; }
      .restart-btn { font-size: 10px; padding: 2px 8px; }
      .restart-btn svg { width: 12px; height: 12px; }
      .sticky-header { margin: 0 -10px 8px; padding: 0 10px 8px; }
      .tab { padding: 8px 12px; font-size: 12px; min-height: 44px; display: flex; align-items: center; }

      /* Mobile modal: fullscreen */
      .modal-overlay { padding: 0; align-items: flex-end; }
      .modal {
        max-width: 100%; max-height: 92vh; border-radius: 16px 16px 0 0;
        resize: none;
      }
      .modal::after { display: none; }
      .modal-header { padding: 16px 16px 0; }
      .modal-body { padding: 12px 16px 16px; padding-bottom: calc(16px + env(safe-area-inset-bottom, 0px)); }
      .modal-actions { flex-direction: column; }
      .modal-btn { width: 100%; justify-content: center; min-height: 44px; }
      .version-selector-body { max-height: 200px; }
    }

    /* ===== Entry Selector ===== */
    .entry-overlay {
      position: fixed; top: 0; left: 0; width: 100%; height: 100%;
      background: rgba(0,0,0,0.5); z-index: 10001;
      display: flex; align-items: center; justify-content: center;
      padding: 20px; box-sizing: border-box;
      animation: fadeIn 0.15s ease;
    }
    .entry-dialog {
      background: var(--card-background-color, #fff);
      border-radius: 16px; padding: 24px;
      max-width: 400px; width: 100%;
      box-shadow: 0 20px 60px rgba(0,0,0,0.3);
      animation: slideUp 0.2s ease;
    }
    .entry-title { font-size: 17px; font-weight: 600; margin-bottom: 4px; color: var(--primary-text-color, #212121); }
    .entry-subtitle { font-size: 13px; color: var(--secondary-text-color, #727272); margin-bottom: 16px; }
    .entry-list { display: flex; flex-direction: column; gap: 8px; margin-bottom: 16px; }
    .entry-btn {
      display: flex; align-items: center; gap: 12px;
      padding: 12px 16px; border: 1px solid var(--divider-color, #e0e0e0);
      border-radius: 12px; background: var(--card-background-color, #fff);
      cursor: pointer; transition: all 0.15s; text-align: left; width: 100%;
    }
    .entry-btn:hover { border-color: var(--primary-color, #03a9f4); background: rgba(var(--rgb-primary-color, 3,169,244), 0.04); }
    .entry-btn-icon {
      width: 36px; height: 36px; border-radius: 50%;
      background: rgba(var(--rgb-primary-color, 3,169,244), 0.1);
      display: flex; align-items: center; justify-content: center;
      flex-shrink: 0; font-size: 16px;
    }
    .entry-btn-text { display: flex; flex-direction: column; min-width: 0; }
    .entry-btn-title { font-size: 14px; font-weight: 500; color: var(--primary-text-color, #212121); }
    .entry-btn-domain { font-size: 12px; color: var(--secondary-text-color, #727272); }
    .entry-btn-current { font-size: 11px; color: var(--primary-color, #03a9f4); }
    .entry-cancel {
      display: block; width: 100%; text-align: center;
      padding: 10px; border: none; background: none;
      color: var(--secondary-text-color, #727272); font-size: 14px;
      cursor: pointer; border-radius: 10px;
    }
    .entry-cancel:hover { background: rgba(0,0,0,0.04); }
  `];async connectedCallback(){super.connectedCallback(),this.addEventListener("refresh-stats",()=>this._loadStats()),this.addEventListener("detail",e=>this._openDetail(e.detail.repo)),this.addEventListener("favorite",()=>this._loadStats()),this.addEventListener("open-flow",e=>{const t=e.detail?.domain;t&&this._openConfigFlow(t)}),this.addEventListener("open-options-flow",e=>{const{entryId:t,domain:i}=e.detail||{};t&&this._openOptionsFlow(t,i)}),this._keydownHandler=e=>{if("Escape"===e.key&&this._showDetail)return e.preventDefault(),void this._closeDetail();if((e.ctrlKey||e.metaKey)&&"k"===e.key){e.preventDefault();const t=this.renderRoot?.querySelector(".search input");return void(t&&(t.focus(),t.select()))}if(!this._showDetail&&"INPUT"!==document.activeElement?.tagName&&"SELECT"!==document.activeElement?.tagName&&"TEXTAREA"!==document.activeElement?.tagName){const t=["browse","updates","management","settings"],i=parseInt(e.key);i>=1&&i<=t.length&&(e.preventDefault(),this.switchView(t[i-1]))}},window.addEventListener("keydown",this._keydownHandler)}disconnectedCallback(){super.disconnectedCallback(),window.removeEventListener("keydown",this._keydownHandler)}async _loadStats(){try{this._error="",this.stats=await ce.getStats();const e=await ce.getFavorites(),t=Array.isArray(e)?e:e.favorites||[];this._favoriteCount=t.length}catch(e){console.error("Stats error:",e),this.stats={},this._error=`API: ${e.message}`}}async _restartHA(){const{ConfirmDialog:e}=await Promise.resolve().then(function(){return Pt});if(await e.show(this,{message:ge("restartConfirm"),confirmText:ge("restartHA"),danger:!0}))try{await ce.restartHA(),Ot(ge("haRestarting"),"info")}catch(e){Ot(`${ge("restartFailed")}: ${e.message}`,"error")}}switchView(e){this.currentView!==e&&(this._viewTransition=!0,this.currentView=e,this.dispatchEvent(new CustomEvent("view-changed",{detail:{view:e},bubbles:!0,composed:!0})),setTimeout(()=>{this._viewTransition=!1},150))}_openDetail(e){this._detailRepo=e,this._showDetail=!0,this._readmeHtml=null,this._readmeLoading=!0,this._showVersionSelector=!1,this._releases=[],this._releasesLoading=!1,this._changelogData=null,this._changelogLoading=!0,this._loadReadme(e),this._loadChangelog(e),requestAnimationFrame(()=>this._installFocusTrap())}async _loadReadme(e){if(e?.full_name){try{const t=await ce.getReadme(e.full_name);this._readmeHtml=t?Tt.sanitize(t):null}catch(e){this._readmeHtml=null}this._readmeLoading=!1}else this._readmeLoading=!1}async _loadChangelog(e){if(e?.full_name){try{const t=await ce.getChangelog(e.full_name);this._changelogData=t?.body?t:null}catch(e){this._changelogData=null}this._changelogLoading=!1}else this._changelogLoading=!1}_applyFilter(e){this._presetFilter=e,this.switchView("browse"),setTimeout(()=>{this._presetFilter=""},100)}_applyTag(e){this._presetTag=e,this.switchView("browse"),setTimeout(()=>{this._presetTag=""},100)}_closeDetail(){this._showDetail=!1,this._detailRepo=null,this._readmeHtml=null,this._readmeLoading=!1,this._detailExpanded=!1,this._showVersionSelector=!1,this._releases=[],this._releasesLoading=!1,this._removeFocusTrap()}_installFocusTrap(){this._removeFocusTrap();const e=this.renderRoot?.querySelector(".modal-overlay");if(!e)return;this._focusTrapHandler=t=>{if("Tab"!==t.key)return;const i=e.querySelectorAll('button, [href], input, select, textarea, [tabindex]:not([tabindex="-1"])');if(0===i.length)return;const o=i[0],r=i[i.length-1];t.shiftKey?document.activeElement!==o&&e.contains(document.activeElement)||(t.preventDefault(),r.focus()):document.activeElement!==r&&e.contains(document.activeElement)||(t.preventDefault(),o.focus())};const t=e.querySelector(".modal-close");t&&t.focus(),window.addEventListener("keydown",this._focusTrapHandler)}_removeFocusTrap(){this._focusTrapHandler&&(window.removeEventListener("keydown",this._focusTrapHandler),this._focusTrapHandler=null)}_openConfigFlow(e){this._configFlowDomain=e,this._configFlowEntryId=null,this._showConfigFlow=!0}_openOptionsFlow(e,t){if(this._configFlowDomain=t||"",this._configFlowEntryId=null,t&&this._configEntries&&this._configEntries[t]&&this._configEntries[t].length>1)return this._entrySelectorDomain=t,this._entrySelectorEntries=this._configEntries[t],this._entrySelectorCurrentId=e,void(this._showEntrySelector=!0);this._configFlowEntryId=e,this._showConfigFlow=!0}_selectConfigEntry(e){if(this._showEntrySelector=!1,this._configFlowEntryId=e,this._configEntries)for(const t of Object.values(this._configEntries)){const i=t.find(t=>t.entry_id===e);if(i){this._configFlowDomain=i.domain||"";break}}this._showConfigFlow=!0}async _loadConfigEntries(){try{const e=await ce.getConfigEntries(),t=e?.entries||[],i={};if(Array.isArray(t))for(const e of t){const t=e.domain||e.handler||"?";i[t]||(i[t]=[]),i[t].push(e)}this._configEntries=i}catch{this._configEntries=null}}async _checkUpdates(){try{const e=await ce.checkUpdatesWithNotify();e.success&&(e.updates_found>0?Ot(ge("updatesChecked",{n:e.updates_found}),"success"):Ot(ge("noUpdatesFound"),"info"),e.notified&&Ot(ge("notifySent"),"success"),this._loadStats())}catch(e){Ot(`Update check failed: ${e.message}`,"error")}}_onConfigureIntegration(e){const{domain:t,entry_id:i}=e.detail;this._configFlowDomain=t,this._configFlowEntryId=i,this._showConfigFlow=!0}_onAddIntegration(e){const{domain:t}=e.detail;this._configFlowDomain=t,this._configFlowEntryId=null,this._showConfigFlow=!0}_onFlowClose(){this._showConfigFlow=!1,this._configFlowDomain="",this._configFlowEntryId=null,this._showEntrySelector=!1}_toggleDetailExpand(){this._detailExpanded=!this._detailExpanded}async _toggleVersionSelector(){if(this._showVersionSelector=!this._showVersionSelector,this._showVersionSelector&&0===this._releases.length){this._releasesLoading=!0;try{const e=this._detailRepo?.id||this._detailRepo?.full_name;if(e){const t=await ce.getRepoReleases(e);this._releases=Array.isArray(t)?t:t.releases||[]}}catch(e){console.error("Failed to load releases:",e),this._releases=[]}this._releasesLoading=!1}}async _installVersion(e){const t=this._detailRepo?.id||this._detailRepo?.full_name;if(t&&e){this._installingVersion=!0;try{await ce.installVersion(t,e),Ot(`${ge("installComplete")}: ${e}`,"success"),this.dispatchEvent(new CustomEvent("refresh-stats",{bubbles:!0,composed:!0})),this._closeDetail()}catch(e){Ot(`${ge("installFailed")}: ${e.message}`,"error")}this._installingVersion=!1}}_getCategoryLabel(e){return{integration:ge("catIntegration"),plugin:ge("catPlugin"),theme:ge("catTheme"),appdaemon:ge("catAppDaemon"),netdaemon:ge("catNetDaemon"),python_script:ge("catPython"),template:ge("catTemplate"),dashboard:ge("catDashboard")}[e]||e}async _modalAction(e){const t=this._detailRepo;if(t)try{if("install"===e)await ce.install(t.id||t.full_name,t.category),Ot(ge("installComplete"),"success");else if("update"===e)await ce.update([t.id||t.full_name]),Ot(ge("updateStarted"),"success");else if("uninstall"===e){const{ConfirmDialog:e}=await Promise.resolve().then(function(){return Pt});if(!await e.show(this,{message:`${ge("confirmRemove")} ${t.full_name||t.name}?`,confirmText:ge("remove"),danger:!0}))return;await ce.remove(t.id||t.full_name),Ot(ge("removed"),"success")}else if("github"===e){const e=t.html_url||`https://github.com/${t.full_name}`;return void window.open(e,"_blank")}this.dispatchEvent(new CustomEvent("refresh-stats",{bubbles:!0,composed:!0})),this._closeDetail()}catch(e){Ot(`${ge("updateFailed")}: ${e.message}`,"error")}}_checkTabsScrollable(){const e=this.renderRoot?.querySelector(".tabs-wrapper"),t=e?.querySelector(".tabs");e&&t&&e.classList.toggle("scrollable",t.scrollWidth>t.clientWidth)}async updated(e){super.updated(e),e.has("narrow")&&requestAnimationFrame(()=>this._checkTabsScrollable())}firstUpdated(){requestAnimationFrame(()=>this._checkTabsScrollable())}render(){const e=[{view:"browse",label:ge("tabBrowse"),icon:"",count:null},{view:"integrations",label:ge("tabIntegrations")||"集成管理",icon:"",count:null},{view:"updates",label:ge("tabUpdates"),icon:"",count:this.stats.available_updates},{view:"management",label:ge("tabManagement"),icon:"",count:null},{view:"settings",label:ge("tabSettings"),icon:"",count:null}],t=this._detailRepo,i=t?.installed||!1,o=i&&(t?.has_update||t?.installed_version&&t?.latest_version&&t.installed_version!==t.latest_version),r=t?fe(t.category):"#03a9f4";return H`
      <div class="store">
        ${this._error?H`
          <div class="error-banner error">
            <svg class="mini-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"/><line x1="12" y1="9" x2="12" y2="13"/><line x1="12" y1="17" x2="12.01" y2="17"/></svg> ${ge("connectFailed")}: <code>${this._error}</code>
          </div>
        `:""}
        ${this._apiReady?"":H`
          <div class="error-banner">
            ${ge("waitingHA")}
          </div>
        `}

        ${"offline"===this._networkStatus?H`
          <div class="network-banner offline">${ge("networkOffline")}</div>
        `:"rate_limited"===this._networkStatus?H`
          <div class="network-banner warning">${ge("rateLimited")}</div>
        `:"server_error"===this._networkStatus?H`
          <div class="network-banner warning">${ge("haRestarting")}</div>
        `:""}

        <!-- Header -->
        <div class="header">
          <div class="header-left">
            <div class="header-icon">
              <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                <path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/>
                <circle cx="12" cy="12" r="3"/>
              </svg>
            </div>
            <div class="title-group">
              <h1>HACS Vision</h1>
              <p>${ge("storeSubtitle")}</p>
            </div>
          </div>
          <div class="header-right">
            <div class="stat" @click=${()=>this._applyFilter("installed")}>
              <div class="stat-num">${this.stats.total_installed??0}</div>
              <div class="stat-label">${ge("statInstalled")}</div>
            </div>
            <div class="stat" @click=${()=>this._applyFilter("update_available")}>
              <div class="stat-num">${this.stats.available_updates??0}</div>
              <div class="stat-label">${ge("statUpdates")}</div>
            </div>
            ${(this.stats.pending_restart??0)>0?H`
            <div class="stat" style="color:#f44336;" @click=${()=>this._applyFilter("pending_restart")}>
              <div class="stat-num">${this.stats.pending_restart}</div>
              <div class="stat-label">${ge("statusPendingRestart")}</div>
            </div>
            `:""}
            <div class="stat" @click=${()=>this._applyTag("favorites")}>
              <div class="stat-num">${this._favoriteCount??0}</div>
              <div class="stat-label">${ge("statFavorites")||"收藏"}</div>
            </div>
            <div class="stat" @click=${()=>this._applyTag("custom")}>
              <div class="stat-num">${this.stats.custom_count??0}</div>
              <div class="stat-label">${ge("statCustom")||"自定义"}</div>
            </div>
            <div class="stat" @click=${()=>this._applyFilter("")}>
              <div class="stat-num">${this.stats.total_repos??0}</div>
              <div class="stat-label">${ge("statRepos")}</div>
            </div>
          </div>
        </div>

        <!-- Sticky Tabs -->
        <div class="sticky-header">
          <div class="tabs-wrapper">
            <div class="tabs" role="tablist">
              ${e.map(e=>H`
                <button class="tab ${this.currentView===e.view?"active":""}"
                        role="tab" aria-selected=${this.currentView===e.view}
                        aria-label=${e.label}
                        @click=${()=>this.switchView(e.view)}>
                  ${e.icon?H`${e.icon} `:""}${e.label}
                  ${void 0!==e.count&&null!==e.count?H`<span class="badge" aria-label="${e.count}">${e.count}</span>`:""}
                </button>
              `)}
            </div>
          </div>
        </div>

        <!-- Content with fade transition -->
        <div class="content ${this._viewTransition?"transitioning":""}">
          <browse-view .hass=${this.hass} .presetFilter=${this._presetFilter} .presetTag=${this._presetTag} .pendingRestart=${this.stats.pending_restart??0} ?hidden=${"browse"!==this.currentView}></browse-view>
          <integrations-list .hass=${this.hass} ?hidden=${"integrations"!==this.currentView} @configure-integration=${this._onConfigureIntegration} @add-integration=${this._onAddIntegration}></integrations-list>
          <updates-view .hass=${this.hass} ?hidden=${"updates"!==this.currentView}></updates-view>
          <management-view .hass=${this.hass} ?hidden=${"management"!==this.currentView}></management-view>
          <config-view .hass=${this.hass} @refresh-stats=${this._loadStats} ?hidden=${"settings"!==this.currentView}></config-view>
        </div>
      </div>

      <!-- Detail Modal -->
      ${this._showDetail&&t?H`
        <div class="modal-overlay" role="dialog" aria-modal="true" aria-label="${t.manifest_name||t.full_name||ge("detail")}" @click=${e=>{e.target===e.currentTarget&&this._closeDetail()}}>
          <div class="modal ${this._detailExpanded?"expanded":""}" @dblclick=${this._toggleDetailExpand}>
            ${this._detailExpanded?"":H`<div class="modal-expand-hint">${ge("dblZoomHint")||"双击放大"}</div>`}
            <div class="modal-header">
              <div class="modal-title">${t.manifest_name||t.repository_manifest?.name||t.full_name||t.name||"unknown"}</div>
              <button class="modal-close" aria-label="${ge("close")||"关闭"}" @click=${this._closeDetail}>✕</button>
            </div>
            <div class="modal-body">
              <div class="detail-category" style="background: ${r}">
                ${this._getCategoryLabel(t.category||"integration")}
              </div>

              <div class="detail-desc">${t.description||ge("noDesc")}</div>

              ${t.authors&&t.authors.length?H`
                <div class="detail-authors">
                  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>
                  ${t.authors.filter(e=>e&&"@user"!==e).map(e=>H`
                    <a class="detail-author-link" href="https://github.com/${e.replace(/^@/,"")}" target="_blank" rel="noopener">@${e.replace(/^@/,"")}</a>
                  `)}
                </div>
              `:""}

              <div class="detail-stats">
                <div class="detail-stat">
                  <svg viewBox="0 0 20 20" fill="#ff9800"><path d="M10 1l2.39 4.84L17.6 6.7l-3.8 3.71.9 5.26L10 13.27l-4.7 2.46.9-5.26L2.4 6.7l5.2-.86L10 1z"/></svg>
                  <span class="val">${(t.stars||t.stargazers_count||0).toLocaleString()}</span> ${ge("stars")}
                </div>
                ${t.downloads?H`
                  <div class="detail-stat">
                    <svg viewBox="0 0 20 20" fill="currentColor"><path d="M3 17a1 1 0 011-1h12a1 1 0 110 2H4a1 1 0 01-1-1zm3.293-7.707a1 1 0 011.414 0L9 10.586V3a1 1 0 112 0v7.586l1.293-1.293a1 1 0 111.414 1.414l-3 3a1 1 0 01-1.414 0l-3-3a1 1 0 010-1.414z"/></svg>
                    <span class="val">${t.downloads.toLocaleString()}</span> ${ge("downloads")}
                  </div>
                `:""}
                <div class="detail-stat">
                  <svg viewBox="0 0 20 20" fill="currentColor"><path d="M10 0C4.477 0 0 4.477 0 10c0 4.42 2.865 8.166 6.839 9.489.5.092.682-.217.682-.482 0-.237-.009-.866-.013-1.7-2.782.604-3.369-1.34-3.369-1.34-.454-1.156-1.11-1.464-1.11-1.464-.908-.62.069-.608.069-.608 1.003.07 1.531 1.03 1.531 1.03.892 1.529 2.341 1.087 2.91.831.092-.646.35-1.086.636-1.336-2.22-.253-4.555-1.11-4.555-4.943 0-1.091.39-1.984 1.029-2.683-.103-.253-.446-1.27.098-2.647 0 0 .84-.269 2.75 1.025A9.578 9.578 0 0110 4.836a9.59 9.59 0 012.504.337c1.909-1.294 2.747-1.025 2.747-1.025.546 1.377.203 2.394.1 2.647.64.699 1.028 1.592 1.028 2.683 0 3.842-2.339 4.687-4.566 4.935.359.309.678.919.678 1.852 0 1.336-.012 2.415-.012 2.743 0 .267.18.578.688.48C17.138 18.163 20 14.418 20 10c0-5.523-4.477-10-10-10z"/></svg>
                  <span class="val">${t.full_name||t.name||""}</span>
                </div>
              </div>

              ${t.topics&&t.topics.length?H`
                <div class="detail-topics">
                  ${t.topics.map(e=>H`
                    <span class="detail-topic-tag">${e}</span>
                  `)}
                </div>
              `:""}

              ${i?H`
                <div class="detail-version">
                  <div class="detail-version-row">
                    <span class="detail-version-label">${ge("currentVersion")}</span>
                    <span class="detail-version-value">${t.installed_version||ge("unknown")}</span>
                  </div>
                  ${o?H`
                    <div class="detail-version-row" style="margin-top:8px;">
                      <span class="detail-version-label">${ge("availableVersion")}</span>
                      <span class="detail-version-value" style="color:var(--success-color, #0f9d58);">${t.latest_version||ge("unknown")}</span>
                    </div>
                  `:""}
                  ${t.installed_at?H`
                    <div class="detail-version-row" style="margin-top:8px;">
                      <span class="detail-version-label">${ge("installedAt")}</span>
                      <span class="detail-version-value">${new Date(t.installed_at).toLocaleString()}</span>
                    </div>
                  `:""}
                </div>
              `:""}

              <!-- Version Selector -->
              <div class="version-selector">
                <div class="version-selector-header" @click=${this._toggleVersionSelector}>
                  ${ge("selectVersion")}
                  <span class="version-selector-arrow ${this._showVersionSelector?"open":""}">▼</span>
                </div>
                ${this._showVersionSelector?H`
                  <div class="version-selector-body">
                    ${this._releasesLoading?H`
                      <div class="releases-loading">
                        <div class="spinner-sm"></div>
                        ${ge("loading")}
                      </div>
                    `:0===this._releases.length?H`
                      <div class="releases-empty">${ge("noReleases")}</div>
                    `:this._releases.map(e=>H`
                      <div class="release-item">
                        <div class="release-info">
                          <div class="release-tag">
                            ${e.tag_name||e.tag||"?"}
                            ${e.prerelease?H`<span class="prerelease-badge">${ge("prerelease")}</span>`:""}
                          </div>
                          ${e.published_at||e.created_at?H`
                            <div class="release-date">${ge("publishedAt")} ${new Date(e.published_at||e.created_at).toLocaleDateString()}</div>
                          `:""}
                        </div>
                        <button class="release-install-btn"
                                @click=${()=>this._installVersion(e.tag_name||e.tag)}
                                ?disabled=${this._installingVersion}>
                          ${ge("installVersion")}
                        </button>
                      </div>
                    `)}
                  </div>
                `:""}
              </div>

              <!-- Changelog (What's New) — shown when update is available -->
              ${o?H`
                <div class="detail-changelog">
                  <div class="detail-changelog-title">${ge("changelogTitle")||"更新内容"}</div>
                  ${this._changelogLoading?H`
                    <div class="readme-loading">
                      <div class="spinner-sm"></div>
                      ${ge("loading")||"加载中..."}
                    </div>
                  `:this._changelogData?H`
                    <div class="changelog-body">${this._changelogData.body}</div>
                    ${this._changelogData.tag?H`
                      <div class="changelog-tag">${this._changelogData.tag}</div>
                    `:""}
                    ${this._changelogData.url?H`
                      <a class="changelog-link" href="${this._changelogData.url}" target="_blank" rel="noopener">${ge("viewFullChangelog")||"查看完整更新日志"} →</a>
                    `:""}
                  `:H`
                    <div class="changelog-empty">${ge("noChangelog")||"暂无更新日志"}</div>
                  `}
                </div>
              `:""}

              <div class="modal-actions">
                ${i?H`
                  ${o?H`
                    <button class="modal-btn primary" @click=${()=>this._modalAction("update")}>
                      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M23 4v6h-6M1 20v-6h6"/><path d="M3.51 9a9 9 0 0114.85-3.36L23 10M1 14l4.64 4.36A9 9 0 0020.49 15"/></svg>
                      ${ge("update")}
                    </button>
                  `:""}
                  <button class="modal-btn danger" @click=${()=>this._modalAction("uninstall")}>
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="3 6 5 6 21 6"/><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/></svg>
                    ${ge("remove")}
                  </button>
                `:H`
                  <button class="modal-btn primary" @click=${()=>this._modalAction("install")}>
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></svg>
                    ${ge("install")}
                  </button>
                `}
                <button class="modal-btn" @click=${()=>this._modalAction("github")}>
                  <svg viewBox="0 0 20 20" fill="currentColor"><path d="M10 0C4.477 0 0 4.477 0 10c0 4.42 2.865 8.166 6.839 9.489.5.092.682-.217.682-.482 0-.237-.009-.866-.013-1.7-2.782.604-3.369-1.34-3.369-1.34-.454-1.156-1.11-1.464-1.11-1.464-.908-.62.069-.608.069-.608 1.003.07 1.531 1.03 1.531 1.03.892 1.529 2.341 1.087 2.91.831.092-.646.35-1.086.636-1.336-2.22-.253-4.555-1.11-4.555-4.943 0-1.091.39-1.984 1.029-2.683-.103-.253-.446-1.27.098-2.647 0 0 .84-.269 2.75 1.025A9.578 9.578 0 0110 4.836a9.59 9.59 0 012.504.337c1.909-1.294 2.747-1.025 2.747-1.025.546 1.377.203 2.394.1 2.647.64.699 1.028 1.592 1.028 2.683 0 3.842-2.339 4.687-4.566 4.935.359.309.678.919.678 1.852 0 1.336-.012 2.415-.012 2.743 0 .267.18.578.688.48C17.138 18.163 20 14.418 20 10c0-5.523-4.477-10-10-10z"/></svg>
                  ${ge("openGithub")}
                </button>
              </div>

              <!-- README Section — no max-height, single scroll via modal-body -->
              <div class="detail-readme">
                <div class="detail-readme-title">${ge("readmeTitle")}</div>
                ${this._readmeLoading?H`
                  <div class="readme-loading">
                    <div class="spinner-sm"></div>
                    ${ge("loadingReadme")}
                  </div>
                `:this._readmeHtml?H`
                  <div class="readme-content" .innerHTML=${this._readmeHtml}></div>
                `:H`
                  <div class="readme-error">${ge("readmeLoadFailed")}</div>
                `}
              </div>
            </div>
          </div>
        </div>
      `:""}

      <!-- Toast container (supports queue) -->
      <div class="toast-container" id="toast-container" aria-live="polite" aria-atomic="true"></div>

      <!-- Entry Selector (multiple config entries for same domain) -->
      ${this._showEntrySelector?H`
        <div class="entry-overlay" role="dialog" aria-modal="true" aria-label="${ge("selectEntryTitle")}" @click=${()=>{this._showEntrySelector=!1}}>
          <div class="entry-dialog" @click=${e=>e.stopPropagation()}>
            <div class="entry-title">${ge("selectEntryTitle")}</div>
            <div class="entry-subtitle">${ge("selectEntrySubtitle")||"请选择要配置的集成实例"}</div>
            <div class="entry-list">
              ${this._entrySelectorEntries.map(e=>H`
                <button class="entry-btn" @click=${()=>this._selectConfigEntry(e.entry_id)}>
                  <div class="entry-btn-icon">⚙️</div>
                  <div class="entry-btn-text">
                    <span class="entry-btn-title">${e.title||e.entry_id}</span>
                    <span class="entry-btn-domain">${e.domain}${e.entry_id===this._entrySelectorCurrentId?" · "+(ge("currentEntry")||"当前"):""}</span>
                  </div>
                </button>
              `)}
            </div>
            <button class="entry-cancel" @click=${()=>{this._showEntrySelector=!1}}>${ge("cancel")}</button>
          </div>
        </div>
      `:""}

      <!-- Config Flow Dialog -->
      <config-flow-dialog
        .hass=${this.hass}
        .domain=${this._configFlowDomain}
        .entryId=${this._configFlowEntryId}
        .configEntries=${this._configEntries}
        .open=${this._showConfigFlow}
        @close=${this._onFlowClose}>
      </config-flow-dialog>
    `}}let Dt=null;function It(e){Dt=e}const Ft=[];let Lt=!1;function Ot(e,t="info"){const i=Dt||document.querySelector("hacs-vision-panel"),o=i?.shadowRoot?.querySelector("#toast-container");o?(Ft.push({msg:e,type:t}),Lt||Mt(o)):console.warn("Toast container not found:",e)}function Mt(e){if(0===Ft.length)return void(Lt=!1);Lt=!0;const{msg:t,type:i}=Ft.shift(),o=document.createElement("div");o.className="toast",i&&o.classList.add(i),o.textContent=t,e.appendChild(o),requestAnimationFrame(()=>{o.classList.add("show")}),setTimeout(()=>{o.classList.remove("show"),setTimeout(()=>{o.remove(),Mt(e)},350)},3e3)}var Nt=Object.freeze({__proto__:null,HacsVisionPanel:Et,registerPanel:It,showToast:Ot});class Ut extends se{static properties={repo:{type:Object},_isFavorite:{type:Boolean,state:!0},_installing:{type:Boolean},favorites:{type:Array},selected:{type:Boolean},showCheckbox:{type:Boolean},viewMode:{type:String},renamedFrom:{type:String},showRemoveBtn:{type:Boolean}};constructor(){super(),this.repo={},this._isFavorite=!1,this._installing=!1,this.favorites=[],this.viewMode="store",this.renamedFrom=null,this.showRemoveBtn=!1}_updateFavoriteState(){this.repo&&this.favorites&&(this._isFavorite=this.favorites.includes(this.repo.id||this.repo.full_name))}willUpdate(e){(e.has("repo")||e.has("favorites"))&&this._updateFavoriteState()}static styles=a`
    :host { display: block; touch-action: manipulation; }
    .card {
      background: var(--card-background-color, #fff);
      border: 1px solid var(--divider-color, #e0e0e0);
      border-radius: 14px; overflow: hidden;
      transition: border-color 0.2s, box-shadow 0.2s; cursor: pointer;
      box-sizing: border-box;
      display: flex; flex-direction: column;
      position: relative; min-height: 290px;
    }
    .card.custom-repo {
      border-left: 3px solid #ff6f00;
    }
    .card:hover { border-color: var(--primary-color, #03a9f4); box-shadow: 0 4px 12px rgba(0,0,0,0.08); }

    .img-container {
      height: 120px; flex-shrink: 0;
      display: flex; align-items: center; justify-content: center;
      background: linear-gradient(135deg, var(--secondary-background-color, #f0f0f0) 0%, var(--card-background-color, #fff) 100%);
      position: relative;
    }
    .avatar {
      width: 52px; height: 52px; border-radius: 50%;
      display: flex; align-items: center; justify-content: center;
      font-size: 24px; font-weight: 700; color: #fff;
      box-shadow: 0 4px 12px rgba(0,0,0,0.15);
      overflow: hidden;
    }
    .avatar img { width: 100%; height: 100%; object-fit: cover; }
    .avatar .initials { display: flex; }
    .badge {
      padding: 4px 10px; border-radius: 6px;
      font-size: 10px; font-weight: 600; color: #fff;
      text-transform: uppercase; flex-shrink: 0;
    }
    .badge.integration { background: #1565c0; }
    .badge.plugin { background: #7b1fa2; }
    .badge.theme { background: #2e7d32; }
    .badge.template { background: #6a1b9a; }

    /* Status badge — auto switches between states, only one shown */
    .status-badge {
      position: absolute; bottom: 10px; left: 10px;
      padding: 4px 10px; border-radius: 6px;
      font-size: 10px; font-weight: 600;
    }
    .status-badge.installed { background: rgba(76,175,80,0.15); color: #4caf50; }
    .status-badge.update-available { background: rgba(255,152,0,0.15); color: #ff9800; }
    .status-badge.pending-restart { background: rgba(244,67,54,0.15); color: #f44336; }

    /* Right-side independent badges — symmetrical with status-badge */
    .right-tags {
      position: absolute; bottom: 10px; right: 10px;
      display: flex; flex-direction: column; gap: 2px;
      align-items: flex-end; pointer-events: none; z-index: 2;
    }
    .right-tags .tag {
      font-size: 9px; padding: 2px 7px; border-radius: 4px;
      white-space: nowrap; line-height: 1.5;
    }
    .right-tags .tag.configured { background: rgba(33,150,243,0.15); color: #2196f3; }
    .right-tags .tag.load-failed { background: rgba(244,67,54,0.15); color: #f44336; }
    .right-tags .tag.custom-tag { background: rgba(255,111,0,0.15); color: #ff6f00; font-weight: 600; }

    .top-bar {
      position: absolute; top: 0; left: 0; right: 0;
      display: flex; align-items: center; gap: 6px;
      padding: 10px; z-index: 2;
    }
    .checkbox {
      width: 18px; height: 18px; border-radius: 4px;
      border: 2px solid rgba(255,255,255,0.7); cursor: pointer;
      display: flex; align-items: center; justify-content: center;
      flex-shrink: 0; transition: all 0.2s;
      background: rgba(0,0,0,0.25);
      -webkit-appearance: none; appearance: none; touch-action: manipulation;
    }
    .checkbox:checked {
      background: var(--primary-color); border-color: var(--primary-color);
    }
    .checkbox:checked::after {
      content: '✓'; color: #fff; font-size: 12px; font-weight: 700;
    }

    .fav-btn {
      position: absolute; top: 10px; right: 10px;
      width: 32px; height: 32px; border-radius: 50%;
      border: none; background: rgba(255,255,255,0.85);
      cursor: pointer; display: flex; align-items: center; justify-content: center;
      transition: all 0.2s; z-index: 2; padding: 0;
      box-shadow: 0 2px 6px rgba(0,0,0,0.12);
    }
    .fav-btn:hover { transform: scale(1.1); }
    .fav-btn svg { width: 18px; height: 18px; transition: all 0.2s; }
    .fav-btn.active svg { fill: #ff9800; color: #ff9800; }
    .fav-btn:not(.active) svg { fill: none; color: var(--secondary-text-color, #727272); }

    .remove-btn {
      position: absolute; top: 10px; right: 10px;
      width: 32px; height: 32px; border-radius: 50%;
      border: none; background: rgba(244,67,54,0.12);
      cursor: pointer; display: flex; align-items: center; justify-content: center;
      transition: all 0.2s; z-index: 2; padding: 0; color: #f44336;
      font-size: 16px; font-weight: 700; line-height: 1;
      box-shadow: 0 2px 6px rgba(0,0,0,0.12);
    }
    .remove-btn:hover { background: rgba(244,67,54,0.25); transform: scale(1.1); }

    .content { padding: 14px; flex: 1; display: flex; flex-direction: column; }

    .name {
      font-size: 15px; font-weight: 600; color: var(--primary-text-color, #212121);
      overflow: hidden; text-overflow: ellipsis; white-space: nowrap; margin-bottom: 2px;
    }

    .fullname {
      font-size: 11px; color: var(--secondary-text-color, #727272);
      overflow: hidden; text-overflow: ellipsis; white-space: nowrap; margin-bottom: 4px;
      min-height: 16px;
    }

    .desc {
      font-size: 12px; color: var(--secondary-text-color, #727272);
      display: -webkit-box; -webkit-line-clamp: 2; -webkit-box-orient: vertical;
      overflow: hidden; margin-bottom: 10px; line-height: 1.5; height: 36px;
    }

    .meta {
      display: flex; justify-content: space-between; align-items: center;
      flex-wrap: wrap; gap: 4px; margin-top: auto;
    }
    .author { font-size: 12px; color: var(--primary-color, #03a9f4); }
    .stars {
      display: flex; align-items: center; gap: 3px;
      font-size: 11px; color: var(--secondary-text-color, #727272);
    }
    .stars svg { width: 14px; height: 14px; fill: #ff9800; color: #ff9800; }

    .tags { display: flex; gap: 4px; flex-wrap: wrap; }
    .tag {
      font-size: 9px; padding: 2px 7px;
      background: rgba(var(--rgb-primary-color, 3,169,244), 0.08);
      color: var(--primary-color, #03a9f4); border-radius: 4px;
    }
    .custom-tag {
      font-size: 9px; padding: 2px 7px; border-radius: 4px;
      background: #ff6f00; color: #fff; font-weight: 700;
    }
    .topic-tag {
      font-size: 9px; padding: 1px 6px; border-radius: 4px;
      background: var(--secondary-background-color);
      color: var(--secondary-text-color); border: 1px solid var(--divider-color);
    }

    .actions {
      display: flex; gap: 6px;
      padding: 8px 14px;
      border-top: 1px solid var(--divider-color, #e0e0e0);
      margin-top: auto; background: var(--card-background-color, #fff);
    }
    .action-btn {
      flex: 1; min-width: 0; padding: 8px 4px; border-radius: 10px;
      font-size: 12px; text-align: center; justify-content: center;
      border: 1px solid var(--divider-color, #e0e0e0);
      background: var(--card-background-color, #fff);
      color: var(--primary-text-color, #212121);
      cursor: pointer; transition: all 0.2s;
      display: flex; align-items: center; gap: 4px;
      touch-action: manipulation;
    }
    .action-btn:hover { border-color: var(--primary-color, #03a9f4); color: var(--primary-color, #03a9f4); }
    .action-btn.primary {
      background: var(--primary-color, #03a9f4); border-color: var(--primary-color, #03a9f4); color: #fff;
    }
    .action-btn.primary:hover { opacity: 0.9; }
    .action-btn.readme-btn {
      flex: 0 0 auto; min-width: auto; padding: 8px 10px;
      background: rgba(var(--rgb-primary-color, 3,169,244), 0.08);
      border-color: transparent; color: var(--primary-color, #03a9f4);
    }
    .action-btn.readme-btn:hover { background: var(--primary-color, #03a9f4); color: #fff; }
    .action-btn svg { width: 16px; height: 16px; flex-shrink: 0; }
    .action-btn .label { overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }

    .action-btn.installing {
      opacity: 0.7; cursor: not-allowed;
      animation: btnPulse 1.5s infinite;
    }
    @keyframes btnPulse { 0%, 100% { opacity: 0.7; } 50% { opacity: 0.45; } }

    @media (max-width: 768px) {
      :host { width: 100%; max-width: 100%; min-width: 0; }
      .card { width: 100%; max-width: 100%; min-height: 270px; box-sizing: border-box; }
      .img-container { height: 100px; }
      .avatar { width: 44px; height: 44px; font-size: 20px; }
      .content { padding: 10px; }
      .name { font-size: 14px; }
      .desc { font-size: 11px; height: 32px; }
      .fullname { min-height: 15px; font-size: 10px; }
      .action-btn {
        min-height: 44px;
        padding: 10px 6px;
        font-size: 11px;
      }
      .action-btn .label { display: none; }
      .fav-btn { width: 36px; height: 36px; }
      .fav-btn svg { width: 20px; height: 20px; }
      .remove-btn { width: 36px; height: 36px; font-size: 18px; }
    }

    .mini-icon { width: 14px; height: 14px; vertical-align: -2px; display: inline; flex-shrink: 0; }
    .mini-icon.spin { animation: spin 1s linear infinite; }
    @keyframes spin { 100% { transform: rotate(360deg); } }
  `;_getInitials(e){if(!e)return"?";const t=e.split("/");return(t[t.length-1]||e).charAt(0).toUpperCase()}_getIconUrl(e){const t=e.domain;return t&&"integration"===e.category?`https://brands.home-assistant.io/${t}/icon.png`:null}_getStatusBadge(e){return e.pending_restart?{label:ge("statusPendingRestart"),cls:"pending-restart"}:e.installed&&(e.has_update||e.installed_version&&e.latest_version&&e.installed_version!==e.latest_version)?{label:ge("statusPendingUpgrade"),cls:"update-available"}:e.installed?{label:ge("installed"),cls:"installed"}:null}_getCategoryLabel(e){return{integration:ge("catIntegration"),plugin:ge("catPlugin"),theme:ge("catTheme"),template:ge("catTemplate"),dashboard:ge("catDashboard")}[e]||e}_handleAction(e,t){e.stopPropagation(),this.dispatchEvent(new CustomEvent(t,{detail:{repo:this.repo},bubbles:!0,composed:!0}))}async _handleFavorite(e){e.stopPropagation();const t=this.repo.id||this.repo.full_name,i=[...this.favorites],o=i.indexOf(t);o>=0?(i.splice(o,1),this._isFavorite=!1):(i.push(t),this._isFavorite=!0);try{await ce.setFavorites(i),this.favorites=i}catch(e){this._isFavorite=!this._isFavorite}this.dispatchEvent(new CustomEvent("favorite",{detail:{repo:this.repo,isFavorite:this._isFavorite},bubbles:!0,composed:!0}))}_handleCardClick(){this.dispatchEvent(new CustomEvent("detail",{detail:{repo:this.repo},bubbles:!0,composed:!0}))}render(){const e=this.repo,t=e.manifest_name||e.repository_manifest?.name||e.full_name||e.name||"unknown",i=e.description||"",o=e.category||"integration",r=e.stars||e.stargazers_count||0,a=e.downloads||0,s=e.installed||!1,n=s&&(e.has_update||e.installed_version&&e.latest_version&&e.installed_version!==e.latest_version),l=fe(o);return H`
      <div class="card${e.is_custom?" custom-repo":""}" @click=${this._handleCardClick}>
        <div class="img-container">
          ${this.showCheckbox?H`
            <div class="top-bar">
              <input type="checkbox" class="checkbox" ?checked=${this.selected}
                     @click=${e=>e.stopPropagation()}
                     @change=${()=>this.dispatchEvent(new CustomEvent("check-change",{detail:{fullName:this.repo?.full_name},bubbles:!0,composed:!0}))}>
              <span class="badge ${o}">${this._getCategoryLabel(o)}</span>
            </div>
          `:H`<span class="badge ${o}" style="position:absolute;top:10px;left:10px;">${this._getCategoryLabel(o)}</span>`}
          <div class="avatar" style="background: ${l}">
            ${this._getIconUrl(e)?H`
              <img src="${this._getIconUrl(e)}" @error=${e=>{e.target.style.display="none",e.target.nextElementSibling.style.display="flex"}} alt="">
              <span class="initials" style="display:none">${this._getInitials(t)}</span>
            `:this._getInitials(t)}
          </div>
          ${this._getStatusBadge(e)?H`<span class="status-badge ${this._getStatusBadge(e).cls}">${this._getStatusBadge(e).label}</span>`:""}
          <!-- Right-side independent badges (symmetrical with status-badge) -->
          <div class="right-tags">
            ${e.config_entry_id?H`<span class="tag configured">${ge("badgeConfigured")}</span>`:""}
            ${e.load_failed?H`<span class="tag load-failed">${ge("badgeLoadFailed")}</span>`:""}
            ${e.is_custom?H`<span class="tag custom-tag">${ge("customBadge")}</span>`:""}
          </div>
          ${this.renamedFrom?H`<span class="renamed-badge" style="position:absolute;bottom:10px;right:10px;font-size:9px;padding:2px 7px;border-radius:4px;background:#ff9800;color:#fff;display:flex;align-items:center;gap:3px;"><svg class="mini-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M23 4v6h-6M1 20v-6h6"/><path d="M3.51 9a9 9 0 0114.85-3.36L23 10M1 14l4.64 4.36A9 9 0 0020.49 15"/></svg> ${this.renamedFrom}</span>`:""}
          ${"management"!==this.viewMode?H`
          <button class="fav-btn ${this._isFavorite?"active":""}"
                  @click=${this._handleFavorite}
                  title=${this._isFavorite?ge("favOn"):ge("favOff")}>
            <svg viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
              <path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z"/>
            </svg>
          </button>
          `:this.showRemoveBtn?H`
          <button class="remove-btn" @click=${e=>this._handleAction(e,"remove-repo")} title="${ge("removeRepo")}">
            ✕
          </button>
          `:""}
        </div>

        <div class="content">
          <div class="name" title=${t}>${t}</div>
          <div class="fullname">${e.full_name||""}</div>
          <div class="desc">${i||ge("noDesc")}</div>
          <div class="meta">
            <div class="tags">
              ${e.topics&&e.topics.length?e.topics.slice(0,3).map(e=>H`<span class="topic-tag">${e}</span>`):""}
            </div>
            <span class="stars">
              <svg viewBox="0 0 20 20"><path d="M10 1l2.39 4.84L17.6 6.7l-3.8 3.71.9 5.26L10 13.27l-4.7 2.46.9-5.26L2.4 6.7l5.2-.86L10 1z"/></svg>
              ${"number"==typeof r?r.toLocaleString():r}
            </span>
            ${a?H`
              <span class="stars">
                <svg viewBox="0 0 20 20" fill="currentColor"><path d="M3 17a1 1 0 011-1h12a1 1 0 110 2H4a1 1 0 01-1-1zm3.293-7.707a1 1 0 011.414 0L9 10.586V3a1 1 0 112 0v7.586l1.293-1.293a1 1 0 111.414 1.414l-3 3a1 1 0 01-1.414 0l-3-3a1 1 0 010-1.414z"/></svg>
                ${a.toLocaleString()}
              </span>
            `:""}
            ${"store"!==this.viewMode?H`
              <span style="font-size:10px;color:var(--secondary-text-color);display:flex;align-items:center;gap:3px;">
                <svg class="mini-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16z"/><polyline points="3.27 6.96 12 12.01 20.73 6.96"/><line x1="12" y1="22.08" x2="12" y2="12"/></svg>
                ${n?H`${e.installed_version||"?"} → <span style="color:var(--primary-color);font-weight:600;">${e.latest_version||"?"}</span>`:e.installed_version||ge("installed")}
              </span>
            `:""}
          </div>
        </div>

        ${"management"!==this.viewMode?H`
        <div class="actions">
          <button class="action-btn readme-btn" @click=${e=>this._handleAction(e,"readme")} title="README">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/><line x1="16" y1="13" x2="8" y2="13"/><line x1="16" y1="17" x2="8" y2="17"/></svg>
          </button>
          ${s?H`
            ${n?H`
              <button class="action-btn primary" @click=${e=>this._handleAction(e,"update")}>
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M23 4v6h-6M1 20v-6h6"/><path d="M3.51 9a9 9 0 0114.85-3.36L23 10M1 14l4.64 4.36A9 9 0 0020.49 15"/></svg>
                <span class="label">${ge("update")}</span>
              </button>
            `:""}
            ${"integration"===o?H`
              <button class="action-btn" @click=${t=>this._handleAction(t,e.config_entry_id?"configure":"add-integration")}>
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1 0 2.83 2 2 0 0 1-2.83 0l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-2 2 2 2 0 0 1-2-2v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83 0 2 2 0 0 1 0-2.83l.06-.06A1.65 1.65 0 0 0 4.68 15a1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1-2-2 2 2 0 0 1 2-2h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 0-2.83 2 2 0 0 1 2.83 0l.06.06A1.65 1.65 0 0 0 9 4.68a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 2-2 2 2 0 0 1 2 2v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 0 2 2 0 0 1 0 2.83l-.06.06A1.65 1.65 0 0 0 19.4 9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 2 2 2 2 0 0 1-2 2h-.09a1.65 1.65 0 0 0-1.51 1z"/></svg>
                <span class="label">${e.config_entry_id?ge("addIntegration"):ge("addIntegrationHint")}</span>
              </button>
            `:""}
            <button class="action-btn" @click=${e=>this._handleAction(e,"uninstall")} style="color:#f44336;border-color:#f44336;">
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="3 6 5 6 21 6"/><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/></svg>
              <span class="label">${ge("remove")}</span>
            </button>
          `:H`
            <button class="action-btn primary ${this._installing?"installing":""}"
                    @click=${e=>this._handleAction(e,"install")} ?disabled=${this._installing}>
              ${this._installing?H`<svg class="mini-icon spin" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 12a9 9 0 1 1-6.219-8.56"/></svg> ${ge("installing")}`:H`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></svg><span class="label">${ge("install")}</span>`}
            </button>
          `}
        </div>
        `:""}
      </div>
    `}}customElements.define("repo-card",Ut);class Bt extends se{static properties={_message:{type:String,state:!0},_confirmText:{type:String,state:!0},_cancelText:{type:String,state:!0},_danger:{type:Boolean,state:!0},_visible:{type:Boolean,state:!0}};constructor(){super(),this._message="",this._confirmText=ge("confirm"),this._cancelText=ge("cancel"),this._danger=!1,this._visible=!1,this._resolve=null}static styles=a`
    :host { display: contents; }
    .overlay {
      position: fixed; top: 0; left: 0; width: 100%; height: 100%;
      background: rgba(0,0,0,0.5); z-index: 10001;
      display: flex; align-items: center; justify-content: center;
      padding: 20px; box-sizing: border-box;
      animation: fadeIn 0.15s ease;
    }
    @keyframes fadeIn { from { opacity: 0; } to { opacity: 1; } }
    .dialog {
      background: var(--card-background-color, #fff);
      border-radius: 16px; padding: 24px;
      max-width: 380px; width: 100%;
      box-shadow: 0 20px 60px rgba(0,0,0,0.3);
      animation: slideUp 0.2s ease;
    }
    @keyframes slideUp { from { transform: translateY(20px); opacity: 0; } to { transform: translateY(0); opacity: 1; } }
    .message {
      font-size: 15px; color: var(--primary-text-color, #212121);
      line-height: 1.6; margin-bottom: 20px;
    }
    .actions { display: flex; gap: 10px; justify-content: flex-end; }
    .btn {
      padding: 10px 20px; border-radius: 10px;
      font-size: 14px; font-weight: 500; cursor: pointer;
      border: 1px solid var(--divider-color, #e0e0e0);
      background: var(--card-background-color, #fff);
      color: var(--primary-text-color, #212121);
      transition: all 0.2s; touch-action: manipulation;
    }
    .btn:hover { border-color: var(--primary-color); color: var(--primary-color); }
    .btn.danger {
      background: #f44336; border-color: #f44336; color: #fff;
    }
    .btn.danger:hover { opacity: 0.9; }
    @media (max-width: 768px) {
      .actions { flex-direction: column-reverse; }
      .btn { width: 100%; text-align: center; min-height: 44px; }
    }
  `;static show(e,{message:t,confirmText:i,cancelText:o,danger:r}={}){let a=e.shadowRoot?.querySelector("confirm-dialog");return a||(a=document.createElement("confirm-dialog"),e.shadowRoot.appendChild(a)),new Promise(e=>{a._resolve=e,a._message=t||"Are you sure?",a._confirmText=i||ge("confirm"),a._cancelText=o||ge("cancel"),a._danger=!!r,a._visible=!0})}_onConfirm(){this._visible=!1,this._resolve&&this._resolve(!0)}_onCancel(){this._visible=!1,this._resolve&&this._resolve(!1)}_onOverlayClick(e){e.target===e.currentTarget&&this._onCancel()}render(){return this._visible?H`
      <div class="overlay" @click=${this._onOverlayClick}>
        <div class="dialog">
          <div class="message">${this._message}</div>
          <div class="actions">
            <button class="btn" @click=${this._onCancel}>${this._cancelText}</button>
            <button class="btn ${this._danger?"danger":""}" @click=${this._onConfirm}>${this._confirmText}</button>
          </div>
        </div>
      </div>
    `:H``}}customElements.define("confirm-dialog",Bt);var Pt=Object.freeze({__proto__:null,ConfirmDialog:Bt});const Ht="hacs_vision_browse_state",jt="hacs_vision_view_mode";class Vt extends se{static properties={repos:{type:Array},total:{type:Number},search:{type:String},category:{type:String},statusFilter:{type:String},sort:{type:String},sortDir:{type:String},page:{type:Number},loading:{type:Boolean},categoryCounts:{type:Object},statusCounts:{type:Object},tagCounts:{type:Object},viewMode:{type:String},groupBy:{type:String},pageSize:{type:Number},_installingIds:{type:Object,state:!0},_searchText:{type:String,state:!0},_showAddRepo:{type:Boolean,state:!0},_newRepoUrl:{type:String,state:!0},_newRepoCategory:{type:String,state:!0},_addRepoInstalling:{type:Boolean,state:!0},_collapsedGroups:{type:Object,state:!0},_filterExpanded:{type:Boolean,state:!0},_favorites:{type:Array,state:!0},presetFilter:{type:String},presetTag:{type:String},pendingRestart:{type:Number},_selectedRepos:{type:Array,state:!0},_tagFilters:{type:Array,state:!0}};constructor(){super();const e=function(){try{return JSON.parse(localStorage.getItem(Ht)||"{}")}catch{return{}}}();this.repos=[],this.total=0,this.search=e.search||"",this.category=e.category||"",this.statusFilter=e.statusFilter||"",this.sort=e.sort||"stars",this.sortDir=e.sortDir||"desc",this.page=e.page||1,this.loading=!1,this.limit=e.pageSize||50,this.pageSize=this.limit,this.categoryCounts={},this.statusCounts={},this.tagCounts={},this._installingIds={},this._searchTimer=void 0,this._searchText=e.search||"",this.viewMode=localStorage.getItem(jt)||"card",this.groupBy=e.groupBy||"none",this._showAddRepo=!1,this._newRepoUrl="",this._newRepoCategory="integration",this._addRepoInstalling=!1,this._collapsedGroups={},this._filterExpanded=!1,this._favorites=[],this._selectedRepos=[],this._tagFilters=[],this.statusOptions=[{value:"",label:ge("statusAll")},{value:"installed",label:ge("statusInstalled")},{value:"not_installed",label:ge("statusNotInstalled")},{value:"update_available",label:ge("statusPendingUpgrade")},{value:"pending_restart",label:ge("statusPendingRestart")}],this.typeOptions=[{value:"",label:ge("typeAll")},{value:"integration",label:ge("typeIntegration")},{value:"plugin",label:ge("typePlugin")},{value:"theme",label:ge("typeTheme")},{value:"template",label:ge("typeTemplate")}],this.groupOptions=[{value:"none",label:ge("groupNone")},{value:"status",label:ge("groupStatus")},{value:"type",label:ge("groupType")}],this.sortColumns=[{key:"name",label:ge("colName")||"名称",sortable:!0},{key:"downloads",label:ge("colDownloads")||"下载",sortable:!0},{key:"stars",label:ge("colStars")||"星数",sortable:!0},{key:"last_updated",label:ge("colLastUpdated")||"更新时间",sortable:!0},{key:"installed_version",label:ge("colInstalledVer")||"已安装",sortable:!0},{key:"latest_version",label:ge("colAvailableVer")||"可用",sortable:!0},{key:"installed_at",label:ge("colInstalledAt")||"安装时间",sortable:!0},{key:"status",label:ge("colStatus")||"状态",sortable:!0}]}static styles=a`
    ${me()}

    :host { display: block; touch-action: manipulation; background: var(--primary-background-color); }

    /* ===== Controls Bar ===== */
    .controls {
      display: flex; align-items: center; gap: 10px;
      margin-bottom: 14px;
    }
    .controls-right {
      display: flex; align-items: center; gap: 6px; flex-shrink: 0;
    }
    .refresh-btn {
      padding: 8px; border: 1px solid var(--divider-color); border-radius: 10px;
      background: var(--card-background-color); color: var(--primary-text-color);
      cursor: pointer; display: flex; align-items: center; justify-content: center;
      transition: all 0.25s; width: 36px; height: 36px;
      touch-action: manipulation; flex-shrink: 0;
    }
    .refresh-btn:hover { border-color: var(--primary-color); color: var(--primary-color); }
    .refresh-btn svg { width: 16px; height: 16px; }

    /* ===== Sort Bar (both card and list mode) ===== */
    .sort-bar {
      display: flex; align-items: center;
      margin-bottom: 10px; padding: 6px 14px;
      background: var(--secondary-background-color, #f0f0f0);
      border-radius: 8px; flex-wrap: wrap; gap: 4px;
    }
    .sort-chips {
      display: flex; align-items: center; gap: 4px; flex-wrap: wrap;
    }
    .sort-chip {
      padding: 4px 10px; border: 1px solid var(--divider-color); border-radius: 14px;
      background: var(--card-background-color); color: var(--secondary-text-color);
      cursor: pointer; font-size: 11px; transition: all 0.2s; white-space: nowrap;
      touch-action: manipulation;
    }
    .sort-chip:hover { border-color: var(--primary-color); color: var(--primary-color); }
    .sort-chip.active { background: var(--primary-color); border-color: var(--primary-color); color: #fff; }
    .sort-chip .sort-dir { font-size: 9px; margin-left: 2px; }

    /* ===== View Mode Toggle ===== */
    .view-toggle {
      display: flex; border: 1px solid var(--divider-color); border-radius: 8px;
      overflow: hidden; flex-shrink: 0;
    }
    .view-toggle-btn {
      padding: 6px 10px; border: none; background: var(--card-background-color);
      color: var(--secondary-text-color); cursor: pointer; font-size: 14px;
      transition: all 0.2s; min-width: 36px; min-height: 36px;
      display: flex; align-items: center; justify-content: center;
      touch-action: manipulation;
    }
    .view-toggle-btn + .view-toggle-btn { border-left: 1px solid var(--divider-color); }
    .view-toggle-btn.active { background: var(--primary-color); color: #fff; }
    .view-toggle-btn:hover:not(.active) { color: var(--primary-color); }

    /* ===== Group By Select ===== */
    .group-select {
      padding: 6px 10px; border: 1px solid var(--divider-color); border-radius: 8px;
      background: var(--card-background-color); color: var(--primary-text-color);
      font-size: 12px; cursor: pointer; outline: none; flex-shrink: 0;
    }

    /* ===== Filter Row ===== */
    .filter-row {
      display: flex; gap: 16px; margin-bottom: 10px; align-items: flex-start;
    }
    .filter-row .filter-group { margin-bottom: 0; flex: 1; min-width: 0; }

    /* ===== Filter Groups ===== */
    .filter-group { margin-bottom: 10px; }
    .filter-label {
      font-size: 11px; font-weight: 600; color: var(--secondary-text-color);
      text-transform: uppercase; letter-spacing: 0.5px; margin-bottom: 6px;
    }
    .filter-chips {
      display: flex; gap: 6px; flex-wrap: wrap;
      overflow-x: auto; -webkit-overflow-scrolling: touch;
    }
    .filter-chips::-webkit-scrollbar { display: none; }
    .filter-chip {
      padding: 6px 12px; border: 1px solid var(--divider-color); border-radius: 18px;
      background: var(--card-background-color); color: var(--secondary-text-color);
      cursor: pointer; font-size: 12px; transition: all 0.25s; white-space: nowrap;
      touch-action: manipulation;
    }
    .filter-chip:hover { border-color: var(--primary-color); color: var(--primary-color); }
    .filter-chip.active { background: var(--primary-color); border-color: var(--primary-color); color: #fff; }
    .filter-chip .chip-count { font-size: 10px; opacity: 0.7; margin-left: 3px; }

    .mini-icon { width: 14px; height: 14px; vertical-align: -2px; display: inline; flex-shrink: 0; }
    .mini-icon.spin { animation: spin 1s linear infinite; }
    @keyframes spin { 100% { transform: rotate(360deg); } }

    /* ===== Add Custom Repo ===== */
    .add-repo-form {
      margin-bottom: 14px; padding: 16px;
      border: 1px solid var(--divider-color); border-radius: 14px;
      background: var(--card-background-color);
    }
    .form-row { display: flex; gap: 8px; margin-bottom: 10px; }
    .form-input {
      flex: 1; padding: 10px 12px; border: 1px solid var(--divider-color);
      border-radius: 10px; font-size: 13px; background: var(--card-background-color);
      color: var(--primary-text-color); outline: none;
    }
    .form-input:focus { border-color: var(--primary-color); }
    .form-select {
      padding: 10px 12px; border: 1px solid var(--divider-color); border-radius: 10px;
      font-size: 13px; background: var(--card-background-color);
      color: var(--primary-text-color); cursor: pointer; flex-shrink: 0;
    }
    .form-actions { display: flex; gap: 8px; }

    /* ===== List View (HACS-style data table) ===== */
    .list-view { width: 100%; overflow-x: auto; }
    .list-table { width: 100%; border-collapse: collapse; font-size: 13px; table-layout: auto; }
    .list-table th {
      text-align: left; padding: 10px 8px; font-size: 11px; font-weight: 600;
      color: var(--secondary-text-color); text-transform: uppercase;
      border-bottom: 2px solid var(--divider-color); white-space: nowrap;
      user-select: none; letter-spacing: 0.3px;
    }
    .list-table th.sortable { cursor: pointer; touch-action: manipulation; }
    .list-table th.sortable:hover { color: var(--primary-color); }
    .list-table th .sort-arrow { font-size: 9px; margin-left: 3px; opacity: 0.5; }
    .list-table th.active-sort .sort-arrow { opacity: 1; color: var(--primary-color); }
    .list-table td {
      padding: 10px 8px; border-bottom: 1px solid var(--divider-color);
      vertical-align: middle;
    }
    .list-table .name-cell,
    .list-table .desc-cell { overflow: hidden; text-overflow: ellipsis; white-space: nowrap; max-width: 0; }
    .list-table .name-cell { font-weight: 500; color: var(--primary-text-color); width: 100%; }
    .list-table .desc-cell { font-size: 11px; color: var(--secondary-text-color); }
    .custom-tag-list {
      display: inline-block; margin-top: 4px;
      font-size: 9px; padding: 1px 6px; border-radius: 4px;
      background: #ff6f00; color: #fff; font-weight: 700;
    }
    .topic-chips { display: flex; gap: 4px; flex-wrap: wrap; margin-top: 4px; }
    .topic-chip {
      font-size: 9px; padding: 1px 6px; border-radius: 4px;
      background: var(--secondary-background-color);
      color: var(--secondary-text-color); border: 1px solid var(--divider-color);
    }
    .list-table tr { cursor: pointer; transition: background 0.15s; }
    .list-table tbody tr:hover { background: var(--secondary-background-color); }

    .list-table .col-icon { width: 40px; }
    .list-table .icon-cell {
      width: 32px; height: 32px; border-radius: 6px;
      display: flex; align-items: center; justify-content: center;
      color: #fff; font-size: 14px; font-weight: 700;
      overflow: hidden;
    }
    .list-table .num-cell { font-size: 12px; color: var(--secondary-text-color); text-align: right; }
    .list-table .ver-cell { font-size: 12px; color: var(--secondary-text-color); white-space: nowrap; }
    .list-table .status-cell { font-size: 11px; }
    .status-badge {
      display: inline-block; padding: 2px 8px; border-radius: 10px; font-size: 10px; font-weight: 600;
    }
    .status-badge.installed { background: rgba(76,175,80,0.15); color: #4caf50; }
    .status-badge.pending-upgrade { background: rgba(255,152,0,0.15); color: #ff9800; }
    .status-badge.pending-restart { background: rgba(244,67,54,0.15); color: #f44336; }
    .status-badge.new { background: rgba(33,150,243,0.15); color: #2196f3; }
    .status-badge.default { background: rgba(158,158,158,0.1); color: #9e9e9e; }
    .list-table .actions-cell { white-space: nowrap; }
    .action-sm {
      padding: 4px 8px; border-radius: 6px; font-size: 11px;
      border: 1px solid var(--divider-color); background: var(--card-background-color);
      color: var(--primary-text-color); cursor: pointer; transition: all 0.2s;
      touch-action: manipulation;
    }
    .action-sm:hover { border-color: var(--primary-color); color: var(--primary-color); }
    .action-sm.primary { background: var(--primary-color); border-color: var(--primary-color); color: #fff; }

    /* ===== Group Headers ===== */
    .group-header {
      display: flex; align-items: center; gap: 8px;
      padding: 10px 14px; margin-top: 12px; margin-bottom: 4px;
      background: var(--secondary-background-color, #f0f0f0);
      border-radius: 8px; cursor: pointer; user-select: none;
      font-size: 13px; font-weight: 600; color: var(--primary-text-color);
      touch-action: manipulation;
    }
    .group-header:first-child { margin-top: 0; }
    .group-header .group-arrow { transition: transform 0.2s; font-size: 10px; }
    .group-header .group-arrow.collapsed { transform: rotate(-90deg); }
    .group-header .group-count { font-size: 11px; color: var(--secondary-text-color); font-weight: 400; margin-left: 4px; }

    /* ===== Pagination ===== */
    .pagination {
      display: flex; justify-content: center; align-items: center; gap: 12px;
      margin-top: 24px; padding: 12px 0;
    }
    .page-btn {
      padding: 8px 16px; border: 1px solid var(--divider-color); border-radius: 8px;
      background: var(--card-background-color); color: var(--primary-text-color);
      cursor: pointer; font-size: 13px; transition: all 0.2s; touch-action: manipulation;
    }
    .page-btn:hover:not(:disabled) { border-color: var(--primary-color); color: var(--primary-color); }
    .page-btn:disabled { opacity: 0.4; cursor: not-allowed; }
    .page-btn.primary { background: var(--primary-color); border-color: var(--primary-color); color: #fff; }
    .page-size-select {
      padding: 6px 8px; border: 1px solid var(--divider-color); border-radius: 6px;
      background: var(--card-background-color); color: var(--primary-text-color);
      font-size: 13px; margin-left: 8px; cursor: pointer;
    }
    .page-info { font-size: 13px; color: var(--secondary-text-color); }

    /* ===== Filter Toggle (mobile) ===== */
    .filter-toggle {
      display: none; width: 100%; padding: 10px 14px;
      border: 1px solid var(--divider-color); border-radius: 10px;
      background: var(--card-background-color); color: var(--primary-text-color);
      cursor: pointer; font-size: 13px; margin-bottom: 8px;
      justify-content: space-between; align-items: center;
      touch-action: manipulation;
    }
    .filter-toggle .toggle-arrow { transition: transform 0.2s; font-size: 10px; }
    .filter-toggle .toggle-arrow.expanded { transform: rotate(180deg); }
    .filter-toggle .active-filters {
      display: flex; gap: 4px; flex-wrap: wrap; margin-left: 8px;
    }
    .filter-toggle .active-filter-tag {
      font-size: 10px; padding: 2px 6px; border-radius: 8px;
      background: var(--primary-color); color: #fff;
    }

    /* ===== Responsive ===== */
    @media (max-width: 768px) {
      .controls { gap: 4px; margin-bottom: 6px; flex-wrap: wrap; }
      .search input { padding: 7px 10px 7px 34px; font-size: 13px; border-radius: 8px; }
      .controls-right { flex-wrap: wrap; }
      .sort-bar { padding: 6px 10px; font-size: 12px; gap: 4px; }
      .sort-chip { padding: 4px 8px; font-size: 11px; }
      .filter-toggle { display: flex; }
      .filter-row:not(.expanded) { display: none; }
      .filter-row.expanded { display: flex; }
      .filter-row { flex-direction: column; gap: 8px; }
      .filter-row .filter-group { margin-bottom: 0; }
      .filter-chips { flex-wrap: wrap; gap: 3px; }
      .filter-chip { padding: 4px 8px; font-size: 11px; }
      .chip-count { min-width: 16px; height: 16px; font-size: 10px; }
      .page-btn { min-height: 44px; }
      .list-table .col-downloads,
      .list-table .col-stars,
      .list-table .col-installed-ver,
      .list-table .col-available-ver,
      .list-table .col-installed-at { display: none; }
    }

    @media (max-width: 480px) {
      .controls-right { gap: 4px; }
      .filter-chips { gap: 4px; }
      .filter-chip { padding: 4px 8px; font-size: 10px; }
      .filter-label { font-size: 10px; margin-bottom: 4px; }
      .list-table .col-last-updated,
      .list-table .col-status { display: none; }
      .form-row { flex-direction: column; }
      .form-input, .form-select { width: 100%; box-sizing: border-box; }
      .form-actions { flex-direction: column; }
      .form-actions .btn { width: 100%; min-height: 44px; justify-content: center; }
    }

    .batch-bar {
      display: flex; align-items: center; gap: 8px; flex-wrap: wrap;
      padding: 8px 12px; margin: 6px 0;
      background: var(--primary-color, #03a9f4); color: #fff;
      border-radius: 8px; font-size: 13px; font-weight: 600;
    }
    .batch-bar-btn {
      padding: 4px 12px; border-radius: 4px; font-size: 11px; font-weight: 600;
      background: rgba(255,255,255,0.2); color: #fff;
      border: 1px solid rgba(255,255,255,0.4); cursor: pointer;
    }
    .batch-bar-btn:hover { background: rgba(255,255,255,0.35); }
    .batch-bar-btn.danger { border-color: #ff5252; color: #ff5252; }
    .restart-bar {
      display: flex; align-items: center; gap: 8px; flex-wrap: wrap;
      padding: 8px 12px; margin: 6px 0;
      background: rgba(244,67,54,0.1); border: 1px solid rgba(244,67,54,0.3);
      border-radius: 8px; font-size: 13px; font-weight: 600; color: #f44336;
    }
    .restart-bar .batch-bar-btn { background: #f44336; border-color: #f44336; color: #fff; }
  `;async connectedCallback(){super.connectedCallback(),await this._loadFavorites(),await this._load(),this.addEventListener("install",e=>this._handleInstall(e.detail.repo)),this.addEventListener("update",e=>this._handleUpdate(e.detail.repo)),this.addEventListener("uninstall",e=>this._handleUninstall(e.detail.repo)),this.addEventListener("configure",e=>this._handleConfigure(e.detail.repo)),this.addEventListener("add-integration",e=>this._handleAddIntegration(e.detail.repo)),this.addEventListener("favorite",e=>{const{isFavorite:t,repo:i}=e.detail,o=i?.id||i?.full_name;o&&(t&&!this._favorites.includes(o)?this._favorites=[...this._favorites,o]:t||(this._favorites=this._favorites.filter(e=>e!==o))),this._syncFavoriteCount()})}willUpdate(e){if(e.has("presetFilter")){const t=this.presetFilter;if(void 0===e.get("presetFilter")&&""===t)return;this.presetFilter="",this.statusFilter=t,this.page=1,this._persistState(),this._load()}if(e.has("presetTag")&&this.presetTag){const e=this.presetTag;this.presetTag="",this._tagFilters.includes(e)?this._tagFilters=this._tagFilters.filter(t=>t!==e):this._tagFilters=[...this._tagFilters,e],this.page=1,this._load()}}async _loadFavorites(){try{const e=await ce.getFavorites();this._favorites=Array.isArray(e)?e:e.favorites||[]}catch(e){this._favorites=[]}}_syncFavoriteCount(){this.requestUpdate()}_persistState(){!function(e){try{localStorage.setItem(Ht,JSON.stringify(e))}catch{}}({search:this.search,category:this.category,statusFilter:this.statusFilter,sort:this.sort,sortDir:this.sortDir,page:this.page,groupBy:this.groupBy,pageSize:this.pageSize})}async _handleInstall(e){const t=e.id||e.full_name;this._installingIds={...this._installingIds,[t]:!0};try{await ce.install(t,e.category),Ot(`${ge("installComplete")}: ${e.full_name||e.name}`,"success"),this.dispatchEvent(new CustomEvent("refresh-stats",{bubbles:!0,composed:!0})),this._load()}catch(e){Ot(`${ge("installFailed")}: ${e.message}`,"error")}delete this._installingIds[t],this._installingIds={...this._installingIds}}async _handleUpdate(e){try{const t=await ce.update([e.id||e.full_name]);t?.success?.length>0?Ot(`${ge("updateComplete")}: ${e.full_name||e.name}`,"success"):Ot(`${ge("updateFailed")}: ${e.full_name||e.name}`,"error"),this.dispatchEvent(new CustomEvent("refresh-stats",{bubbles:!0,composed:!0})),this._load()}catch(e){console.error("Update failed",e),Ot(`${ge("updateFailed")}: ${e.message}`,"error")}}async _handleUninstall(e){if(await Bt.show(this,{message:`${ge("confirmRemove")} ${e.full_name||e.name}?`,confirmText:ge("remove"),danger:!0}))try{await ce.remove(e.id||e.full_name),this.dispatchEvent(new CustomEvent("refresh-stats",{bubbles:!0,composed:!0})),this._load()}catch(e){console.error("Uninstall failed",e)}}_handleConfigure(e){const t=e.domain||(e.full_name||"").split("/")[1]||"";this.dispatchEvent(new CustomEvent("open-options-flow",{detail:{entryId:e.config_entry_id,domain:t},bubbles:!0,composed:!0}))}_handleAddIntegration(e){const t=e.domain||(e.full_name||"").split("/")[1]||"";this.dispatchEvent(new CustomEvent("open-flow",{detail:{domain:t},bubbles:!0,composed:!0}))}async _load(){this.loading=!0;try{const e=!(!this.search||!this.search.match(/github\.com\/([^/]+\/[^/\s?#]+)/i)&&!this.search.match(/^[a-zA-Z0-9_-]+\/[a-zA-Z0-9_.-]+$/));let t=this.search;if(e){const e=this.search.match(/github\.com\/([^/]+\/[^/\s?#]+)/i);e&&(t=e[1].replace(/\.git$/,""))}const i=await ce.listRepositories({search:t,category:this.category,sort:this.sort,sortDir:this.sortDir,page:this.page,limit:this.limit,status:this.statusFilter});this.repos=i.repositories||[],this.total=i.total||0,this.categoryCounts=i.category_counts||{},this.statusCounts=i.status_counts||{},this.tagCounts=i.tag_counts||{},this.tagCounts={...this.tagCounts,favorites:this._favorites.length}}catch(e){console.error("Browse load error",e),this.repos=[],this.total=0}this.loading=!1}_onSearch(e){this._searchText=e.target.value,clearTimeout(this._searchTimer),this._searchTimer=setTimeout(()=>{this.search=this._searchText,this.page=1,this._persistState(),this._load()},300)}_clearSearch(){this._searchText="",this.search="",this.page=1,this._persistState(),this._load()}_onStatusFilter(e){this.statusFilter=e,this.page=1,this._persistState(),this._load()}_onTypeFilter(e){this.category=e,this.page=1,this._persistState(),this._load()}_onTagFilter(e){this._tagFilters.includes(e)?this._tagFilters=this._tagFilters.filter(t=>t!==e):this._tagFilters=[...this._tagFilters,e],this.page=1,this._load()}_onSortColumn(e){this.sort===e?this.sortDir="desc"===this.sortDir?"asc":"desc":(this.sort=e,this.sortDir="name"===e?"asc":"desc"),this.page=1,this._persistState(),this._load()}_onGroupChange(e){this.groupBy=e.target.value,this._persistState()}_onViewModeChange(e){this.viewMode=e;try{localStorage.setItem(jt,e)}catch{}}_toggleGroup(e){this._collapsedGroups={...this._collapsedGroups,[e]:!this._collapsedGroups[e]}}_goPage(e){this.page=e,this._persistState(),this._load()}_onPageSizeChange(e){this.pageSize=parseInt(e.target.value,10),this.limit=this.pageSize,this.page=1,this._persistState(),this._load()}_refresh(){this.page=1,this._persistState(),this._load()}async _addRepo(){const e=this._parseRepoUrl(this._newRepoUrl);if(e){this._addRepoInstalling=!0;try{const t=await ce.addCustomRepo(e,this._newRepoCategory);t.success?(Ot(`${ge("addSuccess")}: ${e}`,"success"),this._newRepoUrl="",this._showAddRepo=!1,this._load(),this.dispatchEvent(new CustomEvent("refresh-stats",{bubbles:!0,composed:!0}))):Ot(`${ge("addFailed")}: ${t.error}`,"error")}catch(e){Ot(`${ge("addFailed")}: ${e.message}`,"error")}this._addRepoInstalling=!1}else Ot(ge("invalidRepoUrl"),"error")}_parseRepoUrl(e){const t=e.match(/github\.com\/([^/]+\/[^/\s?#]+)/i);return t?t[1].replace(/\.git$/,""):/^[a-zA-Z0-9_-]+\/[a-zA-Z0-9_.-]+$/.test(e)?e:null}_getRepoStatus(e){return e.pending_restart?"pending_restart":e.installed&&(e.has_update||e.installed_version&&e.latest_version&&e.installed_version!==e.latest_version)?"pending-upgrade":e.installed?"installed":"default"}_getStatusBadge(e){const t={installed:{label:ge("statusInstalled"),cls:"installed"},"pending-upgrade":{label:ge("statusPendingUpgrade"),cls:"pending-upgrade"},"pending-restart":{label:ge("statusPendingRestart"),cls:"pending-restart"},default:{label:ge("statusDefault"),cls:"default"}}[e]||{label:e,cls:"default"};return H`<span class="status-badge ${t.cls}">${t.label}</span>`}_getStatusLabel(e){return{installed:ge("statusInstalled"),not_installed:ge("statusDefault"),update_available:ge("statusPendingUpgrade"),pending_restart:ge("statusPendingRestart")}[e]||e}_applyFilters(e){return this._tagFilters.length>0?e.filter(e=>{for(const t of this._tagFilters){if("favorites"===t&&!this._favorites.includes(e.id||e.full_name))return!1;if("new"===t&&!e.new&&"new"!==e.status)return!1;if("custom"===t&&!e.is_custom)return!1}return!0}):e}_getFiltered(){let e=this._applyFilters(this.repos);if(!this.search)return e;const t=this.search.toLowerCase();let i=null;const o=t.match(/github\.com\/([^/]+\/[^/\s?#]+)/i);return o&&(i=o[1].replace(/\.git$/,"").toLowerCase()),e.filter(e=>{const o=(e.full_name||"").toLowerCase(),r=(e.name||"").toLowerCase(),a=(e.description||"").toLowerCase(),s=(e.authors||[]).join(",").toLowerCase(),n=(e.manifest_name||e.repository_manifest?.name||"").toLowerCase();return!!(o.includes(t)||r.includes(t)||a.includes(t)||s.includes(t))||(!(!i||o!==i&&!o.includes(i))||!!n.includes(t))})}_groupRepos(e){if("none"===this.groupBy)return null;const t={};for(const i of e){let e;e="status"===this.groupBy?this._getRepoStatus(i):"type"===this.groupBy&&i.category||"other",t[e]||(t[e]=[]),t[e].push(i)}const i=["pending-restart","pending-upgrade","installed","default"],o=["integration","plugin","theme","template","other"],r=Object.keys(t);return"status"===this.groupBy?r.sort((e,t)=>i.indexOf(e)-i.indexOf(t)):"type"===this.groupBy&&r.sort((e,t)=>o.indexOf(e)-o.indexOf(t)),r.map(e=>({key:e,label:"status"===this.groupBy?this._getStatusLabel(e):this._getCategoryLabel(e),repos:t[e]}))}_getCategoryLabel(e){return{integration:ge("catIntegration"),plugin:ge("catPlugin"),theme:ge("catTheme"),template:ge("catTemplate"),other:e}[e]||e}_formatDate(e){if(!e)return"";try{const t=new Date(e),i=new Date-t,o=Math.floor(i/864e5);return 0===o?ge("today")||"今天":1===o?ge("yesterday")||"昨天":o<30?`${o}d`:o<365?`${Math.floor(o/30)}mo`:`${Math.floor(o/365)}y`}catch{return""}}_toggleSelect(e){this._selectedRepos.includes(e)?this._selectedRepos=this._selectedRepos.filter(t=>t!==e):this._selectedRepos=[...this._selectedRepos,e]}_isAllSelected(){const e=this._getFiltered();return e.length>0&&this._selectedRepos.length===e.length}_toggleSelectAll(){const e=this._getFiltered();this._isAllSelected()?this._selectedRepos=[]:this._selectedRepos=e.map(e=>e.full_name).filter(Boolean)}async _batchDo(e){if(0===this._selectedRepos.length)return;const t=this._selectedRepos.map(e=>{const t=this.repos.find(t=>t.full_name===e);return{repository:e,category:t?.category||"integration"}});if("remove"===e){const{ConfirmDialog:e}=await Promise.resolve().then(function(){return Pt});if(!await e.show(this,{message:ge("batchRemoveConfirm",{n:t.length}),confirmText:ge("batchRemove"),danger:!0}))return}try{let i;Ot(ge("batchInProgress"),"info"),i="install"===e?await ce.batchInstall(t):"update"===e?await ce.update(t.map(e=>e.repository)):await ce.batchRemove(t.map(e=>e.repository)),Ot(ge("batchComplete"),"success"),this._selectedRepos=[],this._load()}catch(t){Ot(`${e} failed: ${t.message}`,"error")}}async _restartHA(){const{ConfirmDialog:e}=await Promise.resolve().then(function(){return Pt});if(await e.show(this,{message:this.t?.("restartConfirm"),confirmText:this.t?.("restartHA"),danger:!0}))try{await ce.restartHA(),Ot(this.t?.("haRestarting"),"info")}catch(e){Ot(`${this.t?.("restartFailed")}: ${e.message}`,"error")}}_renderRepoList(e){return"list"===this.viewMode?H`<div class="list-view">${this._renderListTable(e)}</div>`:H`<div class="grid">${e.map(e=>H`
      <repo-card .repo=${e} ._installing=${!!this._installingIds?.[e.id||e.full_name]}
        .favorites=${this._favorites}
        ?showCheckbox=${!0} ?selected=${this._selectedRepos.includes(e.full_name)}
        @check-change=${e=>{e.detail?.fullName&&this._toggleSelect(e.detail.fullName)}}>
      </repo-card>
    `)}</div>`}_renderListTable(e){const t=e=>this.sort!==e?"":"desc"===this.sortDir?" ▼":" ▲",i=e=>"sortable "+(this.sort===e?"active-sort":"");return H`
      <table class="list-table">
        <thead>
          <tr>
            <th class="col-icon"></th>
            <th class="${i("name")}" @click=${()=>this._onSortColumn("name")}>${ge("colName")||"名称"}<span class="sort-arrow">${t("name")}</span></th>
            <th class="${i("downloads")} col-downloads" @click=${()=>this._onSortColumn("downloads")}>${ge("colDownloads")||"下载"}<span class="sort-arrow">${t("downloads")}</span></th>
            <th class="${i("stars")} col-stars" @click=${()=>this._onSortColumn("stars")}>${ge("colStars")||"星数"}<span class="sort-arrow">${t("stars")}</span></th>
            <th class="${i("last_updated")} col-last-updated" @click=${()=>this._onSortColumn("last_updated")}>${ge("colLastUpdated")||"更新"}<span class="sort-arrow">${t("last_updated")}</span></th>
            <th class="${i("installed_version")} col-installed-ver" @click=${()=>this._onSortColumn("installed_version")}>${ge("colInstalledVer")||"已安装"}<span class="sort-arrow">${t("installed_version")}</span></th>
            <th class="${i("latest_version")} col-available-ver" @click=${()=>this._onSortColumn("latest_version")}>${ge("colAvailableVer")||"可用"}<span class="sort-arrow">${t("latest_version")}</span></th>
            <th class="${i("installed_at")} col-installed-at" @click=${()=>this._onSortColumn("installed_at")}>${ge("colInstalledAt")||"安装时间"}<span class="sort-arrow">${t("installed_at")}</span></th>
            <th class="col-status">${ge("colStatus")||"状态"}</th>
            <th class="actions-cell"></th>
          </tr>
        </thead>
        <tbody>
          ${e.map(e=>this._renderListRow(e))}
        </tbody>
      </table>
    `}_renderListRow(e){const t=fe(e.category||"integration"),i=e.manifest_name||e.repository_manifest?.name||e.full_name||e.name||"?",o=e.stars||e.stargazers_count||0,r=e.downloads||0,a=this._getRepoStatus(e),s=e.installed||!1,n="pending-upgrade"===a,l=e.id||e.full_name,c=!!this._installingIds?.[l];return H`
      <tr @click=${()=>this._handleDetail(e)}>
        <td class="col-icon"><div class="icon-cell" style="background:${t}">
          ${e.domain&&"integration"===e.category?H`
              <img src="https://brands.home-assistant.io/${e.domain}/icon.png" style="width:100%;height:100%;object-fit:cover;" @error=${e=>{e.target.style.display="none",e.target.nextSibling.style.display="flex"}}>
              <span style="display:none">${i.charAt(0).toUpperCase()}</span>
            `:i.charAt(0).toUpperCase()}
        </div></td>
        <td class="name-cell">${i}<br><span class="desc-cell">${e.description||""}</span>
          ${e.is_custom?H`<span class="custom-tag-list">${ge("customBadge")}</span>`:""}
          ${e.topics&&e.topics.length?H`<br><span class="topic-chips">${e.topics.slice(0,4).map(e=>H`<span class="topic-chip">${e}</span>`)}</span>`:""}
        </td>
        <td class="num-cell col-downloads">${r?r.toLocaleString():"-"}</td>
        <td class="num-cell col-stars"><svg viewBox="0 0 20 20" fill="#ff9800" width="14" height="14" style="vertical-align:middle;"><path d="M10 1l2.39 4.84L17.6 6.7l-3.8 3.71.9 5.26L10 13.27l-4.7 2.46.9-5.26L2.4 6.7l5.2-.86L10 1z"/></svg> ${"number"==typeof o?o.toLocaleString():o}</td>
        <td class="ver-cell col-last-updated">${this._formatDate(e.last_updated)}</td>
        <td class="ver-cell col-installed-ver">${s&&e.installed_version||"-"}</td>
        <td class="ver-cell col-available-ver">${e.latest_version||"-"}</td>
        <td class="ver-cell col-installed-at">${e.installed_at?this._formatDate(e.installed_at):"-"}</td>
        <td class="status-cell col-status">${this._getStatusBadge(a)}</td>
        <td class="actions-cell">
          ${s?H`
            ${n?H`<button class="action-sm primary" @click=${t=>{t.stopPropagation(),this._handleUpdate(e)}}>${ge("update")}</button>`:""}
          `:H`
            <button class="action-sm primary ${c?"installing":""}" @click=${t=>{t.stopPropagation(),this._handleInstall(e)}} ?disabled=${c}>${c?H`<svg class="mini-icon spin" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 12a9 9 0 1 1-6.219-8.56"/></svg>`:ge("install")}</button>
          `}
        </td>
      </tr>
    `}render(){const e=Math.ceil(this.total/this.limit),t=this._getFiltered(),i=this._groupRepos(t);return H`
      <!-- Controls: Search + Action Buttons -->
      <div class="controls">
        <div class="search">
          <svg class="search-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <circle cx="11" cy="11" r="8"/><path d="M21 21l-4.35-4.35"/>
          </svg>
          <input type="text" placeholder="${ge("searchPlaceholder")}" .value=${this._searchText} @input=${this._onSearch} />
          ${this.search?H`<button class="search-clear" @click=${this._clearSearch}>✕</button>`:""}
        </div>
        <div class="controls-right">
          <div class="view-toggle">
            <button class="view-toggle-btn ${"card"===this.viewMode?"active":""}" @click=${()=>this._onViewModeChange("card")} title="${ge("viewCard")}">${ge("viewCard")}</button>
            <button class="view-toggle-btn ${"list"===this.viewMode?"active":""}" @click=${()=>this._onViewModeChange("list")} title="${ge("viewList")}">${ge("viewList")}</button>
          </div>
          <select class="group-select" @change=${this._onGroupChange} .value=${this.groupBy}>
            ${this.groupOptions.map(e=>H`<option value=${e.value}>${ge("groupBy")}: ${e.label}</option>`)}
          </select>
          <button class="refresh-btn" @click=${this._refresh} title="${ge("refreshTitle")}">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
              <path d="M23 4v6h-6M1 20v-6h6"/><path d="M3.51 9a9 9 0 0114.85-3.36L23 10M1 14l4.64 4.36A9 9 0 0020.49 15"/>
            </svg>
          </button>
          <button class="btn primary" style="padding:6px 12px;font-size:12px;min-height:44px;" @click=${()=>{this._showAddRepo=!this._showAddRepo}}>${ge("addCustomRepo")}</button>
        </div>
      </div>

      <!-- Add Custom Repo Form -->
      ${this._showAddRepo?H`
        <div class="add-repo-form">
          <div class="form-row">
            <input class="form-input" type="text" placeholder="${ge("repoUrl")}" .value=${this._newRepoUrl} @input=${e=>{this._newRepoUrl=e.target.value}} @keydown=${e=>{"Enter"===e.key&&this._addRepo()}}>
            <select class="form-select" .value=${this._newRepoCategory} @change=${e=>{this._newRepoCategory=e.target.value}}>
              <option value="integration">${ge("catIntegration")}</option><option value="plugin">${ge("catPlugin")}</option>
              <option value="theme">${ge("catTheme")}</option><option value="template">${ge("catTemplate")}</option>
            </select>
          </div>
          <div class="form-actions">
            <button class="btn primary" @click=${this._addRepo} ?disabled=${this._addRepoInstalling}>${this._addRepoInstalling?ge("installing"):ge("add")}</button>
            <button class="btn" @click=${()=>{this._showAddRepo=!1}}>${ge("cancel")}</button>
          </div>
        </div>
      `:""}

      <!-- Filter Toggle (mobile: tap to expand) -->
      <button class="filter-toggle" @click=${()=>{this._filterExpanded=!this._filterExpanded}}>
        <span>${ge("filterStatus")||"状态"} / ${ge("filterTags")||"标记"} / ${ge("filterType")||"类型"}</span>
        <span class="active-filters">
          ${this.statusFilter?H`<span class="active-filter-tag">${this._getStatusLabel(this.statusFilter)}</span>`:""}
          ${this.category?H`<span class="active-filter-tag">${this._getCategoryLabel(this.category)}</span>`:""}
        </span>
        <span class="toggle-arrow ${this._filterExpanded?"expanded":""}">▼</span>
      </button>

      <!-- Filters: Status + Tags + Type in one row on desktop -->
      <div class="filter-row ${this._filterExpanded?"expanded":""}">
        <div class="filter-group">
          <div class="filter-label">${ge("filterStatus")}</div>
          <div class="filter-chips">
            ${this.statusOptions.filter(e=>""===e.value||(this.statusCounts[e.value]??0)>0).map(e=>H`
              <button class="filter-chip ${this.statusFilter===e.value?"active":""}" @click=${()=>this._onStatusFilter(e.value)}>${e.label}${void 0!==this.statusCounts[e.value]?H`<span class="chip-count">${this.statusCounts[e.value]}</span>`:""}</button>
            `)}
          </div>
        </div>
        <div class="filter-group">
          <div class="filter-label">${ge("filterTags")}</div>
          <div class="filter-chips">
            <button class="filter-chip tag-chip ${this._tagFilters.includes("favorites")?"active":""}" @click=${()=>this._onTagFilter("favorites")}>
              ${ge("tagFavorites")}<span class="chip-count">${this.tagCounts?.favorites??0}</span>
            </button>
            <button class="filter-chip tag-chip ${this._tagFilters.includes("new")?"active":""}" @click=${()=>this._onTagFilter("new")}>
              ${ge("tagNew")}<span class="chip-count">${this.tagCounts?.new??0}</span>
            </button>
            <button class="filter-chip tag-chip ${this._tagFilters.includes("custom")?"active":""}" @click=${()=>this._onTagFilter("custom")}>
              ${ge("tagCustom")}<span class="chip-count">${this.tagCounts?.custom??0}</span>
            </button>
          </div>
        </div>
        <div class="filter-group">
          <div class="filter-label">${ge("filterType")}</div>
          <div class="filter-chips">
            ${this.typeOptions.filter(e=>""===e.value||(this.categoryCounts[e.value]??0)>0).map(e=>H`
              <button class="filter-chip ${this.category===e.value?"active":""}" @click=${()=>this._onTypeFilter(e.value)}>
                ${e.label}${void 0!==this.categoryCounts[e.value]?H`<span class="chip-count">${this.categoryCounts[e.value]}</span>`:""}
              </button>
            `)}
          </div>
        </div>
      </div>

      <!-- Restart Bar — between filters and batch bar -->
      ${(this.pendingRestart??0)>0?H`
      <div class="restart-bar">
        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M21.5 2v6h-6M2.5 22v-6h6"/><path d="M3.67 10.5a8 8 0 0114.7-2.17L21.5 8M2.5 16l3.13 3.67a8 8 0 0014.7-2.17"/></svg>
        <span>${ge("statusPendingRestart")}: ${this.pendingRestart}</span>
        <button class="batch-bar-btn" @click=${()=>this._restartHA()}>${ge("restartHA")}</button>
        <button class="batch-bar-btn" style="background:transparent;border-color:#f44336;color:#f44336;" @click=${()=>this._onStatusFilter("pending_restart")}>${ge("viewDetail")}</button>
      </div>
      `:""}

      <!-- Batch Action Bar -->
      ${this._selectedRepos.length>0?H`
        <div class="batch-bar">
          <span>${ge("batchSelected",{n:this._selectedRepos.length})}</span>
          <button class="batch-bar-btn" @click=${()=>this._batchDo("update")}
            ?disabled=${!this._selectedRepos.some(e=>{const t=this.repos.find(t=>t.full_name===e);return t?.installed})}>
            ${ge("batchUpdate")}
          </button>
          <button class="batch-bar-btn" @click=${()=>this._batchDo("install")}>${ge("batchInstall")}</button>
          <button class="batch-bar-btn danger" @click=${()=>this._batchDo("remove")}>${ge("batchRemove")}</button>
          <button class="batch-bar-btn" @click=${()=>{this._selectedRepos=[]}}>${ge("cancel")}</button>
        </div>
      `:""}

      <!-- Sort Bar (always visible, both card and list mode) -->
      <div class="sort-bar">
        <div class="sort-chips">
          ${this.sortColumns.map(e=>H`
            <button class="sort-chip ${this.sort===e.key?"active":""}" @click=${()=>this._onSortColumn(e.key)}>
              ${e.label}${this.sort===e.key?H`<span class="sort-dir">${"desc"===this.sortDir?"▼":"▲"}</span>`:""}
            </button>
          `)}
        </div>
      </div>

      <!-- Select All + Results Count -->
      <div style="display:flex;align-items:center;gap:12px;padding:8px 0;margin-bottom:4px;">
        <label style="display:flex;align-items:center;gap:6px;font-size:13px;cursor:pointer;user-select:none;">
          <input type="checkbox" .checked=${this._isAllSelected()}
                 @click=${e=>e.stopPropagation()}
                 @change=${this._toggleSelectAll}
                 style="width:16px;height:16px;cursor:pointer;">
          ${ge("selectAll")||"全选"}
        </label>
        <span style="font-size:13px;color:var(--secondary-text-color);">
          共 <strong>${t.length}</strong> 个
          ${this._selectedRepos.length>0?H`| <strong>${this._selectedRepos.length}</strong> 已选`:""}
        </span>
      </div>

      <!-- Content -->
      ${this.loading?H`
        <div class="skeleton-grid">
          ${[1,2,3,4,5,6].map(()=>H`
            <div class="skeleton-card">
              <div class="skeleton-card-img"></div>
              <div class="skeleton-card-body">
                <div class="skeleton-line wide"></div>
                <div class="skeleton-line medium"></div>
                <div class="skeleton-line" style="width:40%"></div>
              </div>
            </div>
          `)}
        </div>
      `:0===t.length?H`
        <div class="empty">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><rect x="3" y="3" width="18" height="18" rx="2"/><circle cx="8.5" cy="8.5" r="1.5"/><polyline points="21 15 16 10 5 21"/></svg>
          <div>${this.search?ge("noMatch"):ge("noData")}</div>
        </div>
      `:H`

        ${i?H`
          ${i.map(e=>H`
            <div class="group-header" @click=${()=>this._toggleGroup(e.key)}>
              <span class="group-arrow ${this._collapsedGroups[e.key]?"collapsed":""}">▼</span>
              ${e.label}<span class="group-count">(${e.repos.length})</span>
            </div>
            ${this._collapsedGroups[e.key]?"":this._renderRepoList(e.repos)}
          `)}
        `:H`${this._renderRepoList(t)}`}

        ${e>1?H`
          <div class="pagination">
            <button class="page-btn" ?disabled=${this.page<=1} @click=${()=>this._goPage(this.page-1)}>${ge("prevPage")}</button>
            <span class="page-info">${ge("page")} ${this.page} / ${e}</span>
            <button class="page-btn primary" ?disabled=${this.page>=e} @click=${()=>this._goPage(this.page+1)}>${ge("nextPage")}</button>
            <select class="page-size-select" .value=${String(this.pageSize)} @change=${this._onPageSizeChange}>
              <option value="20">20</option>
              <option value="50">50</option>
              <option value="100">100</option>
              <option value="200">200</option>
            </select>
          </div>
        `:""}
      `}
    `}}customElements.define("browse-view",Vt);class qt extends se{static properties={updates:{type:Array},loading:{type:Boolean},updating:{type:Boolean},search:{type:String},_installingIds:{type:Object,state:!0},_changelogs:{type:Object,state:!0},_searchText:{type:String,state:!0},_selectedIds:{type:Object,state:!0},_selectedRepos:{type:Array,state:!0},_batchMode:{type:Boolean,state:!0},_viewMode:{type:String,state:!0}};constructor(){super(),this.updates=[],this.loading=!1,this.updating=!1,this.search="",this._searchTimer=null,this._installingIds={},this._changelogs={},this._changelogsLoading={},this._expandedChangelogs={},this._searchText="",this._selectedIds={},this._selectedRepos=[],this._batchMode=!1;const e=localStorage.getItem("hacs_vision_view_mode");this._viewMode=e||"card"}static styles=[me(),a`
      :host { display: block; touch-action: manipulation; background: var(--primary-background-color); }

      .search { min-width: 160px; }

      .card {
        border: 1px solid var(--divider-color); border-radius: 14px;
        background: var(--card-background-color); overflow: hidden;
        padding: 16px; transition: all 0.2s; cursor: pointer;
        display: flex; flex-direction: column; min-height: 220px;
      }
      .card:hover { border-color: var(--primary-color); }

      .card-header { display: flex; justify-content: space-between; align-items: flex-start; margin-bottom: 8px; }
      .card-left { display: flex; align-items: center; gap: 8px; min-width: 0; flex: 1; }
      .card-name { font-size: 14px; font-weight: 600; color: var(--primary-text-color); word-break: break-all; }
      .card-name .category-badge {
        display: inline-block; font-size: 9px; padding: 2px 7px;
        border-radius: 4px; background: rgba(var(--rgb-primary-color), 0.08);
        color: var(--primary-color); margin-left: 6px; vertical-align: middle;
      }

      .version-row { display: flex; gap: 12px; margin-bottom: 12px; }
      .version-item { flex: 1; text-align: center; padding: 8px; border-radius: 8px; background: var(--secondary-background-color); }
      .version-label { font-size: 10px; color: var(--secondary-text-color); text-transform: uppercase; margin-bottom: 4px; }
      .version-value { font-size: 14px; font-weight: 700; }
      .version-value.old { color: var(--warning-color, #ff8f00); }
      .version-value.new { color: var(--success-color, #0f9d58); }

      .card-desc { font-size: 12px; color: var(--secondary-text-color); margin-bottom: 12px; line-height: 1.5; }

      /* Multi-select checkbox */
      .checkbox {
        width: 18px; height: 18px; border-radius: 4px;
        border: 2px solid var(--secondary-text-color); cursor: pointer;
        display: flex; align-items: center; justify-content: center;
        flex-shrink: 0; transition: all 0.2s; background: transparent;
        -webkit-appearance: none; appearance: none; touch-action: manipulation;
      }
      .checkbox:checked {
        background: var(--primary-color); border-color: var(--primary-color);
      }
      .checkbox:checked::after {
        content: '✓'; color: #fff; font-size: 12px; font-weight: 700;
      }
      .select-all {
        display: flex; align-items: center; gap: 6px;
        font-size: 12px; color: var(--secondary-text-color); cursor: pointer;
        touch-action: manipulation; user-select: none;
      }
      .select-all:hover { color: var(--primary-text-color); }

      .btn.primary { width: 100%; padding: 10px; border-radius: 10px; font-size: 13px; font-weight: 600; margin-top: auto; }
      .btn.primary:hover { opacity: 0.9; }
      /* F3: Progress button pulse */
      .btn.primary.installing {
        opacity: 0.7; cursor: not-allowed;
        animation: btnPulse 1.5s infinite;
      }
      @keyframes btnPulse { 0%, 100% { opacity: 0.7; } 50% { opacity: 0.45; } }

      /* F6: Changelog preview */
      .changelog-preview {
        margin-top: 8px; padding: 10px 12px;
        background: var(--secondary-background-color);
        border-radius: 8px; font-size: 12px;
      }
      .changelog-preview-title { font-weight: 600; margin-bottom: 6px; color: var(--primary-text-color); }
      .changelog-preview-body {
        color: var(--secondary-text-color); white-space: pre-wrap;
        line-height: 1.5; max-height: 80px; overflow: hidden;
      }
      .changelog-preview-link {
        color: var(--primary-color); font-size: 11px; text-decoration: none;
        display: inline-block; margin-top: 6px;
      }
      .changelog-preview-link:hover { text-decoration: underline; }
      .changelog-preview-body.expanded { max-height: none; }
      .changelog-expand-btn {
        display: inline-block; margin-top: 6px; margin-right: 10px;
        color: var(--primary-color); font-size: 11px; cursor: pointer;
        background: none; border: none; padding: 0;
      }
      .changelog-expand-btn:hover { text-decoration: underline; }

      .mini-icon { width: 14px; height: 14px; vertical-align: -2px; display: inline; flex-shrink: 0; }
      .mini-icon.spin { animation: spin 1s linear infinite; }
      @keyframes spin { 100% { transform: rotate(360deg); } }

      /* ===== View Mode Toggle ===== */
      .view-toggle {
        display: flex; border: 1px solid var(--divider-color); border-radius: 8px;
        overflow: hidden; flex-shrink: 0;
      }
      .view-toggle-btn {
        padding: 6px 10px; border: none; background: var(--card-background-color);
        color: var(--secondary-text-color); cursor: pointer; font-size: 14px;
        transition: all 0.2s; min-width: 36px; min-height: 36px;
        display: flex; align-items: center; justify-content: center;
        touch-action: manipulation;
      }
      .view-toggle-btn + .view-toggle-btn { border-left: 1px solid var(--divider-color); }
      .view-toggle-btn.active { background: var(--primary-color); color: #fff; }
      .view-toggle-btn:hover:not(.active) { color: var(--primary-color); }

      /* ===== List View (HACS-style table) ===== */
      .list-view { width: 100%; overflow-x: auto; }
      .list-table { width: 100%; border-collapse: collapse; font-size: 13px; table-layout: auto; }
      .list-table th {
        text-align: left; padding: 10px 8px; font-size: 11px; font-weight: 600;
        color: var(--secondary-text-color); text-transform: uppercase;
        border-bottom: 2px solid var(--divider-color); white-space: nowrap;
        user-select: none; letter-spacing: 0.3px;
      }
      .list-table td {
        padding: 10px 8px; border-bottom: 1px solid var(--divider-color);
        vertical-align: middle;
      }
      .list-table .col-icon { width: 40px; }
      .list-table .icon-cell {
        width: 32px; height: 32px; border-radius: 6px;
        display: flex; align-items: center; justify-content: center;
        color: #fff; font-size: 14px; font-weight: 700;
        overflow: hidden;
      }
      .list-table .name-cell {
        font-weight: 500; color: var(--primary-text-color); width: 100%;
        overflow: hidden; text-overflow: ellipsis; white-space: nowrap;
      }
      .list-table .desc-cell {
        font-size: 11px; color: var(--secondary-text-color);
        overflow: hidden; text-overflow: ellipsis; white-space: nowrap; max-width: 0;
      }
      .custom-tag-list {
        display: inline-block; margin-top: 4px;
        font-size: 9px; padding: 1px 6px; border-radius: 4px;
        background: #ff6f00; color: #fff; font-weight: 700;
      }
      .topic-chips { display: flex; gap: 4px; flex-wrap: wrap; margin-top: 4px; }
      .topic-chip {
        font-size: 9px; padding: 1px 6px; border-radius: 4px;
        background: var(--secondary-background-color);
        color: var(--secondary-text-color); border: 1px solid var(--divider-color);
      }
      .list-table tr { cursor: pointer; transition: background 0.15s; }
      .list-table tbody tr:hover { background: var(--secondary-background-color); }

      .status-badge {
        display: inline-block; padding: 2px 8px; border-radius: 10px; font-size: 10px; font-weight: 600;
      }
      .status-badge.pending-upgrade { background: rgba(255,152,0,0.15); color: #ff9800; }

      .update-all-bar {
        display: flex; justify-content: flex-end; gap: 8px; margin-bottom: 12px;
      }
      .update-all-btn {
        padding: 10px 20px; border-radius: 10px;
        background: var(--primary-color); color: #fff; border: none;
        font-size: 13px; font-weight: 600; cursor: pointer;
        display: flex; align-items: center; gap: 6px; transition: opacity 0.2s;
        touch-action: manipulation;
      }
      .update-all-btn:hover { opacity: 0.9; }
      .update-all-btn:disabled { opacity: 0.5; cursor: not-allowed; }
      .update-all-btn.selected-btn {
        background: transparent; border: 1px solid var(--primary-color);
        color: var(--primary-color);
      }
      .update-all-btn.selected-btn:disabled { opacity: 0.4; }

      @media (max-width: 768px) {
        .search { min-width: 0; }
        .card { padding: 12px; }
        .version-row { gap: 8px; }
        .version-item { padding: 6px; }
        .version-label { font-size: 9px; }
        .version-value { font-size: 12px; }
        .card-desc { font-size: 11px; margin-bottom: 10px; }
        .btn.primary { min-height: 44px; }
        .update-all-bar { justify-content: stretch; flex-wrap: wrap; }
        .update-all-btn { flex: 1; min-width: 120px; justify-content: center; min-height: 44px; }
      }

      .batch-toggle {
        padding: 3px 10px; border-radius: 4px; font-size: 11px;
        border: 1px solid var(--divider-color, #ccc);
        background: var(--card-background-color);
        color: var(--primary-text-color); cursor: pointer;
      }
      .batch-toggle:hover { border-color: var(--primary-color); }
      .batch-bar {
        display: flex; align-items: center; gap: 8px; flex-wrap: wrap;
        padding: 8px 12px; margin: 6px 0;
        background: var(--primary-color, #03a9f4); color: #fff;
        border-radius: 8px; font-size: 13px; font-weight: 600;
      }
      .batch-bar-btn {
        padding: 4px 12px; border-radius: 4px; font-size: 11px; font-weight: 600;
        background: rgba(255,255,255,0.2); color: #fff;
        border: 1px solid rgba(255,255,255,0.4); cursor: pointer;
      }
      .batch-bar-btn:hover { background: rgba(255,255,255,0.35); }
      .batch-bar-btn.danger { border-color: #ff5252; color: #ff5252; }
      .batch-checkbox {
        display: inline-flex; align-items: center; margin-right: 4px; cursor: pointer;
      }
      .batch-checkbox input { width: 16px; height: 16px; cursor: pointer; }
    `];async connectedCallback(){super.connectedCallback(),await this._load()}_lazyLoadChangelogs(){const e=this.updates.filter(e=>e.full_name&&!this._changelogs[e.full_name]);if(0===e.length)return;let t=0;const i=()=>{t>=e.length||(this._loadChangelog(e[t++].full_name),setTimeout(i,150))};setTimeout(i,300)}async _load(){this.loading=!0;try{await ce.refresh().catch(()=>{});const e=await ce.getUpdates();this.updates=Array.isArray(e)?e:e.updates||[],this._lazyLoadChangelogs()}catch(e){console.error("Failed to load updates",e),this.updates=[]}this.loading=!1}async _loadChangelog(e){if(e&&!this._changelogs[e]&&!this._changelogsLoading[e]){this._changelogsLoading={...this._changelogsLoading,[e]:!0};try{const t=await ce.getChangelog(e);t?.body&&(this._changelogs={...this._changelogs,[e]:t})}catch{}this._changelogsLoading={...this._changelogsLoading,[e]:!1}}}_toggleChangelog(e){this._expandedChangelogs={...this._expandedChangelogs,[e]:!this._expandedChangelogs?.[e]}}async _loadChangelogs(){const e=this.updates.filter(e=>e.full_name);if(0===e.length)return;const t=await Promise.allSettled(e.map(e=>ce.getChangelog(e.full_name).then(t=>({fullName:e.full_name,data:t})))),i={};for(const e of t)"fulfilled"===e.status&&e.value.data?.body&&(i[e.value.fullName]=e.value.data);Object.keys(i).length>0&&(this._changelogs={...this._changelogs,...i})}async _updateSelected(){const e=Object.keys(this._selectedIds).filter(e=>this._selectedIds[e]);if(0===e.length)return;if(await Bt.show(this,{message:`${ge("confirmUpdateAll")} ${e.length}?`,confirmText:ge("confirmUpdate"),danger:!1})){this.updating=!0;try{await ce.update(e),Ot(`${ge("allUpdatesStarted")} (${e.length})`,"success"),this._selectedIds={},this._load(),this.dispatchEvent(new CustomEvent("refresh-stats",{bubbles:!0,composed:!0}))}catch(e){Ot(`${ge("updateFailed")}: ${e.message}`,"error")}this.updating=!1}}async _updateAll(){const e=this.updates.map(e=>e.id||e.full_name);if(0===e.length)return;if(await Bt.show(this,{message:`${ge("updateAll")} ${e.length}?`,confirmText:ge("confirmUpdate"),danger:!1})){this.updating=!0;try{await ce.update(e),Ot(`${ge("allUpdatesStarted")} (${e.length})`,"success"),this._selectedIds={},this._load(),this.dispatchEvent(new CustomEvent("refresh-stats",{bubbles:!0,composed:!0}))}catch(e){Ot(`${ge("updateFailed")}: ${e.message}`,"error")}this.updating=!1}}_toggleSelect(e){this._selectedIds={...this._selectedIds,[e]:!this._selectedIds[e]}}_toggleSelectFull(e){this._selectedRepos.includes(e)?this._selectedRepos=this._selectedRepos.filter(t=>t!==e):this._selectedRepos=[...this._selectedRepos,e]}async _batchDo(e){if(0!==this._selectedRepos.length){if("remove"===e){if(!await Bt.show(this,{message:ge("batchRemoveConfirm",{n:this._selectedRepos.length}),confirmText:ge("batchRemove"),danger:!0}))return}try{Ot(ge("batchInProgress"),"info"),"update"===e?await ce.update(this._selectedRepos):"remove"===e&&await ce.batchRemove(this._selectedRepos.map(e=>e)),Ot(ge("batchComplete"),"success"),this._selectedRepos=[],this._batchMode=!1,this._load(),this.dispatchEvent(new CustomEvent("refresh-stats",{bubbles:!0,composed:!0}))}catch(t){Ot(`${e} failed: ${t.message}`,"error")}}}_toggleSelectAll(){const e=this._getFiltered();if(this._isAllSelected())this._selectedIds={};else{const t={};for(const i of e)t[i.id||i.full_name]=!0;this._selectedIds=t}}_isAllSelected(){const e=this._getFiltered();return 0!==e.length&&e.every(e=>this._selectedIds[e.id||e.full_name])}_selectedCount(){return Object.keys(this._selectedIds).filter(e=>this._selectedIds[e]).length}async _updateOne(e){const t=e.id||e.full_name;this._installingIds={...this._installingIds,[t]:!0};try{await ce.update([t]);const i=e.latest_version;let o=0;const r=async()=>{if(o++>30)return this._installingIds={...this._installingIds},delete this._installingIds[t],void Ot(`${ge("installFailed")}: timeout`,"error");try{const o=await ce.getRepoStatus(t);if(o?.installed_version===i||o?.installed&&!o?.has_update)return this._installingIds={...this._installingIds},delete this._installingIds[t],Ot(`${ge("updateComplete")}: ${e.full_name||e.name}`,"success"),this._load(),void this.dispatchEvent(new CustomEvent("refresh-stats",{bubbles:!0,composed:!0}))}catch(e){}setTimeout(r,2e3)};setTimeout(r,2e3)}catch(e){this._installingIds={...this._installingIds},delete this._installingIds[t],Ot(`${ge("updateFailed")}: ${e.message}`,"error")}}_getFiltered(){if(!this.search)return this.updates;const e=this.search.toLowerCase();return this.updates.filter(t=>(t.full_name||t.name||"").toLowerCase().includes(e))}_clearSearch(){this._searchText="",this.search="",this._searchTimer&&(clearTimeout(this._searchTimer),this._searchTimer=null)}_openDetail(e){this.dispatchEvent(new CustomEvent("detail",{detail:{repo:e},bubbles:!0,composed:!0}))}_setViewMode(e){this._viewMode=e;try{localStorage.setItem("hacs_vision_view_mode",e)}catch{}}_renderListTable(e){return H`
      <table class="list-table">
        <thead>
          <tr>
            <th class="col-icon"></th>
            <th>${ge("colName")||"名称"}</th>
            <th>${ge("currentVersion")}</th>
            <th>${ge("latestVersion")}</th>
            <th>${ge("colStatus")||"状态"}</th>
            <th></th>
          </tr>
        </thead>
        <tbody>
          ${e.map(e=>this._renderListRow(e))}
        </tbody>
      </table>
    `}_renderListRow(e){const t=e.id||e.full_name,i=!!this._installingIds?.[t],o=!!this._selectedIds[t],r=e.manifest_name||e.name||e.full_name||"?",a=fe(e.category),s=e.domain;return H`
      <tr @click=${t=>{t.target.closest(".btn")||t.target.closest("a")||t.target.closest(".checkbox")||this._openDetail(e)}}>
        <td class="col-icon">
          <div class="icon-cell" style="background:${a}">
            ${s&&"integration"===e.category?H`
                <img src="https://brands.home-assistant.io/${s}/icon.png" style="width:100%;height:100%;object-fit:cover;" @error=${e=>{e.target.style.display="none",e.target.nextElementSibling.style.display="flex"}}>
                <span style="display:none">${r.charAt(0).toUpperCase()}</span>
              `:r.charAt(0).toUpperCase()}
          </div>
        </td>
        <td>
          <div class="name-cell">${r}</div>
          ${e.description?H`<div class="desc-cell">${e.description}</div>`:""}
          ${e.is_custom?H`<span class="custom-tag-list">${ge("customBadge")}</span>`:""}
          ${e.topics&&e.topics.length?H`<div class="topic-chips">${e.topics.slice(0,4).map(e=>H`<span class="topic-chip">${e}</span>`)}</div>`:""}
        </td>
        <td style="font-size:12px;color:var(--warning-color);white-space:nowrap;">${e.installed_version||"?"}</td>
        <td style="font-size:12px;color:var(--success-color);white-space:nowrap;">${e.latest_version||"?"}</td>
        <td><span class="status-badge pending-upgrade">${ge("statusPendingUpgrade")}</span></td>
        <td style="white-space:nowrap;">
          <input type="checkbox" class="checkbox" .checked=${o}
                 @click=${e=>e.stopPropagation()}
                 @change=${()=>this._toggleSelect(t)} style="margin-right:6px;">
          <button class="btn primary ${i?"installing":""}" style="padding:4px 10px;font-size:11px;"
                  @click=${t=>{t.stopPropagation(),this._updateOne(e)}} ?disabled=${i||this.updating}>
            ${i?H`<svg class="mini-icon spin" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 12a9 9 0 1 1-6.219-8.56"/></svg>`:H`<svg class="mini-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M23 4v6h-6M1 20v-6h6"/><path d="M3.51 9a9 9 0 0114.85-3.36L23 10M1 14l4.64 4.36A9 9 0 0020.49 15"/></svg> ${ge("updateNow")}`}
          </button>
        </td>
      </tr>
    `}render(){const e=this._getFiltered();return H`
      <div class="controls">
        <div class="search">
          <svg class="search-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <circle cx="11" cy="11" r="8"/><path d="M21 21l-4.35-4.35"/>
          </svg>
          <input type="text" placeholder="${ge("searchUpdates")}" .value=${this._searchText||""}
                 @input=${e=>{this._searchText=e.target.value,clearTimeout(this._searchTimer),this._searchTimer=setTimeout(()=>{this.search=this._searchText},300)}}>
          ${this.search?H`
            <button class="search-clear" @click=${this._clearSearch}>✕</button>
          `:""}
        </div>
        <div class="view-toggle">
          <button class="view-toggle-btn ${"card"===this._viewMode?"active":""}" @click=${()=>this._setViewMode("card")} title="${ge("viewCard")}">${ge("viewCard")}</button>
          <button class="view-toggle-btn ${"list"===this._viewMode?"active":""}" @click=${()=>this._setViewMode("list")} title="${ge("viewList")}">${ge("viewList")}</button>
        </div>
        <button class="batch-toggle" @click=${()=>{this._batchMode=!this._batchMode,this._batchMode||(this._selectedRepos=[])}}>
          ${this._batchMode?ge("cancel"):ge("batchSelect")}
        </button>
      </div>

      ${this.loading?H`
        <div class="skeleton-grid">
          ${[1,2,3,4].map(()=>H`
            <div class="skeleton-card">
              <div class="skeleton-card-img"></div>
              <div class="skeleton-card-body">
                <div class="skeleton-line wide"></div>
                <div class="skeleton-line medium"></div>
                <div class="skeleton-line" style="width:50%"></div>
              </div>
            </div>
          `)}
        </div>
      `:0===this.updates.length?H`
        <div class="empty">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5">
            <path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"/>
            <polyline points="22 4 12 14.01 9 11.01"/>
          </svg>
          <div>${ge("allUpToDate")}</div>
        </div>
      `:H`
        <div class="info-bar">
          <div style="display:flex;align-items:center;gap:8px;">
            <label class="select-all">
              <input type="checkbox" class="checkbox" .checked=${this._isAllSelected()}
                     @click=${e=>e.stopPropagation()}
                     @change=${this._toggleSelectAll}>
              ${ge("selectAll")||"全选"}
            </label>
            <span>${ge("totalPrefix")} <span class="count">${this.updates.length}</span> ${ge("totalUpdates")}</span>
          </div>
          <button class="btn" @click=${this._load}>
            <svg class="mini-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M23 4v6h-6M1 20v-6h6"/><path d="M3.51 9a9 9 0 0114.85-3.36L23 10M1 14l4.64 4.36A9 9 0 0020.49 15"/></svg> ${ge("refresh")}
          </button>
        </div>

        ${this.updates.length>1?H`
          <div class="update-all-bar">
            ${this._selectedCount()>0?H`
              <button class="update-all-btn selected-btn" @click=${this._updateSelected} ?disabled=${this.updating||0===this._selectedCount()}>
                <svg class="mini-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M9 12l2 2 4-4"/><circle cx="12" cy="12" r="10"/></svg> ${ge("updateSelected")} (${this._selectedCount()||0})
              </button>
            `:H`
              <button class="update-all-btn" @click=${this._updateAll} ?disabled=${this.updating||0===this.updates.length}>
                <svg class="mini-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M23 4v6h-6M1 20v-6h6"/><path d="M3.51 9a9 9 0 0114.85-3.36L23 10M1 14l4.64 4.36A9 9 0 0020.49 15"/></svg> ${this.updating?ge("updatingProgress"):ge("updateAllNow")}
              </button>
            `}
          </div>
        `:""}

        ${this._batchMode&&this._selectedRepos.length>0?H`
          <div class="batch-bar">
            <span>${ge("batchSelected",{n:this._selectedRepos.length})}</span>
            <button class="batch-bar-btn" @click=${()=>this._batchDo("update")}>${ge("batchUpdate")}</button>
            <button class="batch-bar-btn danger" @click=${()=>this._batchDo("remove")}>${ge("batchRemove")}</button>
            <button class="batch-bar-btn" @click=${()=>{this._selectedRepos=[],this._batchMode=!1}}>${ge("cancel")}</button>
          </div>
        `:""}

        ${"list"===this._viewMode?H`
          <div class="list-view">${this._renderListTable(e)}</div>
        `:H`
          <div class="grid">
            ${e.map(e=>{const t=e.id||e.full_name,i=!!this._installingIds?.[t],o=this._changelogs?.[e.full_name],r=!!this._selectedIds[t];return H`
              <div class="card" @click=${t=>{t.target.closest(".btn")||t.target.closest("a")||t.target.closest(".checkbox")||this._openDetail(e)}}>
                <div class="card-header">
                  <div class="card-left">
                    <input type="checkbox" class="checkbox" .checked=${r}
                           @click=${e=>e.stopPropagation()}
                           @change=${()=>this._toggleSelect(t)}>
                    <div class="card-name">
                      ${e.name||e.full_name}
                      ${e.category?H`<span class="category-badge">${e.category}</span>`:""}
                    </div>
                  </div>
                </div>
                <div class="version-row">
                  <div class="version-item">
                    <div class="version-label">${ge("currentVersion")}</div>
                    <div class="version-value old">${e.installed_version||"?"}</div>
                  </div>
                  <div class="version-item">
                    <div class="version-label">${ge("latestVersion")}</div>
                    <div class="version-value new">${e.latest_version||"?"}</div>
                  </div>
                </div>
                <div class="card-desc">${e.description||""}</div>

                ${o?.body?H`
                  <div class="changelog-preview">
                    <div class="changelog-preview-title">${ge("changelogTitle")} ${o.tag?H`<small>(${o.tag})</small>`:""}</div>
                    <div class="changelog-preview-body${this._expandedChangelogs?.[e.full_name]?" expanded":""}">${o.body}</div>
                    <div>
                      <button class="changelog-expand-btn" @click=${()=>this._toggleChangelog(e.full_name)}>${this._expandedChangelogs?.[e.full_name]?ge("changelogShowLess"):ge("changelogShowMore")}</button>
                      <a class="changelog-preview-link" href="${o.url||`https://github.com/${e.full_name}/releases`}" target="_blank" rel="noopener">${ge("viewFullChangelog")} →</a>
                    </div>
                  </div>
                `:""}

                <button class="btn primary ${i?"installing":""}"
                        @click=${()=>this._updateOne(e)} ?disabled=${i||this.updating}>
                  ${i?H`<svg class="mini-icon spin" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 12a9 9 0 1 1-6.219-8.56"/></svg> ${ge("updatingProgress")}`:H`<svg class="mini-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M23 4v6h-6M1 20v-6h6"/><path d="M3.51 9a9 9 0 0114.85-3.36L23 10M1 14l4.64 4.36A9 9 0 0020.49 15"/></svg> ${ge("updateNow")}`}
                </button>
              </div>
            `})}
          </div>
        `}
      `}
    `}}customElements.define("updates-view",qt);
/**
   * @license
   * Copyright 2017 Google LLC
   * SPDX-License-Identifier: BSD-3-Clause
   */
const Gt=1;class Wt{constructor(e){}get _$AU(){return this._$AM._$AU}_$AT(e,t,i){this._$Ct=e,this._$AM=t,this._$Ci=i}_$AS(e,t){return this.update(e,t)}update(e,t){return this.render(...t)}}
/**
   * @license
   * Copyright 2018 Google LLC
   * SPDX-License-Identifier: BSD-3-Clause
   */const Yt=(e=>(...t)=>({_$litDirective$:e,values:t}))(class extends Wt{constructor(e){if(super(e),e.type!==Gt||"class"!==e.name||e.strings?.length>2)throw Error("`classMap()` can only be used in the `class` attribute and must be the only part in the attribute.")}render(e){return" "+Object.keys(e).filter(t=>e[t]).join(" ")+" "}update(e,[t]){if(void 0===this.st){this.st=new Set,void 0!==e.strings&&(this.nt=new Set(e.strings.join(" ").split(/\s/).filter(e=>""!==e)));for(const e in t)t[e]&&!this.nt?.has(e)&&this.st.add(e);return this.render(t)}const i=e.element.classList;for(const e of this.st)e in t||(i.remove(e),this.st.delete(e));for(const e in t){const o=!!t[e];o===this.st.has(e)||this.nt?.has(e)||(o?(i.add(e),this.st.add(e)):(i.remove(e),this.st.delete(e)))}return j}});class Jt extends se{static properties={customRepos:{type:Array},archivedRepos:{type:Array},ignoredRepos:{type:Array},renamedEntries:{type:Array},loading:{type:Boolean},_customRepoUrl:{type:String},_customRepoCategory:{type:String},_showAddCustom:{type:Boolean},_addingCustom:{type:Boolean},erLoading:{type:Boolean},iLoading:{type:Boolean},importing:{type:Boolean},exporting:{type:Boolean},_viewMode:{type:String},_collapsed:{type:Object},_renamedRefreshing:{type:Boolean},_depResults:{type:Object},_depLoading:{type:Boolean},_customRepoSearch:{type:String},_customRepoSort:{type:String}};constructor(){super(),this.customRepos=[],this.archivedRepos=[],this.ignoredRepos=[],this.renamedEntries=[],this.loading=!1,this.exporting=!1,this.importing=!1,this._depResults=null,this._depLoading=!1,this._renamedRefreshing=!1,this._showAddCustom=!1,this._customRepoUrl="",this._customRepoCategory="integration",this._addingCustom=!1,this._viewMode="card",this._customRepoSearch="",this._customRepoSort="name",this._collapsed={customRepos:!1,archived:!1,ignored:!1,tools:!1}}static styles=[me(),a`
    :host { display: block; touch-action: manipulation; background: var(--primary-background-color); }

    /* ===== Section Base ===== */
    .section {
      background: var(--card-background-color, #fff);
      border: 1px solid var(--divider-color, #e0e0e0);
      border-radius: 14px; padding: 20px; margin-bottom: 16px;
    }
    .section-title {
      font-size: 15px; font-weight: 700; color: var(--primary-text-color);
      display: flex; align-items: center; gap: 8px; flex: 1;
    }
    .section-title svg { width: 20px; height: 20px; color: var(--primary-color); flex-shrink: 0; }
    .section-desc { font-size: 13px; color: var(--secondary-text-color); margin-bottom: 16px; line-height: 1.6; }

    /* ===== Search ===== */
    .search { position: relative; display: flex; align-items: center; }
    .search-icon { position: absolute; left: 10px; width: 16px; height: 16px; color: var(--secondary-text-color); pointer-events: none; }
    .search input {
      width: 100%; padding: 8px 12px 8px 34px; border: 1px solid var(--divider-color);
      border-radius: 10px; font-size: 13px; background: var(--card-background-color);
      color: var(--primary-text-color); outline: none; transition: border-color 0.2s;
      box-sizing: border-box; font-family: inherit;
    }
    .search input:focus { border-color: var(--primary-color); }
    .search input::placeholder { color: var(--secondary-text-color); }
    .edit-input {
      padding: 8px 12px; border: 1px solid var(--divider-color);
      border-radius: 10px; font-size: 13px; background: var(--card-background-color);
      color: var(--primary-text-color); outline: none; transition: border-color 0.2s;
      box-sizing: border-box; font-family: inherit;
    }
    .edit-input:focus { border-color: var(--primary-color); }

    /* ===== Collapsible ===== */
    .section-header {
      display: flex; align-items: center; gap: 8px; margin-bottom: 14px;
      cursor: pointer; user-select: none; -webkit-tap-highlight-color: transparent;
    }
    .section-header .arrow {
      width: 18px; height: 18px; transition: transform 0.25s; flex-shrink: 0;
      color: var(--secondary-text-color);
    }
    .section-header .arrow.open { transform: rotate(0deg); }
    .section-header .arrow.closed { transform: rotate(-90deg); }
    .section-content { overflow: hidden; }
    .section-content.collapsed { display: none; }

    /* ===== View Toggle ===== */
    .view-toggle {
      display: flex; gap: 2px;
      background: var(--secondary-background-color, #f0f0f0);
      border-radius: 8px; padding: 2px; flex-shrink: 0;
    }
    .view-toggle button {
      border: none; background: none; padding: 4px 10px; border-radius: 6px;
      cursor: pointer; font-size: 11px; color: var(--secondary-text-color);
      transition: all 0.2s; font-family: inherit;
    }
    .view-toggle button.active {
      background: var(--card-background-color, #fff);
      color: var(--primary-text-color);
      box-shadow: 0 1px 3px rgba(0,0,0,0.1);
    }

    /* ===== List View (enhanced) ===== */
    .repo-list { display: flex; flex-direction: column; gap: 8px; }
    .repo-item {
      display: flex; justify-content: space-between; align-items: flex-start;
      padding: 12px 14px; border: 1px solid var(--divider-color);
      border-radius: 10px; font-size: 13px; transition: all 0.2s; gap: 12px;
      cursor: pointer;
    }
    .repo-item:hover { border-color: var(--primary-color); }
    .col-icon { flex-shrink: 0; }
    .icon-cell {
      width: 32px; height: 32px; border-radius: 6px;
      display: flex; align-items: center; justify-content: center;
      color: #fff; font-size: 14px; font-weight: 700;
      overflow: hidden;
    }
    .repo-info { flex: 1; min-width: 0; }
    .repo-top { display: flex; align-items: center; gap: 6px; flex-wrap: wrap; margin-bottom: 4px; }
    .repo-name { color: var(--primary-text-color); font-weight: 600; font-size: 14px; }
    .repo-meta { display: flex; align-items: center; gap: 8px; flex-wrap: wrap; font-size: 11px; color: var(--secondary-text-color); margin-bottom: 4px; }
    .repo-fullname { color: var(--secondary-text-color); }
    .repo-version { color: var(--text-primary-color); }
    .repo-not-installed { color: var(--secondary-text-color); font-style: italic; font-size: 10px; }
    .update-badge { color: #f44336; font-weight: 600; }
    .repo-stars { color: #f9a825; }
    .repo-desc { font-size: 12px; color: var(--secondary-text-color); line-height: 1.5; display: -webkit-box; -webkit-line-clamp: 2; -webkit-box-orient: vertical; overflow: hidden; margin-top: 2px; }
    .topic-chips { display: flex; gap: 4px; flex-wrap: wrap; }
    .topic-chip {
      font-size: 9px; padding: 1px 6px; border-radius: 4px;
      background: var(--secondary-background-color);
      color: var(--secondary-text-color); border: 1px solid var(--divider-color);
    }
    .repo-actions { display: flex; gap: 4px; flex-shrink: 0; align-items: center; flex-wrap: wrap; }

    .category-badge {
      display: inline-block; padding: 1px 8px; border-radius: 4px;
      font-size: 10px; font-weight: 600; text-transform: uppercase; letter-spacing: 0.3px;
    }
    .category-badge.integration { background: #e8f5e9; color: #2e7d32; }
    .category-badge.plugin { background: #fff3e0; color: #e65100; }
    .category-badge.theme { background: #f3e5f5; color: #7b1fa2; }
    .category-badge.python_script { background: #e3f2fd; color: #1565c0; }
    .category-badge.template { background: #fce4ec; color: #c62828; }
    .category-badge.appdaemon { background: #e0f2f1; color: #00695c; }
    .category-badge.netdaemon { background: #ede7f6; color: #4527a0; }
    .category-badge.dashboard { background: #fff8e1; color: #f57f17; }

    .renamed-badge {
      display: inline-flex; align-items: center; gap: 3px;
      padding: 1px 8px; border-radius: 4px; font-size: 10px; font-weight: 600;
      background: #fff3e0; color: #e65100; letter-spacing: 0.3px;
    }
    .custom-badge-tag { font-size: 10px; padding: 1px 6px; border-radius: 4px; background: #ff6f00; color: #fff; font-weight: 700; display: inline-flex; align-items: center; }
    .section-badge {
      display: inline-flex; align-items: center; padding: 2px 10px;
      border-radius: 10px; font-size: 11px; font-weight: 500;
      background: var(--primary-color); color: #fff;
    }

    /* ===== Card View ===== */
    .repo-cards {
      display: grid;
      grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
      gap: 12px;
    }
    .repo-card {
      background: var(--card-background-color, #fff);
      border: 1px solid var(--divider-color, #e0e0e0);
      border-radius: 14px; overflow: hidden;
      transition: border-color 0.2s, box-shadow 0.2s; cursor: pointer;
      display: flex; flex-direction: column; position: relative;
    }
    .repo-card:hover { border-color: var(--primary-color, #03a9f4); box-shadow: 0 4px 12px rgba(0,0,0,0.08); }
    .repo-card-img {
      height: 100px; flex-shrink: 0;
      display: flex; align-items: center; justify-content: center;
      position: relative;
    }
    .repo-card-avatar {
      width: 44px; height: 44px; border-radius: 50%;
      display: flex; align-items: center; justify-content: center;
      font-size: 20px; font-weight: 700; color: #fff;
      box-shadow: 0 4px 12px rgba(0,0,0,0.15);
      overflow: hidden;
    }
    .repo-card-badge-cat {
      position: absolute; top: 10px; left: 10px;
      padding: 3px 8px; border-radius: 6px;
      font-size: 10px; font-weight: 600; color: #fff; text-transform: uppercase;
    }
    .repo-card-custom {
      position: absolute; top: 10px; left: 50%;
      transform: translateX(-50%);
      padding: 3px 10px; border-radius: 6px;
      font-size: 10px; font-weight: 700; color: #fff; text-transform: uppercase;
      background: #ff6f00; box-shadow: 0 2px 6px rgba(255,111,0,0.4);
    }
    .repo-card-actions-img {
      position: absolute; top: 10px; right: 10px; z-index: 2;
    }
    .repo-card-actions-img .btn-icon {
      width: 30px; height: 30px;
      background: rgba(255,255,255,0.85); border-radius: 50%;
      display: flex; align-items: center; justify-content: center;
      border: none; cursor: pointer; box-shadow: 0 2px 6px rgba(0,0,0,0.12);
      padding: 0; color: var(--secondary-text-color);
      transition: all 0.2s;
    }
    .repo-card-actions-img .btn-icon:hover { color: #f44336; }
    .repo-card-installed {
      position: absolute; bottom: 10px; left: 10px;
      padding: 2px 8px; border-radius: 6px;
      font-size: 10px; font-weight: 600;
      background: rgba(76,175,80,0.15); color: #4caf50;
    }
    .repo-card-body { padding: 12px; flex: 1; display: flex; flex-direction: column; }
    .repo-card-body .name {
      font-size: 14px; font-weight: 600; color: var(--primary-text-color);
      overflow: hidden; text-overflow: ellipsis; white-space: nowrap; margin-bottom: 2px;
    }
    .repo-card-body .fullname {
      font-size: 11px; color: var(--secondary-text-color);
      overflow: hidden; text-overflow: ellipsis; white-space: nowrap; margin-bottom: 4px;
    }
    .repo-card-body .desc {
      font-size: 12px; color: var(--secondary-text-color);
      display: -webkit-box; -webkit-line-clamp: 2; -webkit-box-orient: vertical;
      overflow: hidden; margin-bottom: 8px; line-height: 1.5; height: 36px;
    }
    .repo-card-body .meta {
      display: flex; justify-content: space-between; align-items: center;
      flex-wrap: wrap; gap: 4px; margin-top: auto;
    }
    .repo-card-body .meta .stars {
      display: flex; align-items: center; gap: 3px;
      font-size: 11px; color: var(--secondary-text-color);
    }
    .repo-card-renamed {
      position: absolute; top: 10px; right: 48px; z-index: 2;
      padding: 3px 8px; border-radius: 6px; font-size: 9px; font-weight: 600;
      background: #fff3e0; color: #e65100;
    }

    /* ===== Buttons ===== */
    .btn {
      padding: 8px 14px; border: 1px solid var(--divider-color); border-radius: 8px;
      background: var(--card-background-color); color: var(--primary-text-color);
      cursor: pointer; font-size: 12px; transition: all 0.2s;
      touch-action: manipulation; display: inline-flex; align-items: center; gap: 8px; font-family: inherit;
    }
    .btn.sm { padding: 4px 10px; font-size: 11px; }
    .btn-icon {
      width: 32px; height: 32px; padding: 0; display: inline-flex;
      align-items: center; justify-content: center; border-radius: 8px;
      border: 1px solid var(--divider-color); cursor: pointer;
      color: var(--primary-text-color); transition: all 0.2s; text-decoration: none;
    }
    .btn-icon:hover { border-color: var(--primary-color); color: var(--primary-color); }

    .edit-input {
      padding: 6px 10px; border: 1px solid var(--primary-color); border-radius: 6px;
      font-size: 13px; background: var(--card-background-color);
      color: var(--primary-text-color); outline: none; flex: 1; min-width: 0; font-family: inherit;
    }
    .edit-input:focus { border-color: var(--primary-color); box-shadow: 0 0 0 2px rgba(var(--rgb-primary-color), 0.15); }

    .btn-group { display: flex; gap: 4px; flex-shrink: 0; align-items: center; }
    .btn-group-wide { display: flex; gap: 12px; flex-wrap: wrap; }

    .empty { font-size: 13px; color: var(--secondary-text-color); padding: 32px 0; text-align: center; }

    /* ===== Add Form ===== */
    .add-form {
      padding: 14px; border: 1px dashed var(--primary-color);
      border-radius: 10px; background: rgba(var(--rgb-primary-color, 0, 123, 255), 0.04);
      margin-bottom: 12px; display: flex; flex-direction: column; gap: 10px;
    }
    .add-form-controls { display: flex; gap: 8px; align-items: center; flex-wrap: wrap; }
    .add-form-controls select { flex: 0 0 auto; max-width: 160px; }
    .add-preview { font-size: 12px; color: var(--secondary-text-color); padding: 4px 2px; }
    .add-error { color: #f44336; }

    /* ===== Dep Check Results ===== */
    .dep-panel {
      margin-top:12px;padding:12px 14px;border-radius:10px;font-size:13px;
      background:var(--secondary-background-color);
    }
    .dep-summary { display:flex;justify-content:space-between;align-items:center;margin-bottom:8px; }
    .dep-summary .title { font-weight:600;color:var(--primary-text-color); }
    .dep-summary .issues { color:#f44336;font-weight:600; }
    .dep-item {
      margin-top:8px;padding:10px 12px;border-radius:8px;
      background:var(--card-background-color);border:1px solid var(--divider-color);
    }
    .dep-item .repo { font-weight:500;color:var(--primary-text-color);margin-bottom:4px; }
    .dep-item .missing { font-size:11px;color:#f44336; }
    .dep-ok { color:var(--success-color,#0f9d58);font-weight:500; }

    .mini-icon { width: 14px; height: 14px; vertical-align: -2px; display: inline; flex-shrink: 0; }
    .mini-icon.spin { animation: spin 1s linear infinite; }
    @keyframes spin { 100% { transform: rotate(360deg); } }

    /* ===== Mobile ===== */
    @media (max-width: 768px) {
      .section { padding: 14px; border-radius: 12px; }
      .btn { min-height: 44px; }
      .btn.sm { min-height: 36px; }
      .btn-group-wide { flex-direction: column; gap: 8px; }
      .btn-group-wide .btn { width: 100%; justify-content: center; }
      .repo-item { flex-direction: column; gap: 8px; padding: 10px 12px; }
      .repo-actions { width: 100%; justify-content: flex-end; }
      .repo-name { font-size: 13px; }
      .repo-meta { font-size: 10px; }
      .repo-desc { font-size: 11px; }
      .repo-cards { grid-template-columns: 1fr; }
      .repo-card-img { height: 80px; }
      .repo-card-avatar { width: 36px; height: 36px; font-size: 16px; }
      .add-form { padding: 10px; }
      .add-form-controls { flex-direction: column; align-items: stretch; }
      .add-form-controls select { max-width: 100%; }
      .add-form-controls .btn { width: 100%; justify-content: center; }
      .section-badge { font-size: 10px; padding: 1px 8px; }
      .category-badge { font-size: 9px; padding: 1px 6px; }
    }
  `];async connectedCallback(){super.connectedCallback(),await this._load()}async _load(){this.loading=!0;try{const e=await ce.getConfig()||{};this.archivedRepos=e.archived_repositories||[],this.ignoredRepos=e.ignored_repositories||[],this.renamedEntries=Object.entries(e.renamed_repositories||{});const t=await ce.getCustomRepos();this.customRepos=Array.isArray(t)?t:t.custom_repositories||[]}catch(e){console.error("Config load error",e)}this.loading=!1}async _removeArchivedRepo(e){if(await Bt.show(this,{message:`${ge("confirmRemoveArchived")} ${e}?`,confirmText:ge("removeArchived"),danger:!0}))try{await ce.removeArchivedRepo(e),this._load()}catch(e){Ot(`${ge("removeRepoFailed")}: ${e.message}`,"error")}}async _removeRenamedRepo(e){if(await Bt.show(this,{message:`${ge("confirmRemoveRenamed")} ${e}?`,confirmText:ge("removeRenamed"),danger:!0}))try{await ce.removeRenamedRepo(e),this._load()}catch(e){Ot(`${ge("removeRepoFailed")}: ${e.message}`,"error")}}async _replaceRenamedOneClick(e,t){if(await Bt.show(this,{message:`${ge("confirmReplaceRenamed")}: ${e} → ${t}${ge("replaceRenamedWarning")}?`,confirmText:ge("replace"),danger:!0})){this._renamedRefreshing=!0;try{await ce.replaceRenamedRepo(e,t),Ot(`${ge("replace")}: ${e} → ${t}`,"success"),await ce.refresh(),this._load(),this.dispatchEvent(new CustomEvent("refresh-stats",{bubbles:!0,composed:!0}))}catch(e){Ot(`${ge("updateFailed")}: ${e.message}`,"error")}this._renamedRefreshing=!1}}async _checkDependencies(){this._depLoading=!0;try{const e=await ce.checkDependencies();this._depResults=e,e.all_ok?Ot(ge("depOk"),"success"):Ot(`${ge("depMissing")} (${e.issues_count})`,"error")}catch(e){this._depResults=null,Ot(`${ge("checkFailed")}: ${e.message}`,"error")}this._depLoading=!1}_depMissingCount(){return this._depResults?.dependencies?this._depResults.dependencies.filter(e=>e.has_issues).length:0}async _export(){this.exporting=!0;try{const e=await ce.exportBackup(),t=new Blob([JSON.stringify(e,null,2)],{type:"application/json"}),i=URL.createObjectURL(t),o=document.createElement("a");o.href=i,o.download=`hacs-vision-backup-${(new Date).toISOString().slice(0,10)}.json`,o.click(),URL.revokeObjectURL(i),Ot(ge("exportSuccess"),"success")}catch(e){Ot(`${ge("exportFailed")}: ${e.message}`,"error")}this.exporting=!1}async _import(){const e=document.createElement("input");e.type="file",e.accept=".json",e.onchange=async()=>{const t=e.files[0];if(t){this.importing=!0;try{const e=await t.text(),i=JSON.parse(e);await ce.importBackup(i),Ot(ge("importSuccess"),"success"),this.dispatchEvent(new CustomEvent("refresh-stats",{bubbles:!0,composed:!0}))}catch(e){Ot(`${ge("importFailed")}: ${e.message}`,"error")}this.importing=!1}},e.click()}_toggleAddCustom(){this._showAddCustom=!this._showAddCustom,this._showAddCustom||(this._customRepoUrl="",this._customRepoCategory="integration")}_parseRepoUrl(e){const t=(e=e.trim()).match(/github\.com\/([^/]+\/[^/\s?#]+)/i);return t?t[1].replace(/\.git$/,""):/^[a-zA-Z0-9_-]+\/[a-zA-Z0-9_.-]+$/.test(e)?e:null}async _addCustomRepo(){const e=this._parseRepoUrl(this._customRepoUrl);if(!e)return void Ot(ge("invalidRepoUrl"),"error");const t=this.customRepos.some(t=>(t.full_name||t.repository)===e);if(t)Ot(`${e} ${ge("alreadyExists")}`,"error");else{this._addingCustom=!0;try{const t=await ce.addCustomRepo(e,this._customRepoCategory);t.success?(Ot(`${ge("addSuccess")}: ${e}`,"success"),this._customRepoUrl="",this._load(),this.dispatchEvent(new CustomEvent("refresh-stats",{bubbles:!0,composed:!0}))):Ot(`${ge("addFailed")}: ${t.error}`,"error")}catch(e){Ot(`${ge("addFailed")}: ${e.message}`,"error")}this._addingCustom=!1}}async _removeCustomRepo(e,t){if(await Bt.show(this,{message:`${ge("confirmRemoveRepo")} ${e}?`,confirmText:ge("removeRepo"),danger:!0}))try{const t=await ce.removeCustomRepo(e);t&&!1===t.success&&Ot(`${ge("removeRepoFailed")}: ${t.error}`,"error"),this._load(),this.dispatchEvent(new CustomEvent("refresh-stats",{bubbles:!0,composed:!0}))}catch(e){Ot(`${ge("removeRepoFailed")}: ${e.message}`,"error")}}_toggleSection(e){this._collapsed={...this._collapsed,[e]:!this._collapsed[e]}}_setViewMode(e){this._viewMode=e}_openCardDetail(e){this.dispatchEvent(new CustomEvent("detail",{detail:{repo:e},bubbles:!0,composed:!0}))}_getFilteredCustomRepos(){let e=[...this.customRepos];const t=(this._customRepoSearch||"").toLowerCase();t&&(e=e.filter(e=>{const i=(e.manifest_name||e.name||e.full_name||"").toLowerCase(),o=(e.description||"").toLowerCase();return i.includes(t)||o.includes(t)}));const i=this._customRepoSort||"name";return"stars"===i?e.sort((e,t)=>(t.stargazers_count||0)-(e.stargazers_count||0)):"updated"===i?e.sort((e,t)=>(t.last_updated||"").localeCompare(e.last_updated||"")):e.sort((e,t)=>(e.manifest_name||e.name||e.full_name||"").localeCompare(t.manifest_name||t.name||t.full_name||"")),e}_getInitials(e){if(!e)return"?";const t=e.split("/");return(t[t.length-1]||e).charAt(0).toUpperCase()}_getCategoryColor(e){return fe(e)}_getCategoryLabel(e){return{integration:ge("catIntegration"),plugin:ge("catPlugin"),theme:ge("catTheme"),appdaemon:ge("catAppDaemon"),netdaemon:ge("catNetDaemon"),python_script:ge("catPython"),template:ge("catTemplate"),dashboard:ge("catDashboard")}[e]||e}_renderCard(e,t){const i=e.full_name||e.repository,o=e.manifest_name||e.name||i,r=t.find(([e,t])=>t===i),a=!!r,s=a?r[0]:null,n=e.installed_version||"",l=e.latest_version||"",c=e.has_update,d=e.stargazers_count||0,p=e.description||"",h=e.installed||!1,g=this._getCategoryColor(e.category);return H`
      <div class="repo-card" @click=${()=>this._openCardDetail(e)}>
        <div class="repo-card-img" style="background:linear-gradient(135deg, ${g}44 0%, ${g}22 100%);">
          <div class="repo-card-avatar" style="background:${g}">
            ${e.domain&&"integration"===e.category?H`
              <img src="https://brands.home-assistant.io/${e.domain}/icon.png" style="width:100%;height:100%;object-fit:cover;" @error=${e=>{e.target.style.display="none",e.target.nextSibling.style.display="flex"}}>
              <span style="display:none">${this._getInitials(o)}</span>
            `:this._getInitials(o)}
          </div>
          <span class="repo-card-badge-cat" style="background:${g}">
            ${this._getCategoryLabel(e.category)}
          </span>
          ${e.is_custom?H`<span class="repo-card-custom">${ge("customBadge")}</span>`:""}
          ${a?H`<span class="repo-card-renamed"><svg class="mini-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M23 4v6h-6M1 20v-6h6"/><path d="M3.51 9a9 9 0 0114.85-3.36L23 10M1 14l4.64 4.36A9 9 0 0020.49 15"/></svg> ${s}</span>`:""}
          ${h?H`<span class="repo-card-installed"><svg class="mini-icon" viewBox="0 0 24 24" fill="none" stroke="#4caf50" stroke-width="2"><path d="M20 6L9 17l-5-5"/></svg> ${ge("installed")}</span>`:""}
          <div class="repo-card-actions-img">
            <button class="btn-icon" @click=${t=>{t.stopPropagation(),this._removeCustomRepo(i,e.category)}} title="${ge("removeRepo")}">
              ✕
            </button>
          </div>
        </div>
        <div class="repo-card-body">
          <div class="name" title=${o}>${o}</div>
          <div class="fullname">${i}</div>
          <div class="desc">${p||ge("noDesc")}</div>
          ${e.topics&&e.topics.length?H`
            <div class="topic-chips" style="margin-top:6px;">
              ${e.topics.slice(0,3).map(e=>H`<span class="topic-chip">${e}</span>`)}
            </div>
          `:""}
          <div class="meta">
            <span class="stars">
              <svg viewBox="0 0 20 20" fill="#ff9800" width="14" height="14"><path d="M10 1l2.39 4.84L17.6 6.7l-3.8 3.71.9 5.26L10 13.27l-4.7 2.46.9-5.26L2.4 6.7l5.2-.86L10 1z"/></svg> ${d>0?"number"==typeof d?d.toLocaleString():d:0}
            </span>
            ${h?H`
              <span style="font-size:10px;color:var(--secondary-text-color);">
                <svg class="mini-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16z"/><polyline points="3.27 6.96 12 12.01 20.73 6.96"/><line x1="12" y1="22.08" x2="12" y2="12"/></svg> ${n}${c?H` <span class="update-badge"><svg class="mini-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M23 4v6h-6M1 20v-6h6"/><path d="M3.51 9a9 9 0 0114.85-3.36L23 10M1 14l4.64 4.36A9 9 0 0020.49 15"/></svg> ${l}</span>`:""}
              </span>
            `:H`<span class="repo-not-installed">${ge("notInstalled")}</span>`}
          </div>
        </div>
      </div>
    `}_renderListItem(e,t){const i=e.full_name||e.repository,o=e.manifest_name||e.name||i,r=t.find(([e,t])=>t===i),a=!!r,s=a?r[0]:null,n=e.installed_version||"",l=e.latest_version||"",c=e.has_update,d=e.stargazers_count||0,p=e.description||"";return H`
      <div class="repo-item" @click=${()=>this._openCardDetail(e)}>
        <div class="col-icon">
          <div class="icon-cell" style="background:${this._getCategoryColor(e.category)}">
            ${e.domain&&"integration"===e.category?H`
                <img src="https://brands.home-assistant.io/${e.domain}/icon.png" style="width:100%;height:100%;object-fit:cover;" @error=${e=>{e.target.style.display="none",e.target.nextSibling.style.display="flex"}}>
                <span style="display:none">${o.charAt(0).toUpperCase()}</span>
              `:o.charAt(0).toUpperCase()}
          </div>
        </div>
        <div class="repo-info">
          <div class="repo-top">
            <span class="repo-name">${o}</span>
            <span class="category-badge ${e.category}">${this._getCategoryLabel(e.category)}</span>
            ${e.is_custom?H`<span class="custom-badge-tag">${ge("customBadge")}</span>`:""}
            ${a?H`<span class="renamed-badge"><svg class="mini-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M23 4v6h-6M1 20v-6h6"/><path d="M3.51 9a9 9 0 0114.85-3.36L23 10M1 14l4.64 4.36A9 9 0 0020.49 15"/></svg> ${s}</span>`:""}
          </div>
          <div class="repo-meta">
            <span class="repo-fullname">${i}</span>
            <span class="stars" style="color:#f9a825;"><svg viewBox="0 0 20 20" fill="#ff9800" width="14" height="14"><path d="M10 1l2.39 4.84L17.6 6.7l-3.8 3.71.9 5.26L10 13.27l-4.7 2.46.9-5.26L2.4 6.7l5.2-.86L10 1z"/></svg> ${d>0?"number"==typeof d?d.toLocaleString():d:0}</span>
            ${e.installed?H`
              <span class="repo-version"><svg class="mini-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16z"/><polyline points="3.27 6.96 12 12.01 20.73 6.96"/><line x1="12" y1="22.08" x2="12" y2="12"/></svg> ${n}</span>
              ${c?H`<span class="update-badge"><svg class="mini-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M23 4v6h-6M1 20v-6h6"/><path d="M3.51 9a9 9 0 0114.85-3.36L23 10M1 14l4.64 4.36A9 9 0 0020.49 15"/></svg> ${l}</span>`:""}
            `:H`<span class="repo-not-installed">${ge("notInstalled")}</span>`}
          </div>
          ${p?H`<div class="repo-desc">${p}</div>`:""}
          ${e.topics&&e.topics.length?H`
            <div class="topic-chips" style="margin-top:4px;">
              ${e.topics.slice(0,4).map(e=>H`<span class="topic-chip">${e}</span>`)}
            </div>
          `:""}
        </div>
        <div class="repo-actions">
          <a class="btn btn-icon" href="https://github.com/${i}" target="_blank" rel="noopener" @click=${e=>e.stopPropagation()} title="GitHub">
            <svg viewBox="0 0 24 24" fill="currentColor" width="14" height="14"><path d="M12 0C5.37 0 0 5.37 0 12c0 5.31 3.435 9.795 8.205 11.385.6.105.825-.255.825-.57 0-.285-.015-1.23-.015-2.235-3.015.555-3.795-.735-4.035-1.41-.135-.345-.72-1.41-1.23-1.695-.42-.225-1.02-.78-.015-.795.945-.015 1.62.87 1.845 1.23 1.08 1.815 2.805 1.305 3.495.99.105-.78.42-1.305.765-1.605-2.67-.3-5.46-1.335-5.46-5.925 0-1.305.465-2.385 1.23-3.225-.12-.3-.54-1.53.12-3.18 0 0 1.005-.315 3.3 1.23.96-.27 1.98-.405 3-.405s2.04.135 3 .405c2.295-1.56 3.3-1.23 3.3-1.23.66 1.65.24 2.88.12 3.18.765.84 1.23 1.905 1.23 3.225 0 4.605-2.805 5.625-5.475 5.925.435.375.81 1.095.81 2.22 0 1.605-.015 2.895-.015 3.3 0 .315.225.69.825.57A12.02 12.02 0 0024 12c0-6.63-5.37-12-12-12z"/></svg>
          </a>
          ${a?H`
            <button class="btn primary sm" @click=${e=>{e.stopPropagation(),this._replaceRenamedOneClick(s,i)}} ?disabled=${this._renamedRefreshing}>
              ${this._renamedRefreshing?H`<svg class="mini-icon spin" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 12a9 9 0 1 1-6.219-8.56"/></svg>`:ge("replace")}
            </button>
            <button class="btn danger sm" @click=${e=>{e.stopPropagation(),this._removeRenamedRepo(s)}} title=${ge("removeRenamed")}>✕</button>
          `:""}
          <button class="btn danger sm" @click=${t=>{t.stopPropagation(),this._removeCustomRepo(i,e.category)}}>✕</button>
        </div>
      </div>
    `}render(){const{archivedRepos:e,ignoredRepos:t,renamedEntries:i,customRepos:o,loading:r,_viewMode:a,_collapsed:s}=this;return H`
      ${r?H`
        <div class="skeleton-grid" style="margin-bottom:16px;">
          ${[1,2,3].map(()=>H`
            <div class="skeleton-card">
              <div class="skeleton-card-img"></div>
              <div class="skeleton-card-body">
                <div class="skeleton-line wide"></div>
                <div class="skeleton-line" style="width:40%"></div>
              </div>
            </div>
          `)}
        </div>
      `:""}

      <!-- Custom Repos -->
      <div class="section">
        <div class="section-header" @click=${()=>this._toggleSection("customRepos")}>
          <svg class="arrow ${s.customRepos?"closed":"open"}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="6 9 12 15 18 9"/></svg>
          <div class="section-title">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><path d="M12 8v8"/><path d="M8 12h8"/></svg>
            ${ge("customRepos")}
            ${i.length>0?H`<span class="section-badge">${i.length} ${ge("renamedRepos")}</span>`:""}
          </div>
          <div class="view-toggle">
            <button class=${Yt({active:"card"===a})} @click=${e=>{e.stopPropagation(),this._setViewMode("card")}}>
              ${ge("catDashboard")||"卡片"}
            </button>
            <button class=${Yt({active:"list"===a})} @click=${e=>{e.stopPropagation(),this._setViewMode("list")}}>
              ${ge("list")||"列表"}
            </button>
          </div>
          <button class="btn sm" @click=${e=>{e.stopPropagation(),this._load()}} title="${ge("refresh")}" style="flex-shrink:0;"><svg class="mini-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M23 4v6h-6M1 20v-6h6"/><path d="M3.51 9a9 9 0 0114.85-3.36L23 10M1 14l4.64 4.36A9 9 0 0020.49 15"/></svg></button>
        </div>
        <div class="section-content ${s.customRepos?"collapsed":""}">
          <div class="section-desc">${ge("customReposDesc")}</div>

          <!-- Search & Sort -->
          <div style="display:flex;gap:8px;margin-bottom:12px;flex-wrap:wrap;">
            <div class="search" style="flex:1;min-width:150px;">
              <svg class="search-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="11" cy="11" r="8"/><path d="M21 21l-4.35-4.35"/></svg>
              <input type="text" placeholder="${ge("search")||"搜索..."}" .value=${this._customRepoSearch} @input=${e=>this._customRepoSearch=e.target.value}>
            </div>
            <select class="edit-input" style="width:auto;" .value=${this._customRepoSort} @change=${e=>this._customRepoSort=e.target.value}>
              <option value="name">${ge("sortByName")}</option>
              <option value="stars">${ge("sortByStars")}</option>
              <option value="updated">${ge("sortByUpdated")}</option>
            </select>
          </div>

          ${this._showAddCustom?H`
            <div class="add-form">
              <input class="edit-input" .value=${this._customRepoUrl} @input=${e=>this._customRepoUrl=e.target.value} placeholder="owner/repo 或 GitHub URL" @keydown=${e=>"Enter"===e.key&&this._addCustomRepo()}>
              <div class="add-form-controls">
                <select class="edit-input" .value=${this._customRepoCategory} @change=${e=>this._customRepoCategory=e.target.value}>
                  ${["integration","plugin","theme","dashboard","python_script","template","appdaemon","netdaemon"].map(e=>H`<option value=${e}>${this._getCategoryLabel(e)}</option>`)}
                </select>
                <button class="btn primary sm" @click=${this._addCustomRepo} ?disabled=${this._addingCustom||!this._customRepoUrl.trim()}>
                  ${this._addingCustom?H`<svg class="mini-icon spin" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 12a9 9 0 1 1-6.219-8.56"/></svg> ${ge("add")}`:H`<svg class="mini-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="20 6 9 17 4 12"/></svg> ${ge("add")}`}
                </button>
                <button class="btn sm" @click=${this._toggleAddCustom}>${ge("cancel")}</button>
              </div>
              ${this._customRepoUrl.trim()?H`
                <div class="add-preview">${this._parseRepoUrl(this._customRepoUrl)?H`<svg class="mini-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16z"/><polyline points="3.27 6.96 12 12.01 20.73 6.96"/><line x1="12" y1="22.08" x2="12" y2="12"/></svg> ${this._parseRepoUrl(this._customRepoUrl)}`:H`<span class="add-error">${ge("invalidRepoUrl")}</span>`}</div>
              `:""}
            </div>
          `:H`
            <button class="btn primary" @click=${this._toggleAddCustom} style="margin-bottom:12px;">+ ${ge("addRepo")}</button>
          `}

          ${o.length>0?"card"===a?H`<div class="repo-cards">${this._getFilteredCustomRepos().map(e=>{const t=this.renamedEntries.find(([t,i])=>i===(e.full_name||e.repository));return H`
                <repo-card .repo=${e} viewMode="management"
                  .renamedFrom=${t?t[0]:void 0}
                  showRemoveBtn=true
                  @detail=${e=>this._openCardDetail(e.detail.repo)}
                  @remove-repo=${e=>this._removeCustomRepo(e.detail.repo?.full_name||e.detail.repo?.repository,e.detail.repo?.category)}>
                </repo-card>`})}</div>`:H`<div class="repo-list">${this._getFilteredCustomRepos().map(e=>this._renderListItem(e,i))}</div>`:H`<div class="empty">${ge("noCustomRepos")}</div>`}
        </div>
      </div>

      <!-- Archived -->
      <div class="section">
        <div class="section-header" @click=${()=>this._toggleSection("archived")}>
          <svg class="arrow ${s.archived?"closed":"open"}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="6 9 12 15 18 9"/></svg>
          <div class="section-title">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 8v13H3V8"/><path d="M1 3h22v5H1z"/><path d="M10 12h4"/></svg>
            ${ge("archivedRepos")}
          </div>
        </div>
        <div class="section-content ${s.archived?"collapsed":""}">
          ${e.length>0?H`
            <div class="repo-list">
              ${e.map(e=>H`
                <div class="repo-item" style="cursor:default;">
                  <div class="repo-info"><div class="repo-top"><span class="repo-name">${e}</span></div></div>
                  <div class="repo-actions">
                    <a class="btn sm" href="https://github.com/${e}" target="_blank" rel="noopener">${ge("viewOnGithub")}</a>
                    <button class="btn danger sm" @click=${()=>this._removeArchivedRepo(e)}>${ge("removeArchived")}</button>
                  </div>
                </div>
              `)}
            </div>
          `:H`<div class="empty">${ge("noArchived")}</div>`}
        </div>
      </div>

      <!-- Ignored -->
      <div class="section">
        <div class="section-header" @click=${()=>this._toggleSection("ignored")}>
          <svg class="arrow ${s.ignored?"closed":"open"}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="6 9 12 15 18 9"/></svg>
          <div class="section-title">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><line x1="4.93" y1="4.93" x2="19.07" y2="19.07"/></svg>
            ${ge("ignoredRepos")}
          </div>
        </div>
        <div class="section-content ${s.ignored?"collapsed":""}">
          ${t.length>0?H`
            <div class="repo-list">
              ${t.map(e=>H`
                <div class="repo-item" style="cursor:default;"><div class="repo-info"><div class="repo-top"><span class="repo-name">${e}</span></div></div></div>
              `)}
            </div>
          `:H`<div class="empty">${ge("noIgnored")}</div>`}
        </div>
      </div>

      <!-- Tools: Export / Import / Dep Check -->
      <div class="section">
        <div class="section-header" @click=${()=>this._toggleSection("tools")}>
          <svg class="arrow ${s.tools?"closed":"open"}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="6 9 12 15 18 9"/></svg>
          <div class="section-title">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><path d="M14.31 8l5.74 5.74-.94 3.71-3.71.94L8 14.31"/><path d="M14.31 8L8 14.31l-2.23.45a1 1 0 0 0-.86 1.16l.6 3.02a1 1 0 0 0 1.16.86l3.02-.6L16 12.69"/></svg>
            ${ge("tools")||"工具"}
          </div>
        </div>
        <div class="section-content ${s.tools?"collapsed":""}">
          <div class="section-desc">${ge("toolsDesc")||"导出、导入和依赖检查"}</div>

          <div style="display:flex;flex-wrap:wrap;gap:8px;margin-bottom:16px;">
            <button class="btn primary" @click=${this._export} ?disabled=${this.exporting}>
              ${this.exporting?ge("exporting"):ge("exportBtn")}
            </button>
            <button class="btn" @click=${this._import} ?disabled=${this.importing}>
              ${this.importing?ge("importing"):ge("importBtn")}
            </button>
            <button class="btn" @click=${this._checkDependencies} ?disabled=${this._depLoading}>
              ${this._depLoading?H`<svg class="mini-icon spin" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 12a9 9 0 1 1-6.219-8.56"/></svg> ${ge("checkingUpdates")}`:H`<svg class="mini-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg> ${ge("checkDep")}`}
            </button>
          </div>

          ${this._depResults?H`
            <div class="dep-panel">
              <div class="dep-summary">
                <span class="title">${this._depResults.all_ok?H`<svg class="mini-icon" viewBox="0 0 24 24" fill="none" stroke="#4caf50" stroke-width="2"><path d="M20 6L9 17l-5-5"/></svg>`:H`<svg class="mini-icon" viewBox="0 0 24 24" fill="none" stroke="#ff9800" stroke-width="2"><path d="M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"/><line x1="12" y1="9" x2="12" y2="13"/><line x1="12" y1="17" x2="12.01" y2="17"/></svg>`} ${ge("totalPrefix")||"共"} ${this._depResults.total_checked} ${ge("totalRepos")}</span>
                ${this._depResults.all_ok?"":H`<span class="issues">${this._depResults.issues_count} ${ge("depMissing")||"缺失"}</span>`}
              </div>
              ${this._depResults.all_ok?H`<div class="dep-ok"><svg class="mini-icon" viewBox="0 0 24 24" fill="none" stroke="#4caf50" stroke-width="2"><path d="M20 6L9 17l-5-5"/></svg> ${ge("depOk")}</div>`:H`
                ${this._depResults.dependencies.filter(e=>e.has_issues).map(e=>H`
                  <div class="dep-item">
                    <div class="repo">${e.repository}</div>
                    <div class="missing">${e.missing.join(", ")}</div>
                  </div>
                `)}
              `}
            </div>
          `:""}
        </div>
      </div>
    `}}customElements.define("management-view",Jt);class Xt extends se{static properties={hass:{type:Object},_settings:{type:Object,state:!0},_saving:{type:Boolean,state:!0},_showIntegrationPicker:{type:Boolean,state:!0},_handlers:{type:Array,state:!0},_handlerSearch:{type:String,state:!0},_handlersLoading:{type:Boolean,state:!0},_version:{type:String,state:!0}};constructor(){super(),this._settings={},this._saving=!1,this._showIntegrationPicker=!1,this._handlers=[],this._handlerSearch="",this._handlersLoading=!1,this._version=""}connectedCallback(){super.connectedCallback(),this._load()}async _load(){try{this._settings=await ce.getSettings()||{}}catch(e){console.error("Settings load failed:",e),this._settings={}}try{const e=await ce.getVersion();this._version=e?.version||""}catch(e){}}async _save(){this._saving=!0;try{await ce.updateSettings(this._settings);const{showToast:e}=await Promise.resolve().then(function(){return Nt});e(ge("settingsSaved"),"success")}catch(e){showToast(`${ge("settingsSaveFailed")}: ${e.message}`,"error")}this._saving=!1}_set(e,t){this._settings={...this._settings,[e]:t}}async _openIntegrationPicker(){if(this._showIntegrationPicker=!0,this._handlerSearch="",0===this._handlers.length){this._handlersLoading=!0;try{const e=await this.hass.callApi("GET","config/config_entries/flow_handlers");this._handlers=Array.isArray(e)?e.map(e=>"string"==typeof e?{domain:e,name:e}:e):[],this._handlers.sort((e,t)=>(e.name||e.domain).localeCompare(t.name||t.domain))}catch(e){console.error("Failed to load flow handlers:",e),this._handlers=[]}this._handlersLoading=!1}}_closeIntegrationPicker(){this._showIntegrationPicker=!1,this._handlerSearch=""}_selectHandler(e){this._showIntegrationPicker=!1,this._handlerSearch="",this.dispatchEvent(new CustomEvent("open-flow",{detail:{domain:e},bubbles:!0,composed:!0}))}get _filteredHandlers(){const e=this._handlerSearch.toLowerCase().trim();return e?this._handlers.filter(t=>(t.name||"").toLowerCase().includes(e)||(t.domain||"").toLowerCase().includes(e)):this._handlers}static styles=a`
    :host { display: block; }
    .settings { padding: 0 4px; }
    .settings-title { font-size: 16px; font-weight: 600; color: var(--primary-text-color); margin-bottom: 4px; }
    .settings-desc { font-size: 13px; color: var(--secondary-text-color); margin-bottom: 20px; }
    .field {
      margin-bottom: 18px; padding: 14px 16px;
      background: var(--card-background-color, #fff);
      border: 1px solid var(--divider-color, #e0e0e0);
      border-radius: 10px;
    }
    .field-label { font-size: 13px; font-weight: 600; color: var(--primary-text-color); margin-bottom: 6px; }
    .field input, .field select {
      width: 100%; padding: 8px 12px; border-radius: 8px;
      border: 1px solid var(--divider-color, #e0e0e0);
      background: var(--secondary-background-color, #f5f5f5);
      color: var(--primary-text-color); font-size: 14px;
      box-sizing: border-box;
    }
    .field select { appearance: auto; }
    .save-btn {
      padding: 10px 24px; border-radius: 10px; font-size: 14px; font-weight: 600;
      background: var(--primary-color, #03a9f4); color: #fff;
      border: none; cursor: pointer; transition: opacity 0.15s;
    }
    .save-btn:hover { opacity: 0.9; }
    .save-btn:disabled { opacity: 0.5; cursor: not-allowed; }
    .version { font-size: 12px; color: var(--secondary-text-color); margin-top: 24px; text-align: center; }
    .actions { display: flex; gap: 8px; flex-wrap: wrap; margin-top: 8px; }
    .action-btn {
      padding: 8px 16px; border-radius: 8px; font-size: 13px; font-weight: 600;
      border: 1px solid var(--divider-color, #e0e0e0);
      background: var(--card-background-color, #fff);
      color: var(--primary-text-color);
      cursor: pointer; display: inline-flex; align-items: center; gap: 4px;
    }
    .action-btn:hover { border-color: var(--primary-color); }
    .action-btn.primary { background: var(--primary-color); color: #fff; border-color: var(--primary-color); }
    .action-btn.primary:hover { opacity: 0.9; }

    /* Integration Picker — match store modal style */
    .picker-overlay {
      position: fixed; top: 0; left: 0; right: 0; bottom: 0;
      background: rgba(0,0,0,0.6); z-index: 9999;
      display: flex; align-items: center; justify-content: center;
      padding: 20px; box-sizing: border-box;
      animation: fadeIn 0.2s ease;
    }
    @keyframes fadeIn { from { opacity: 0; } to { opacity: 1; } }
    .picker-dialog {
      background: var(--card-background-color, #fff);
      color: var(--primary-text-color, #212121);
      border-radius: 16px; box-shadow: 0 20px 60px rgba(0,0,0,0.3);
      width: 90%; max-width: 520px; max-height: 80vh;
      display: flex; flex-direction: column;
      animation: slideUp 0.25s ease;
    }
    @keyframes slideUp { from { transform: translateY(30px); opacity: 0; } to { transform: translateY(0); opacity: 1; } }
    .picker-header {
      display: flex; justify-content: space-between; align-items: center;
      padding: 16px 20px; border-bottom: 1px solid var(--divider-color, #e0e0e0);
    }
    .picker-title { font-size: 16px; font-weight: 700; color: var(--primary-text-color, #212121); }
    .picker-close {
      width: 32px; height: 32px; border: none; border-radius: 50%;
      background: var(--divider-color, #e0e0e0);
      color: var(--secondary-text-color, #727272);
      cursor: pointer; font-size: 18px;
      display: flex; align-items: center; justify-content: center;
      transition: all 0.2s;
    }
    .picker-close:hover { background: var(--primary-color, #03a9f4); color: #fff; }
    .picker-search {
      padding: 12px 20px; border-bottom: 1px solid var(--divider-color, #e0e0e0);
    }
    .picker-search input {
      width: 100%; padding: 10px 12px; border-radius: 10px;
      border: 1px solid var(--divider-color, #e0e0e0);
      background: var(--card-background-color, #fff);
      color: var(--primary-text-color, #212121); font-size: 14px;
      box-sizing: border-box; transition: border-color 0.2s;
    }
    .picker-search input:focus { border-color: var(--primary-color, #03a9f4); outline: none; }
    .picker-count {
      font-size: 12px; color: var(--secondary-text-color); padding: 8px 20px 0;
    }
    .picker-list {
      overflow-y: auto; flex: 1; padding: 8px 12px;
    }
    .picker-item {
      display: flex; align-items: center; gap: 10px;
      padding: 10px 12px; border-radius: 10px; cursor: pointer;
      transition: all 0.2s;
    }
    .picker-item:hover {
      background: rgba(var(--rgb-primary-color, 3,169,244), 0.04);
      border-color: var(--primary-color, #03a9f4);
    }
    .picker-item-domain {
      font-size: 12px; color: var(--secondary-text-color);
      background: rgba(var(--rgb-primary-color, 3,169,244), 0.08);
      color: var(--primary-color, #03a9f4);
      padding: 2px 8px; border-radius: 4px; flex-shrink: 0;
    }
    .picker-item-name { font-size: 14px; font-weight: 500; }
    .picker-empty {
      text-align: center; padding: 32px 0; color: var(--secondary-text-color); font-size: 14px;
    }
    .picker-loading {
      text-align: center; padding: 32px 0; color: var(--secondary-text-color);
    }
    .spinner-sm {
      width: 20px; height: 20px;
      border: 2px solid var(--divider-color, #e0e0e0);
      border-top-color: var(--primary-color, #03a9f4);
      border-radius: 50%; animation: spin 1s linear infinite;
      margin: 0 auto 8px;
    }
    @keyframes spin { from { transform: rotate(0deg); } to { transform: rotate(360deg); } }
  `;render(){return H`
      <div class="settings">
        <div class="settings-title">${ge("settingsTitle")}</div>
        <div class="settings-desc">${ge("settingsDesc")}</div>

        <div class="field">
          <div class="field-label">${ge("settingsRefreshInterval")}</div>
          <input type="number" min="60" max="86400"
            .value=${this._settings.refresh_interval??3600}
            @change=${e=>this._set("refresh_interval",parseInt(e.target.value)||3600)}
          />
        </div>

        <div class="field">
          <div class="field-label">${ge("settingsDefaultView")}</div>
          <select @change=${e=>this._set("default_view",e.target.value)}
            .value=${this._settings.default_view||"browse"}>
            <option value="browse">${ge("tabBrowse")}</option>
            <option value="updates">${ge("tabUpdates")}</option>
            <option value="management">${ge("tabManagement")}</option>
          </select>
        </div>

        <div class="field">
          <div class="field-label">${ge("settingsNotifyUpdates")}</div>
          <select @change=${e=>this._set("notify_updates","true"===e.target.value)}
            .value=${String(this._settings.notify_updates??!0)}>
            <option value="true">${ge("enabled")}</option>
            <option value="false">${ge("disabled")}</option>
          </select>
        </div>

        <div class="field">
          <div class="field-label">${ge("settingsNotifyRestart")}</div>
          <select @change=${e=>this._set("notify_restart","true"===e.target.value)}
            .value=${String(this._settings.notify_restart??!0)}>
            <option value="true">${ge("enabled")}</option>
            <option value="false">${ge("disabled")}</option>
          </select>
        </div>

        <button class="save-btn" @click=${this._save} ?disabled=${this._saving}>
          ${this._saving?ge("loading"):ge("save")}
        </button>

        <div class="actions">
          <button class="action-btn primary" @click=${this._openIntegrationPicker}>
            ${ge("addHAIntegration")}
          </button>
          <button class="action-btn" @click=${this._checkUpdates}>
            ${ge("checkUpdatesNotify")}
          </button>
          <button class="action-btn" @click=${this._checkAndRestart}>
            ${ge("restartHA")}
          </button>
        </div>

        <div class="version">HACS Vision${this._version?` v${this._version}`:""}</div>
      </div>

      ${this._showIntegrationPicker?this._renderPicker():""}
    `}_renderPicker(){const e=this._filteredHandlers;return H`
      <div class="picker-overlay" @click=${e=>{e.target===e.currentTarget&&this._closeIntegrationPicker()}}>
        <div class="picker-dialog">
          <div class="picker-header">
            <span class="picker-title">${ge("addHAIntegration")}</span>
            <button class="picker-close" @click=${this._closeIntegrationPicker}>&times;</button>
          </div>
          <div class="picker-search">
            <input type="text"
              placeholder=${ge("searchIntegration")}
              .value=${this._handlerSearch}
              @input=${e=>{this._handlerSearch=e.target.value}}
              @keydown=${e=>{"Escape"===e.key&&this._closeIntegrationPicker()}}
            />
          </div>
          <div class="picker-count">${e.length} ${ge("integrationCount")}</div>
          <div class="picker-list">
            ${this._handlersLoading?H`
              <div class="picker-loading">
                <div class="spinner-sm"></div>
                <div>${ge("loading")}</div>
              </div>
            `:0===e.length?H`
              <div class="picker-empty">${ge("noIntegrationMatch")}</div>
            `:e.map(e=>H`
              <div class="picker-item" @click=${()=>this._selectHandler(e.domain)}>
                <span class="picker-item-name">${e.name||e.domain}</span>
                ${e.name&&e.name!==e.domain?H`
                  <span class="picker-item-domain">${e.domain}</span>
                `:""}
              </div>
            `)}
          </div>
        </div>
      </div>
    `}async _checkUpdates(){try{const e=await ce.checkUpdatesWithNotify(),{showToast:t}=await Promise.resolve().then(function(){return Nt});e.success&&(e.updates_found>0?t(ge("updatesChecked",{n:e.updates_found}),"success"):t(ge("noUpdatesFound"),"info"),e.notified&&t(ge("notifySent"),"success"))}catch(e){showToast(`Update check failed: ${e.message}`,"error")}}async _checkAndRestart(){const{ConfirmDialog:e}=await Promise.resolve().then(function(){return Pt});if(await e.show(this,{message:ge("restartConfirm"),confirmText:ge("restartHA"),danger:!0}))try{await ce.restartHA();const{showToast:e}=await Promise.resolve().then(function(){return Nt});e(ge("haRestarting"),"info")}catch(e){showToast(`${ge("restartFailed")}: ${e.message}`,"error")}}}customElements.define("config-view",Xt);class Zt extends se{static properties={hass:{type:Object},configEntries:{type:Array},loading:{type:Boolean},searchText:{type:String},_statusFilter:{type:String,state:!0},_showAddDialog:{type:Boolean,state:!0},_handlerSearch:{type:String,state:!0},_handlers:{type:Array,state:!0},_handlersLoading:{type:Boolean,state:!0},_removing:{type:Object,state:!0},_reloading:{type:Object,state:!0},_detailDomain:{type:String,state:!0},_detailEntries:{type:Array,state:!0},_showDetail:{type:Boolean,state:!0},_domainNames:{type:Object,state:!0},_domainIcons:{type:Object,state:!0}};constructor(){super(),this.configEntries=[],this.loading=!0,this.searchText="",this._statusFilter="all",this._showAddDialog=!1,this._handlerSearch="",this._handlers=[],this._handlersLoading=!1,this._removing={},this._reloading={},this._detailDomain="",this._detailEntries=[],this._showDetail=!1,this._domainNames={},this._domainIcons={}}connectedCallback(){super.connectedCallback(),this._load()}async _load(){this.loading=!0;try{const e=await ce.getConfigEntries();this.configEntries=e.entries||[],await this._preloadDomainNames()}catch(e){console.error("Failed to load config entries:",e),Ot(ge("loadFailed"),"error")}this.loading=!1}async _preloadDomainNames(){if(!this.hass?.loadBackendTranslation)return;const e=[...new Set(this.configEntries.map(e=>e.domain))],t=await Promise.all(e.map(async e=>{let t=null,i=null;if(this.hass.localize){const o=this.hass.localize(`component.${e}.title`);o&&o!==`component.${e}.title`&&(t=o);const r=this.hass.localize(`component.${e}.icon`);r&&r!==`component.${e}.icon`&&(i=r)}if(!t||!i)try{if(await this.hass.loadBackendTranslation("config",e),this.hass.localize){if(!t){const i=this.hass.localize(`component.${e}.title`);i&&i!==`component.${e}.title`&&(t=i)}if(!i){const t=this.hass.localize(`component.${e}.icon`);t&&t!==`component.${e}.icon`&&(i=t)}}}catch(e){}return{domain:e,name:t||e,icon:i||null}})),i={},o={};for(const e of t)i[e.domain]=e.name,o[e.domain]=e.icon;this._domainNames=i,this._domainIcons=o}async _loadHandlers(){if(!(this._handlers.length>0)){this._handlersLoading=!0;try{const e=await this.hass.callApi("GET","config/config_entries/flow_handlers");this._handlers=Array.isArray(e)?e.map(e=>"string"==typeof e?{domain:e,name:e}:e):[],this._handlers.sort((e,t)=>(e.name||e.domain).localeCompare(t.name||t.domain))}catch(e){console.error("Failed to load flow handlers:",e),this._handlers=[]}this._handlersLoading=!1}}async _removeEntry(e,t){t.stopPropagation();const{ConfirmDialog:i}=await Promise.resolve().then(function(){return Pt});if(!await i.show(this,{title:e.domain,message:ge("confirmDelete"),confirmText:ge("remove"),danger:!0}))return;this._removing={...this._removing,[e.entry_id]:!0};try{const t=ce._getHeaders(),i=await fetch(`/api/config/config_entries/entry/${e.entry_id}`,{method:"DELETE",headers:t,credentials:"include"});if(!i.ok)throw new Error(`HTTP ${i.status}`);Ot(`${e.domain} ${ge("removed")}`,"success"),this._load()}catch(t){Ot(`${ge("removeFailed")}: ${t.message}`,"error")}const o={...this._removing};delete o[e.entry_id],this._removing=o}async _reloadEntry(e,t){t.stopPropagation(),this._reloading={...this._reloading,[e.entry_id]:!0};try{const t=ce._getHeaders(),i=await fetch(`/api/config/config_entries/entry/${e.entry_id}/reload`,{method:"POST",headers:{...t,"Content-Type":"application/json"},credentials:"include",body:"{}"});if(!i.ok)throw new Error(`HTTP ${i.status}`);Ot(`${e.domain} ${ge("reloaded")}`,"success"),setTimeout(()=>this._load(),1500)}catch(t){Ot(`${ge("reloadFailed")}: ${t.message}`,"error")}const i={...this._reloading};delete i[e.entry_id],this._reloading=i}_configureEntry(e,t){t.stopPropagation(),this._closeDetail(),this.dispatchEvent(new CustomEvent("configure-integration",{bubbles:!0,composed:!0,detail:{domain:e.domain,entry_id:e.entry_id}}))}_openAddDialog(){this._showAddDialog=!0,this._handlerSearch="",this._loadHandlers()}_closeAddDialog(){this._showAddDialog=!1,this._handlerSearch=""}_addIntegration(e){this._closeAddDialog(),this.dispatchEvent(new CustomEvent("add-integration",{bubbles:!0,composed:!0,detail:{domain:e}}))}_openDetail(e,t){this._detailDomain=e,this._detailEntries=t,this._showDetail=!0}_closeDetail(){this._showDetail=!1,this._detailDomain="",this._detailEntries=[]}_translateDomain(e){return this._domainNames?.[e]||e}_renderAvatar(e){const t=this._domainIcons?.[e];if(t)return H`<ha-icon class="domain-icon" icon="${t}"></ha-icon>`;const i=this._getDomainColor(e),o=e.charAt(0).toUpperCase();return H`<div class="avatar" style="background:${i}">${o}</div>`}_getDomainColor(e){const t=["#1565c0","#7b1fa2","#2e7d32","#e65100","#00838f","#6a1b9a","#c62828","#283593"];let i=0;for(let t=0;t<e.length;t++)i=(i<<5)-i+e.charCodeAt(t);return t[Math.abs(i)%t.length]}_getState(e){const t=(e.state||"loaded").toLowerCase();return e.disabled_by?{label:ge("statusDisabled"),cls:"state-disabled",dot:"#9e9e9e"}:t.includes("fail")?{label:ge("badgeLoadFailed"),cls:"state-failed",dot:"#f44336"}:"not_loaded"===t?{label:ge("statusNotInstalled"),cls:"state-not-loaded",dot:"#9e9e9e"}:{label:ge("statusInstalled"),cls:"state-loaded",dot:"#4caf50"}}_groupState(e){const t=e.some(e=>!e.disabled_by&&(e.state||"").toLowerCase().includes("fail")),i=e.some(e=>e.disabled_by);return t?"failed":i?"disabled":"loaded"}_groupLabel(e){return{loaded:ge("statusInstalled"),failed:ge("badgeLoadFailed"),disabled:ge("statusDisabled")}[e]||e}_groupColor(e){return{loaded:"#4caf50",failed:"#f44336",disabled:"#9e9e9e"}[e]||"#999"}get _filteredDomainGroups(){const e=this.searchText.toLowerCase().trim(),t={};for(const i of this.configEntries)e&&!i.domain.toLowerCase().includes(e)||(t[i.domain]||(t[i.domain]=[]),t[i.domain].push(i));let i=Object.entries(t).map(([e,t])=>({domain:e,entries:t,_state:this._groupState(t)}));"all"!==this._statusFilter&&(i=i.filter(e=>e._state===this._statusFilter));const o={failed:0,disabled:1,loaded:2};return i.sort((e,t)=>{const i=o[e._state]??3,r=o[t._state]??3;return i!==r?i-r:e.domain.localeCompare(t.domain)}),i}get _chipCounts(){const e={all:0,loaded:0,failed:0,disabled:0},t={};for(const i of this.configEntries)t[i.domain]||(t[i.domain]=!0,e.all++);const i={};for(const e of this.configEntries)i[e.domain]||(i[e.domain]=[]),i[e.domain].push(e);for(const[t,o]of Object.entries(i)){const t=this._groupState(o);void 0!==e[t]&&e[t]++}return e}get _filteredHandlers(){const e=this._handlerSearch.toLowerCase().trim();return e?this._handlers.filter(t=>(t.name||"").toLowerCase().includes(e)||(t.domain||"").toLowerCase().includes(e)):this._handlers}render(){const e=this._filteredDomainGroups,t=this._chipCounts;return H`
      <div class="integrations">
        <div class="header">
          <div class="header-left">
            <h1 class="page-title">${ge("tabIntegrations")}</h1>
            <span class="count-badge">${t.all}</span>
          </div>
          <div class="header-actions">
            <div class="search-box">
              <input type="text" class="search-input"
                .value=${this.searchText}
                @input=${e=>{this.searchText=e.target.value}}
                placeholder="${ge("searchIntegration")}">
            </div>
            <button class="action-btn icon-btn" @click=${this._load} title="${ge("refresh")}">
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="16" height="16"><path d="M23 4v6h-6M1 20v-6h6"/><path d="M3.51 9a9 9 0 0 1 14.85-3.36L23 10M1 14l4.64 4.36A9 9 0 0 0 20.49 15"/></svg>
            </button>
            <button class="action-btn primary" @click=${this._openAddDialog}>
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="14" height="14"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>
              ${ge("addHAIntegration")}
            </button>
          </div>
        </div>

        <!-- Filter chips -->
        <div class="filter-bar">
          ${["all","loaded","failed","disabled"].map(e=>H`
            <button class="chip ${this._statusFilter===e?"chip-active":""} chip-${e}"
              @click=${()=>{this._statusFilter=e}}>
              <span class="chip-label">${ge("all"===e?"filterAll":"loaded"===e?"filterLoaded":"failed"===e?"filterFailed":"filterDisabled")}</span>
              <span class="chip-count">${t[e]??0}</span>
            </button>
          `)}
        </div>

        ${this.loading?H`
          <div class="loading"><div class="spinner-sm"></div><div class="loading-text">${ge("loading")}</div></div>
        `:0===e.length?H`
          <div class="empty-state">
            <div class="empty-icon">⚙</div>
            <div class="empty-title">${ge("noData")}</div>
          </div>
        `:H`
          <div class="card-grid">
            ${e.map(e=>this._renderCard(e))}
          </div>
        `}
      </div>

      ${this._renderAddDialog()}
      ${this._renderDetailDialog()}
    `}_renderCard(e){const{domain:t,entries:i}=e;this._getDomainColor(t);const o=e._state,r=i.some(e=>this._removing[e.entry_id]||this._reloading[e.entry_id]),a=!r&&i.some(e=>!this._removing[e.entry_id]);return H`
      <div class="card card-${o}" @click=${()=>this._openDetail(t,i)} role="button" tabindex="0"
        @keydown=${e=>{"Enter"!==e.key&&" "!==e.key||(e.preventDefault(),this._openDetail(t,i))}}>
        <!-- Top-left status bar -->
        <div class="card-stripe" style="background:${this._groupColor(o)}"></div>

        <div class="card-img">
          ${this._renderAvatar(t)}
        </div>
        <div class="card-body">
          <div class="card-name" title="${t}">${this._translateDomain(t)}</div>
          <div class="card-meta">${i.length}${ge("entryCount")}</div>
          <div class="card-status" style="color:${this._groupColor(o)}">
            <span class="status-dot" style="background:${this._groupColor(o)}"></span>
            ${this._groupLabel(o)}
          </div>
        </div>
        <div class="card-actions" @click=${e=>e.stopPropagation()}>
          <button class="card-btn reload" @click=${()=>this._quickReloadDomain(t,i)}
            title="${ge("reloadDomain")}" ?disabled=${!a}>
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="13" height="13"><path d="M23 4v6h-6M1 20v-6h6"/><path d="M3.51 9a9 9 0 0 1 14.85-3.36L23 10M1 14l4.64 4.36A9 9 0 0 0 20.49 15"/></svg>
          </button>
          <button class="card-btn" @click=${()=>this._openDetail(t,i)} title="${ge("viewDetail")}">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="14" height="14"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/></svg>
          </button>
        </div>
      </div>
    `}async _quickReloadDomain(e,t){const i=t.filter(e=>!this._removing[e.entry_id]);if(i.length)for(const e of i)await this._reloadEntry(e,{stopPropagation:()=>{}})}_renderDetailDialog(){if(!this._showDetail||!this._detailEntries.length)return"";const e=this._detailDomain;return this._getDomainColor(e),H`
      <div class="modal-overlay" role="dialog" aria-modal="true" aria-label="${this._translateDomain(e)}" @click=${e=>{e.target===e.currentTarget&&this._closeDetail()}}>
        <div class="modal">
          <div class="modal-header">
            <div class="modal-header-left">
              ${this._renderAvatar(e)}
              <div>
                <div class="modal-title">${this._translateDomain(e)}</div>
                <div class="modal-subtitle">${ge("detailEntries",{count:this._detailEntries.length})}</div>
              </div>
            </div>
            <button class="modal-close" aria-label="${ge("close")||"关闭"}" @click=${this._closeDetail}>✕</button>
          </div>
          <div class="modal-body">
            ${this._detailEntries.map(e=>this._renderEntryRow(e))}
          </div>
        </div>
      </div>
    `}_renderEntryRow(e){const t=this._getState(e),i=this._removing[e.entry_id]||this._reloading[e.entry_id],o=e.title||e.entry_id.substring(0,8);return H`
      <div class="entry-row ${e.disabled_by?"disabled":""}">
        <span class="entry-dot" style="background:${t.dot}"></span>
        <div class="entry-info">
          <span class="entry-label">${t.label}</span>
          <span class="entry-id" title="entry_id: ${e.entry_id}">${o}</span>
        </div>
        <div class="entry-actions" @click=${e=>e.stopPropagation()}>
          <button class="entry-btn" @click=${t=>this._configureEntry(e,t)} title="${ge("configureEntry")}" ?disabled=${i}>
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="13" height="13"><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1 0 2.83 2 2 0 0 1-2.83 0l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-2 2 2 2 0 0 1-2-2v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83 0 2 2 0 0 1 0-2.83l.06-.06A1.65 1.65 0 0 0 4.68 15a1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1-2-2 2 2 0 0 1 2-2h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 0-2.83 2 2 0 0 1 2.83 0l.06.06A1.65 1.65 0 0 0 9 4.68a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 2-2 2 2 0 0 1 2 2v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 0 2 2 0 0 1 0 2.83l-.06.06A1.65 1.65 0 0 0 19.4 9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 2 2 2 2 0 0 1-2 2h-.09a1.65 1.65 0 0 0-1.51 1z"/></svg>
          </button>
          <button class="entry-btn reload" @click=${t=>this._reloadEntry(e,t)} title="${ge("reloadEntry")}" ?disabled=${i}>
            ${this._reloading[e.entry_id]?H`<span class="spinning">⋯</span>`:H`
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="13" height="13"><path d="M23 4v6h-6M1 20v-6h6"/><path d="M3.51 9a9 9 0 0 1 14.85-3.36L23 10M1 14l4.64 4.36A9 9 0 0 0 20.49 15"/></svg>
            `}
          </button>
          <button class="entry-btn remove" @click=${t=>this._removeEntry(e,t)} title="${ge("removeEntry")}" ?disabled=${i}>
            ${this._removing[e.entry_id]?H`<span class="spinning">⋯</span>`:H`
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="13" height="13"><polyline points="3 6 5 6 21 6"/><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/></svg>
            `}
          </button>
        </div>
      </div>
    `}_renderAddDialog(){if(!this._showAddDialog)return"";const e=this._filteredHandlers;return H`
      <div class="picker-overlay" role="dialog" aria-modal="true" aria-label="${ge("addIntegration")}" @click=${e=>{e.target===e.currentTarget&&this._closeAddDialog()}}>
        <div class="picker-dialog">
          <div class="picker-header">
            <span class="picker-title">${ge("addHAIntegration")}</span>
            <button class="picker-close" aria-label="${ge("close")||"关闭"}" @click=${this._closeAddDialog}>&times;</button>
          </div>
          <div class="picker-search">
            <input type="text" class="handler-search-input"
              placeholder="${ge("searchIntegration")}"
              .value=${this._handlerSearch}
              @input=${e=>{this._handlerSearch=e.target.value}}
              @keydown=${e=>{"Escape"===e.key&&this._closeAddDialog()}} />
          </div>
          <div class="picker-count">${e.length} ${ge("integrationCount")}</div>
          <div class="picker-list">
            ${this._handlersLoading?H`
              <div class="picker-loading"><div class="spinner-sm"></div><div>${ge("loading")}</div></div>
            `:0===e.length?H`
              <div class="picker-empty">${ge("noIntegrationMatch")}</div>
            `:e.map(e=>H`
              <div class="picker-item" @click=${()=>this._addIntegration(e.domain)}>
                ${this._renderAvatar(e.domain)}
                <span class="picker-item-name">${this._translateDomain(e.domain)}</span>
                ${e.name&&e.name!==e.domain?H`<span class="picker-item-domain">${e.domain}</span>`:""}
              </div>
            `)}
          </div>
        </div>
      </div>
    `}static styles=a`
    :host { display: block; padding: 16px; }

    /* ===== Header ===== */
    .header {
      display: flex; align-items: center; justify-content: space-between;
      gap: 12px; margin-bottom: 12px; flex-wrap: wrap;
    }
    .header-left { display: flex; align-items: center; gap: 10px; }
    .page-title { margin: 0; font-size: 20px; font-weight: 700; color: var(--primary-text-color); }
    .count-badge {
      font-size: 12px; padding: 2px 10px; border-radius: 12px;
      background: var(--primary-color, #03a9f4); color: #fff; font-weight: 600;
    }
    .header-actions { display: flex; align-items: center; gap: 6px; }
    .search-box { position: relative; }
    .search-input {
      padding: 9px 14px; border: 1px solid var(--divider-color, #e0e0e0);
      border-radius: 10px; font-size: 14px;
      background: var(--card-background-color, #fff);
      color: var(--primary-text-color); width: 200px; outline: none;
      box-sizing: border-box; transition: border-color 0.2s;
    }
    .search-input:focus { border-color: var(--primary-color, #03a9f4); }

    .action-btn {
      padding: 9px 18px; border-radius: 10px; font-size: 14px; font-weight: 600;
      border: 1px solid var(--divider-color, #e0e0e0);
      background: var(--card-background-color, #fff);
      color: var(--primary-text-color); cursor: pointer;
      display: inline-flex; align-items: center; gap: 6px;
      transition: all 0.15s; white-space: nowrap;
    }
    .action-btn:hover { border-color: var(--primary-color, #03a9f4); }
    .action-btn.icon-btn { padding: 9px 12px; }
    .action-btn.primary {
      background: var(--primary-color, #03a9f4); color: #fff; border-color: var(--primary-color, #03a9f4);
    }
    .action-btn.primary:hover { opacity: 0.9; }

    /* ===== Filter Chips ===== */
    .filter-bar {
      display: flex; gap: 8px; margin-bottom: 16px;
      flex-wrap: wrap;
    }
    .chip {
      display: inline-flex; align-items: center; gap: 6px;
      padding: 6px 14px; border-radius: 20px; border: 1px solid var(--divider-color, #e0e0e0);
      background: var(--card-background-color, #fff);
      color: var(--secondary-text-color); cursor: pointer;
      font-size: 12px; font-weight: 500;
      transition: all 0.15s;
    }
    .chip:hover { border-color: var(--primary-color, #03a9f4); }
    .chip-active {
      border-color: var(--primary-color, #03a9f4);
      background: rgba(var(--rgb-primary-color, 3,169,244), 0.06);
    }
    .chip-active.chip-loaded { border-color: #4caf50; background: rgba(76,175,80,0.08); }
    .chip-active.chip-failed { border-color: #f44336; background: rgba(244,67,54,0.08); }
    .chip-active.chip-disabled { border-color: #9e9e9e; background: rgba(158,158,158,0.1); }
    .chip-label { color: var(--primary-text-color); }
    .chip-count {
      font-size: 11px; padding: 1px 7px; border-radius: 10px;
      background: var(--divider-color, #e8e8e8); font-weight: 600;
    }

    .loading { text-align: center; padding: 60px 0; }
    .loading-text { font-size: 14px; color: var(--secondary-text-color); margin-top: 8px; }
    .spinner-sm {
      width: 20px; height: 20px; margin: 0 auto;
      border: 2px solid var(--divider-color, #e0e0e0);
      border-top-color: var(--primary-color, #03a9f4);
      border-radius: 50%; animation: spin 1s linear infinite;
    }
    @keyframes spin { from { transform: rotate(0deg); } to { transform: rotate(360deg); } }
    .spinning { animation: spin 1s linear infinite; display: inline-block; }
    .empty-state { text-align: center; padding: 60px 20px; }
    .empty-icon { font-size: 48px; margin-bottom: 12px; }
    .empty-title { font-size: 16px; font-weight: 600; color: var(--primary-text-color); }

    /* ===== Card Grid ===== */
    .card-grid {
      display: grid;
      grid-template-columns: repeat(auto-fill, minmax(200px, 1fr));
      gap: 12px;
    }
    .card {
      background: var(--card-background-color, #fff);
      border: 1px solid var(--divider-color, #e0e0e0);
      border-radius: 14px; overflow: hidden;
      cursor: pointer; position: relative;
      display: flex; flex-direction: column;
      transition: box-shadow 0.2s; touch-action: manipulation;
    }
    .card:hover {
      box-shadow: 0 4px 14px rgba(0,0,0,0.08);
    }
    .card.card-failed { border-color: rgba(244,67,54,0.25); }
    .card.card-disabled { border-color: rgba(158,158,158,0.25); }
    .card:focus-visible {
      box-shadow: 0 0 0 2px rgba(var(--rgb-primary-color, 3,169,244), 0.3);
      outline: none;
    }

    .card-stripe {
      height: 3px; flex-shrink: 0;
    }

    .card-img {
      height: 90px;
      display: flex; align-items: center; justify-content: center;
      background: linear-gradient(135deg, var(--secondary-background-color, #f0f0f0) 0%, var(--card-background-color, #fff) 100%);
    }
    .domain-icon {
      --mdc-icon-size: 46px;
      color: var(--primary-text-color, #212121);
    }
    .avatar {
      width: 46px; height: 46px; border-radius: 50%;
      display: flex; align-items: center; justify-content: center;
      font-size: 18px; font-weight: 700; color: #fff;
      box-shadow: 0 3px 10px rgba(0,0,0,0.13);
    }

    .card-body { padding: 10px 14px 12px; flex: 1; display: flex; flex-direction: column; gap: 3px; }
    .card-name {
      font-size: 14px; font-weight: 600;
      color: var(--primary-text-color, #212121);
      white-space: nowrap; overflow: hidden; text-overflow: ellipsis;
    }
    .card-meta { font-size: 11px; color: var(--secondary-text-color, #727272); }
    .card-status {
      display: flex; align-items: center; gap: 5px;
      font-size: 11px; font-weight: 500; margin-top: 2px;
    }
    .status-dot { width: 7px; height: 7px; border-radius: 50%; flex-shrink: 0; }

    .card-actions {
      position: absolute; top: 8px; right: 8px;
      opacity: 0; transition: opacity 0.15s;
      display: flex; gap: 4px; z-index: 2;
    }
    .card:hover .card-actions, .card:focus-visible .card-actions { opacity: 1; }
    .card-btn {
      width: 28px; height: 28px; padding: 0;
      display: flex; align-items: center; justify-content: center;
      border-radius: 50%; border: none;
      background: rgba(255,255,255,0.92);
      color: var(--secondary-text-color);
      cursor: pointer;
      transition: all 0.15s;
      box-shadow: 0 1px 3px rgba(0,0,0,0.1);
    }
    .card-btn:disabled { opacity: 0.4; cursor: not-allowed; }
    .card-btn:hover { background: #fff; }
    .card-btn.reload:hover { color: #ff9800; }
    .card-btn:hover:not(.reload) { color: var(--primary-color, #03a9f4); }

    /* ===== Detail Modal ===== */
    .modal-overlay {
      position: fixed; inset: 0;
      background: rgba(0,0,0,0.6); z-index: 9999;
      display: grid; place-items: center;
      padding: 20px; box-sizing: border-box;
      animation: fadeIn 0.2s ease;
    }
    @keyframes fadeIn { from { opacity: 0; } to { opacity: 1; } }
    .modal {
      background: var(--card-background-color, #fff);
      color: var(--primary-text-color, #212121);
      border-radius: 16px; box-shadow: 0 20px 60px rgba(0,0,0,0.3);
      width: 90%; max-width: 460px; max-height: 70vh;
      display: flex; flex-direction: column;
      animation: slideUp 0.25s ease;
    }
    @keyframes slideUp { from { transform: translateY(30px); opacity: 0; } to { transform: translateY(0); opacity: 1; } }
    .modal-header {
      display: flex; align-items: center; justify-content: space-between;
      padding: 18px 20px 14px; flex-shrink: 0;
    }
    .modal-header-left { display: flex; align-items: center; gap: 14px; }
    .modal-title { font-size: 16px; font-weight: 600; color: var(--primary-text-color); }
    .modal-subtitle { font-size: 11px; color: var(--secondary-text-color); }
    .modal-close {
      width: 32px; height: 32px; border: none; border-radius: 50%;
      background: var(--divider-color, #e0e0e0);
      color: var(--secondary-text-color); cursor: pointer; font-size: 16px;
      display: flex; align-items: center; justify-content: center;
      transition: all 0.2s;
    }
    .modal-close:hover { background: var(--primary-color, #03a9f4); color: #fff; }
    .modal-body { overflow-y: auto; flex: 1; padding: 0 6px 10px; }

    .entry-row {
      display: flex; align-items: center; gap: 10px;
      padding: 11px 14px; margin: 2px 6px;
      border-radius: 10px; transition: background 0.1s;
    }
    .entry-row:hover { background: var(--secondary-background-color, #f5f5f5); }
    .entry-row.disabled { opacity: 0.45; }

    .entry-dot { width: 8px; height: 8px; border-radius: 50%; flex-shrink: 0; }
    .entry-info { flex: 1; min-width: 0; }
    .entry-label { font-size: 13px; font-weight: 500; color: var(--primary-text-color); }
    .entry-id {
      font-size: 10px; font-family: monospace;
      color: var(--secondary-text-color); display: block; margin-top: 1px;
    }
    .entry-actions {
      display: flex; gap: 2px; flex-shrink: 0;
      opacity: 0; transition: opacity 0.15s;
    }
    .entry-row:hover .entry-actions { opacity: 1; }
    .entry-btn {
      width: 28px; height: 28px; padding: 0;
      display: inline-flex; align-items: center; justify-content: center;
      border: 1px solid transparent; border-radius: 6px;
      background: none; font-size: 13px; cursor: pointer;
      color: var(--secondary-text-color); transition: all 0.15s;
    }
    .entry-btn:disabled { opacity: 0.35; cursor: not-allowed; }
    .entry-btn:hover { background: rgba(33,150,243,0.08); color: #2196f3; }
    .entry-btn.reload:hover { background: rgba(255,152,0,0.08); color: #ff9800; }
    .entry-btn.remove:hover { background: rgba(244,67,54,0.08); color: #f44336; }

    /* ===== Picker Dialog ===== */
    .picker-overlay {
      position: fixed; inset: 0;
      background: rgba(0,0,0,0.6); z-index: 9999;
      display: grid; place-items: center;
      padding: 20px; box-sizing: border-box;
      animation: fadeIn 0.2s ease;
    }
    .picker-dialog {
      background: var(--card-background-color, #fff);
      color: var(--primary-text-color, #212121);
      border-radius: 16px; box-shadow: 0 20px 60px rgba(0,0,0,0.3);
      width: 90%; max-width: 520px; max-height: 80vh;
      display: flex; flex-direction: column;
      animation: slideUp 0.25s ease;
    }
    .picker-header {
      display: flex; justify-content: space-between; align-items: center;
      padding: 16px 20px; border-bottom: 1px solid var(--divider-color, #e0e0e0);
    }
    .picker-title { font-size: 16px; font-weight: 700; color: var(--primary-text-color); }
    .picker-close {
      width: 32px; height: 32px; border: none; border-radius: 50%;
      background: var(--divider-color, #e0e0e0);
      color: var(--secondary-text-color); cursor: pointer; font-size: 18px;
      display: flex; align-items: center; justify-content: center;
      transition: all 0.2s;
    }
    .picker-close:hover { background: var(--primary-color, #03a9f4); color: #fff; }
    .picker-search { padding: 12px 20px; border-bottom: 1px solid var(--divider-color, #e0e0e0); }
    .handler-search-input {
      width: 100%; padding: 10px 12px; border-radius: 10px;
      border: 1px solid var(--divider-color, #e0e0e0);
      background: var(--card-background-color, #fff);
      color: var(--primary-text-color); font-size: 14px;
      box-sizing: border-box; transition: border-color 0.2s;
    }
    .handler-search-input:focus { border-color: var(--primary-color, #03a9f4); outline: none; }
    .picker-count { font-size: 12px; color: var(--secondary-text-color); padding: 8px 20px 0; }
    .picker-list { overflow-y: auto; flex: 1; padding: 8px 12px; }
    .picker-item {
      display: flex; align-items: center; gap: 10px;
      padding: 10px 12px; border-radius: 10px; cursor: pointer;
      transition: all 0.2s;
    }
    .picker-item:hover { background: rgba(var(--rgb-primary-color, 3,169,244), 0.04); }
    .picker-item-domain {
      font-size: 12px; background: rgba(var(--rgb-primary-color, 3,169,244), 0.08);
      color: var(--primary-color, #03a9f4); padding: 2px 8px; border-radius: 4px;
    }
    .picker-item-name { font-size: 14px; font-weight: 500; color: var(--primary-text-color, #212121); }
    .picker-empty, .picker-loading { text-align: center; padding: 32px 0; color: var(--secondary-text-color); }

    @media (max-width: 600px) {
      :host { padding: 12px; }
      .header { flex-direction: column; align-items: flex-start; }
      .header-actions { width: 100%; }
      .search-input { width: 100%; }
      .card-grid { grid-template-columns: repeat(auto-fill, minmax(150px, 1fr)); gap: 10px; }
      .card-img { height: 75px; }
      .domain-icon { --mdc-icon-size: 40px; }
      .avatar { width: 40px; height: 40px; font-size: 16px; }
      .card-actions { opacity: 1; }
      .chip { font-size: 11px; padding: 4px 12px; }
      .modal-overlay { padding: 0; align-items: flex-end; }
      .modal { max-width: 100%; max-height: 75vh; border-radius: 16px 16px 0 0; padding-bottom: max(16px, env(safe-area-inset-bottom, 12px)); }
      .entry-actions { opacity: 1; }
    }
  `}customElements.define("integrations-list",Zt);class Kt extends se{static properties={hass:{type:Object},domain:{type:String},entryId:{type:String},configEntries:{type:Object},open:{type:Boolean,reflect:!0},_loading:{type:Boolean,state:!0},_flowId:{type:String,state:!0},_step:{type:Object,state:!0},_errors:{type:Object,state:!0},_finished:{type:Boolean,state:!0},_result:{type:Object,state:!0},_isOptions:{type:Boolean,state:!0},_isSubentry:{type:Boolean,state:!0},_subentryTypes:{type:Array,state:!0},_subentryType:{type:String,state:!0},_existingSubentries:{type:Array,state:!0},_isSubentryReconfigure:{type:Boolean,state:!0},_subentryReconfigureId:{type:String,state:!0}};constructor(){super(),this.domain="",this.entryId=null,this.configEntries=null,this.open=!1,this._loading=!1,this._flowId=null,this._step=null,this._errors={},this._finished=!1,this._result=null,this._isOptions=!1,this._isSubentry=!1,this._subentryTypes=[],this._subentryType="",this._existingSubentries=[],this._isSubentryReconfigure=!1,this._subentryReconfigureId="",this._loadingTimeout=null,this._translations=null,this._lang="zh-Hans"}_getHass(){if(this.hass)return this.hass;try{const e=window.parent?.document?.querySelector("home-assistant");return e?.hass||null}catch(e){return null}}disconnectedCallback(){super.disconnectedCallback(),this._clearLoadingTimeout()}_clearLoadingTimeout(){this._loadingTimeout&&(clearTimeout(this._loadingTimeout),this._loadingTimeout=null)}_startLoadingTimeout(){this._clearLoadingTimeout(),this._loadingTimeout=setTimeout(()=>{this._loading&&!this._finished&&(this._clearLoadingTimeout(),this._finished=!0,this._result={type:"error",message:ge("flowTimeout")},this._loading=!1,this.requestUpdate())},3e4)}connectedCallback(){super.connectedCallback()}updated(e){if(e.has("open")&&this.open)if(this.entryId){this._isOptions=!1,this._isSubentry=!1,this._subentryTypes=[],this._subentryType="",this._existingSubentries=[],this._isSubentryReconfigure=!1,this._subentryReconfigureId="";const e=this._findEntry(this.entryId);e&&e.supported_subentry_types&&e.supported_subentry_types.length>0?(this._isSubentry=!0,this._subentryTypes=e.supported_subentry_types,this._loadExistingSubentries(),this._startFlow()):(this._isOptions=!0,this._startFlow())}else this.domain&&(this._isOptions=!1,this.entryId=null,this._startFlow())}openFlow(e){this.entryId=null,this._isOptions=!1,this._isSubentry=!1,this._subentryTypes=[],this._subentryType="",this._existingSubentries=[],this._isSubentryReconfigure=!1,this._subentryReconfigureId="",this.domain=e,this.open=!0}openOptionsFlow(e){this.domain="",this._isOptions=!1,this._isSubentry=!1,this._subentryTypes=[],this._subentryType="",this._existingSubentries=[],this._isSubentryReconfigure=!1,this._subentryReconfigureId="",this.entryId=e,this.open=!0}_findEntry(e){if(!this.configEntries||!e)return null;for(const t of Object.values(this.configEntries)){const i=t.find(t=>t.entry_id===e);if(i)return i}return null}async _loadExistingSubentries(){if(this.entryId)try{const e=await ce.getSubentries(this.entryId);this._existingSubentries=e?.subentries||[]}catch{this._existingSubentries=[]}}async _loadTranslations(e){if(!e)return;if(this._translations&&this._translations._domain===e)return;let t={};try{const i=await ce.getTranslations(e,this._lang),o=i?.data||{};t=this._deepMerge(t,o)}catch(e){}try{const i=this._getHass();if(i&&"function"==typeof i.loadBackendTranslation){let o;try{o=await i.loadBackendTranslation("config",e)}catch(t){try{o=await i.loadBackendTranslation(e,"config")}catch(i){console.warn(`HACS Vision: loadBackendTranslation failed for ${e}:`,t?.message||i?.message)}}o&&"object"==typeof o&&"object"==typeof o&&Object.keys(o).length>0&&(o=this._flatToNested(o),t=this._deepMerge(t,o),console.debug(`HACS Vision: loaded HA backend translations for ${e}:`,Object.keys(o).length,"keys"))}else console.warn("HACS Vision: hass.loadBackendTranslation is not available")}catch(t){console.warn(`HACS Vision: loadBackendTranslation error for ${e}:`,t)}if(this._isOptions)try{const i=this._getHass();if(i&&"function"==typeof i.loadBackendTranslation){let o;try{o=await i.loadBackendTranslation("options",e)}catch(t){try{o=await i.loadBackendTranslation(e,"options")}catch(e){}}o&&"object"==typeof o&&Object.keys(o).length>0&&(o=this._flatToNested(o),t=this._deepMerge(t,o))}}catch(e){}this._translations={_domain:e,_data:t}}_deepMerge(e,t){for(const i of Object.keys(t))t[i]&&"object"==typeof t[i]&&!Array.isArray(t[i])?(e[i]&&"object"==typeof e[i]||(e[i]={}),this._deepMerge(e[i],t[i])):e[i]=t[i];return e}_flatToNested(e){if(!e||"object"!=typeof e)return e;const t=Object.keys(e)[0];if(!t||!t.includes("."))return e;const i={};for(const[t,o]of Object.entries(e)){if("string"!=typeof o)continue;const e=t.split(".");let r=i;for(let t=0;t<e.length-1;t++)r[e[t]]&&"object"==typeof r[e[t]]||(r[e[t]]={}),r=r[e[t]];r[e[e.length-1]]=o}return i}_t(e){if(!this._translations?._data)return null;const t="component."+this._translations._domain+".",i=e.startsWith(t)?e.slice(t.length):e;let o=this._traverse(this._translations._data,i);return o||(i.startsWith("config.")&&(o=this._traverse(this._translations._data,"options."+i.slice(7)),o)?o:null)}_traverse(e,t){const i=t.split(".");let o=e;for(const e of i){if(null==o||"object"!=typeof o)return null;o=o[e]}return"string"==typeof o?o:null}async _startFlow(){if(this._isSubentry&&!this._subentryType&&!this._isSubentryReconfigure)return this._loading=!1,this._finished=!1,this._result=null,this._step=null,void this.requestUpdate();this._loading=!0,this._finished=!1,this._result=null,this._step=null,this._errors={},this.requestUpdate(),this._startLoadingTimeout();try{const e=this._isOptions||this._isSubentry?this._getFlowDomain():this.domain;let t;e&&await this._loadTranslations(e),t=this._isSubentryReconfigure&&this._subentryType&&this.entryId?await ce.startSubentryFlow(this.entryId,this._subentryType,{source:"reconfigure",subentry_id:this._subentryReconfigureId}):this._isSubentry&&this._subentryType&&this.entryId?await ce.startSubentryFlow(this.entryId,this._subentryType):this._isOptions&&this.entryId?await ce.startOptionsFlow(this.entryId):await ce.startConfigFlow(this.domain),await this._handleFlowResponse(t)}catch(e){console.error("HACS Vision: config flow start error:",e),this._finished=!0,this._result={type:"error",message:this._getFlowErrorMessage(e)},this._loading=!1,this.requestUpdate()}}async _handleFlowResponse(e){if("abort"===e.type)return this._finished=!0,this._result={type:"abort",reason:e.reason},this._loading=!1,void this.requestUpdate();if("create_entry"===e.type)return this._finished=!0,this._result={type:"create_entry",title:e.title||this.domain||ge("flowDone")},this._loading=!1,void this.requestUpdate();if("form"===e.type){this._flowId=e.flow_id||e.flowId,this._step=e,this._errors=e.errors||{};const t=this._getFlowDomain()||e.handler;return t&&await this._loadTranslations(t),this._loading=!1,void this.requestUpdate()}if("external"===e.type){this._finished=!0;const t=e.url||"";return this._result={type:"external",url:t,message:ge("flowExternalAuth")},this._loading=!1,void this.requestUpdate()}if("menu"===e.type)return this._flowId=e.flow_id||e.flowId,this._step=e,this._errors={},this._loading=!1,void this.requestUpdate();this._finished=!0,this._result={type:"unsupported",message:ge("flowUnknownType",{type:e.type})},this._loading=!1,this.requestUpdate()}async _submitStep(e){this._loading=!0,this._errors={},this.requestUpdate();try{let t;t=this._isSubentry&&this._flowId?await ce.stepSubentryFlow(this._flowId,e):this._isOptions&&this._step?await ce.stepOptionsFlow(this._flowId,e):await ce.stepConfigFlow(this._flowId,e),this._handleFlowResponse(t)}catch(e){console.error("HACS Vision: flow step error:",e),this._errors={base:e.message||ge("flowSubmitFailed")},this._loading=!1,this.requestUpdate()}}_handleSubmit(e){e.preventDefault();const t=e.target,i={};for(const e of t.elements)e.name&&"submit"!==e.type&&"button"!==e.type&&("checkbox"===e.type?i[e.name]=e.checked:"select-multiple"===e.type?i[e.name]=Array.from(e.selectedOptions).map(e=>e.value):void 0!==e.value&&null!==e.value&&(i[e.name]=void 0===e.valueAsNumber||isNaN(e.valueAsNumber)||"number"!==e.type?e.value:e.valueAsNumber));this._submitStep(i)}_handleMenuSelect(e){this._submitStep({next_step_id:e})}_handleSubentrySelect(e){this._subentryType=e,this._isSubentryReconfigure=!1,this._subentryReconfigureId="",this._startFlow()}_handleExistingSubentrySelect(e){this._subentryType=e.subentry_type,this._isSubentryReconfigure=!0,this._subentryReconfigureId=e.subentry_id,this._subentryType=e.subentry_type,this._startFlow()}_cancelFlow(){this._flowId&&(this._isSubentry?ce.cancelSubentryFlow(this._flowId).catch(()=>{}):ce.cancelConfigFlow(this._flowId).catch(()=>{})),this._close()}_close(){this.open=!1,this._flowId=null,this._step=null,this._finished=!1,this._result=null,this._errors={},this._isOptions=!1,this._isSubentry=!1,this._subentryTypes=[],this._subentryType="",this._existingSubentries=[],this._isSubentryReconfigure=!1,this._subentryReconfigureId="",this.domain="",this.entryId=null,this.dispatchEvent(new CustomEvent("close",{bubbles:!0,composed:!0}))}static styles=[me(),a`
    :host { display: block; }
    :host([open]) {
      position: fixed;
      top: 0; left: 0; right: 0; bottom: 0;
      z-index: 9999;
      pointer-events: none;
    }
    .overlay {
      position: fixed; inset: 0;
      background: rgba(0,0,0,0.6);
      z-index: 9999;
      display: grid; place-items: center;
      padding: 20px; box-sizing: border-box;
      animation: fadeIn 0.2s ease;
      pointer-events: auto;
    }
    @keyframes fadeIn { from { opacity: 0; } to { opacity: 1; } }
    .dialog {
      background: var(--card-background-color, #fff);
      color: var(--primary-text-color, #212121);
      border-radius: 16px;
      box-shadow: 0 20px 60px rgba(0,0,0,0.3);
      width: 90%; max-width: 520px;
      max-height: 80vh;
      overflow-y: auto;
      padding: 24px;
      animation: slideUp 0.25s ease;
    }
    @keyframes slideUp { from { transform: translateY(30px); opacity: 0; } to { transform: translateY(0); opacity: 1; } }
    .header {
      display: flex; justify-content: space-between; align-items: center;
      margin-bottom: 16px;
    }
    .title { font-size: 18px; font-weight: 700; color: var(--primary-text-color, #212121); }
    .close-btn {
      width: 32px; height: 32px; border: none; border-radius: 50%;
      background: var(--divider-color, #e0e0e0);
      color: var(--secondary-text-color, #727272);
      cursor: pointer; font-size: 18px;
      display: flex; align-items: center; justify-content: center;
      transition: all 0.2s;
    }
    .close-btn:hover { background: var(--primary-color, #03a9f4); color: #fff; }

    .spinner {
      width: 36px; height: 36px;
      border: 3px solid var(--divider-color, #e0e0e0);
      border-top-color: var(--primary-color, #03a9f4);
      border-radius: 50%;
      animation: spin 1s linear infinite;
      margin: 0 auto 12px;
    }
    .step-desc {
      font-size: 14px; color: var(--secondary-text-color, #727272);
      margin-bottom: 16px;
      white-space: pre-wrap;
      line-height: 1.6;
    }

    /* Form Fields — match store card style */
    .form-field { margin-bottom: 16px; }
    .form-field label {
      display: block; font-size: 13px; font-weight: 600; margin-bottom: 6px;
      color: var(--primary-text-color, #212121);
    }
    .form-field input, .form-field select, .form-field textarea {
      width: 100%; box-sizing: border-box;
      padding: 10px 12px; border: 1px solid var(--divider-color, #e0e0e0);
      border-radius: 10px; font-size: 14px;
      background: var(--card-background-color, #fff);
      color: var(--primary-text-color, #212121);
      font-family: inherit;
      transition: border-color 0.2s;
    }
    .form-field textarea {
      min-height: 80px; resize: vertical;
      line-height: 1.5;
    }
    .form-field input:focus, .form-field select:focus, .form-field textarea:focus {
      border-color: var(--primary-color, #03a9f4); outline: none;
    }
    .form-field select { cursor: pointer; appearance: auto; }
    .field-desc { font-size: 12px; color: var(--secondary-text-color, #727272); margin-bottom: 6px; line-height: 1.5; }
    .checkbox-label {
      display: inline-flex; align-items: center; gap: 10px;
      cursor: pointer; font-size: 14px; font-weight: 400;
      padding: 6px 0;
    }
    .checkbox-label input[type="checkbox"] { width: auto; margin: 0; flex-shrink: 0; }
    .form-error { color: #f44336; font-size: 12px; margin-top: 4px; }

    /* Menu (step type) — match store action-btn style */
    .menu-option {
      display: flex; align-items: center; gap: 10px;
      padding: 12px 16px; border: 1px solid var(--divider-color, #e0e0e0);
      border-radius: 10px; margin-bottom: 8px;
      cursor: pointer; transition: all 0.2s;
      background: var(--card-background-color, #fff);
    }
    .menu-option:hover {
      border-color: var(--primary-color, #03a9f4);
      background: rgba(var(--rgb-primary-color, 3,169,244), 0.04);
    }
    .menu-option .menu-label { font-size: 14px; font-weight: 500; flex: 1; }
    .menu-option .menu-desc { font-size: 12px; color: var(--secondary-text-color); }
    .menu-option .menu-arrow { color: var(--secondary-text-color); font-size: 18px; }
    .menu-label-group { flex: 1; display: flex; flex-direction: column; min-width: 0; }
    .menu-sublabel { font-size: 11px; color: var(--secondary-text-color, #727272); margin-top: 1px; }
    .menu-icon { width: 28px; height: 28px; border-radius: 50%; display: flex; align-items: center; justify-content: center; font-size: 14px; background: rgba(var(--rgb-primary-color, 3,169,244), 0.1); flex-shrink: 0; }
    .subentry-divider { height: 1px; background: var(--divider-color, #e0e0e0); margin: 10px 0; }

    /* Result States */
    .result { text-align: center; padding: 24px 0; }
    .result-icon { width: 48px; height: 48px; margin: 0 auto 12px; }
    .result-icon.success { color: #4caf50; }
    .result-icon.abort { color: #ff9800; }
    .result-icon.error { color: #f44336; }
    .result-icon.external { color: #2196f3; }
    .result-title { font-size: 16px; font-weight: 600; margin-bottom: 8px; }
    .result-desc { font-size: 14px; color: var(--secondary-text-color, #727272); margin-bottom: 16px; }

    .actions { display: flex; gap: 8px; justify-content: flex-end; margin-top: 20px; }
    .btn {
      padding: 8px 20px; border-radius: 10px; border: 1px solid var(--divider-color, #e0e0e0);
      background: var(--card-background-color, #fff);
      color: var(--primary-text-color, #212121);
      cursor: pointer; font-size: 14px; font-family: inherit;
      transition: all 0.2s;
    }
    .btn.primary:hover { opacity: 0.9; color: #fff; }
    .btn.external {
      background: #2196f3; border-color: #2196f3; color: #fff;
      text-decoration: none; display: inline-flex; align-items: center; gap: 6px;
      border-radius: 10px; padding: 8px 20px;
    }

    @media (max-width: 600px) {
      .overlay { padding: 0; align-items: flex-end; }
      .dialog {
        max-width: 100%; max-height: 75vh;
        border-radius: 16px 16px 0 0;
        padding-bottom: max(24px, env(safe-area-inset-bottom, 16px));
      }
    }
  `];render(){if(!this.open)return"";const e=this._isSubentry?(this._getFlowDomain()||"")+" - "+ge("subentryTitle"):this._isOptions?this._getFlowDomain()||ge("flowTitleOptions"):this._step?.title||this._localizeTitle()||this._step?.handler||this.domain||ge("flowTitle");return H`
      <div class="overlay" role="dialog" aria-modal="true" aria-label="${this._flowTitle||ge("flowTitle")}" @click=${e=>{e.target===e.currentTarget&&this._cancelFlow()}}>
        <div class="dialog">
          <div class="header">
            <span class="title">${e}</span>
            <button class="close-btn" aria-label="${ge("close")}" @click=${this._cancelFlow}>&times;</button>
          </div>

          ${this._loading?H`
            <div class="loading">
              <div class="spinner"></div>
              <div>${ge("flowProcessing")}</div>
            </div>
          `:""}

          ${this._finished&&this._result?this._renderResult():""}

          ${this._loading||this._finished||!this._step?"":this._renderStep()}

          ${this._loading||this._finished||this._step||this._result||!this._isSubentry||this._subentryType?"":H`
            <div class="subentry-list">
              ${this._existingSubentries.length>0?H`
                <div class="step-desc" style="margin-bottom:8px">${ge("subentryExisting")}</div>
                ${this._existingSubentries.map(e=>H`
                  <div class="menu-option" @click=${()=>this._handleExistingSubentrySelect(e)}>
                    <span class="menu-icon">⚙</span>
                    <div class="menu-label-group">
                      <span class="menu-label">${e.title||this._getSubentryTypeLabel(e.subentry_type)}</span>
                      <span class="menu-sublabel">${this._getSubentryTypeLabel(e.subentry_type)}</span>
                    </div>
                    <span class="menu-arrow">${ge("subentryReconfigure")}</span>
                  </div>
                `)}
                <div class="subentry-divider"></div>
              `:""}

              <div class="step-desc" style="margin-bottom:8px">${ge("subentryAddNew")}</div>
              ${this._subentryTypes.map(e=>H`
                <div class="menu-option" @click=${()=>this._handleSubentrySelect(e)}>
                  <span class="menu-icon">+</span>
                  <span class="menu-label">${ge("subentryAddPrefix")} ${this._getSubentryTypeLabel(e)}</span>
                  <span class="menu-arrow">→</span>
                </div>
              `)}
              <div class="actions" style="margin-top:16px">
                <button class="btn" @click=${this._cancelFlow}>${ge("flowCancel")}</button>
              </div>
            </div>
          `}

          ${this._loading||this._finished||this._step||this._result||this._isSubentry&&!this._subentryType?"":H`
            <div class="loading">
              <div class="spinner"></div>
              <div>${ge("flowStarting")}</div>
            </div>
          `}
        </div>
      </div>
    `}_renderStep(){const e=this._step;return e?"menu"===e.type?this._renderMenu(e):"form"===e.type?this._renderForm(e):H`<div class="result error"><div class="result-title">${ge("flowResultFailed")}: ${e.type}</div></div>`:""}_renderMenu(e){const t=this._buildDescription(e),i=e.menu_options||[];return H`
      ${t?H`<div class="step-desc">${t}</div>`:""}
      <div class="menu-list">
        ${i.map((t,i)=>{const o="string"==typeof t,r=o?t:t.value||"",a=this._t(`component.${this._getFlowDomain()}.config.step.${e.step_id}.menu_options.${r}`)||this._isOptions&&this._t(`component.${this._getFlowDomain()}.options.step.${e.step_id}.menu_options.${r}`)||(o?t:t.label||t.title||t.value||""),s=o?"":t.description||"";return H`
            <div class="menu-option" @click=${()=>this._handleMenuSelect(r)}>
              <span class="menu-label">${a}</span>
              ${s?H`<span class="menu-desc">${s}</span>`:""}
              <span class="menu-arrow">→</span>
            </div>
          `})}
      </div>
      <div class="actions">
        <button class="btn" @click=${this._cancelFlow}>${ge("flowCancel")}</button>
      </div>
    `}_renderForm(e){const t=this._buildDescription(e),i=e.data_schema||[],o=this._errors?.base||"";return H`
      ${t?H`<div class="step-desc">${t}</div>`:""}
      ${o?H`<div class="form-error" style="margin-bottom:12px">${o}</div>`:""}
      <form @submit=${this._handleSubmit}>
        ${i.map(e=>this._renderField(e))}
        <div class="actions">
          <button type="button" class="btn" @click=${this._cancelFlow}>${ge("flowCancel")}</button>
          <button type="submit" class="btn primary" ?disabled=${this._loading}>
            ${this._loading?ge("flowProcessing"):e.last_step?ge("flowStepFinish"):ge("flowStepNext")}
          </button>
        </div>
      </form>
    `}_buildDescription(e){let t=e.description||e.description_placeholders?.description||"";if(t&&t.includes(".")){const e=this._t(t)||null;e&&(t=e)}if(!t){const e=this._translateField("description");e&&(t=e)}const i=e.description_placeholders||{};for(const[e,o]of Object.entries(i)){const i=null!=o&&"object"!=typeof o?String(o):"";t=t.replace(new RegExp(`\\{${e}\\}`,"g"),i)}if(!t&&Object.keys(i).length>0){const e=Object.entries(i).map(([,e])=>null!=e&&"object"!=typeof e?String(e):"").filter(Boolean);t=e.join("\n")}return t}_getFlowDomain(){if(this.domain)return this.domain;if(this.entryId&&this.configEntries)for(const e of Object.values(this.configEntries))for(const t of e)if(t.entry_id===this.entryId)return t.domain||"";const e=this._step?.handler;return e&&!/^[0-9A-Z]{20,}$/.test(e)?e:""}_getSubentryTypeLabel(e){const t={conversation:"subentryConversation",tts:"subentryTts",stt:"subentryStt",translation:"subentryTranslation",ai_task_data:"subentryAiTaskData",device:"subentryDevice",wecom:"subentryWecom",wechat:"subentryWechat",qq:"subentryQq",feishu:"subentryFeishu",dingtalk:"subentryDingtalk",xiaoyi:"subentryXiaoyi",custom:"subentryCustom"}[e];return t?ge(t):e}_localizeTitle(){const e=this._getFlowDomain(),t=this._step?.step_id;if(e&&t){const e=this._translateField("title");if(e)return e}if(e){const t=`component.${e}.title`,i=this._t(t);if(i)return i}return""}_translateField(e){const t=this._getFlowDomain(),i=this._step?.step_id;if(!t||!i)return null;if(this._isSubentry&&this._subentryType){const o=`component.${t}.config_subentries.${this._subentryType}.step.${i}.${e}`,r=this._t(o);if(r)return r}const o=`component.${t}.config.step.${i}.${e}`;return this._t(o)}_getFieldLabel(e){const t=this._translateField(`data.${e.name}`);return t||(e.label||this._friendlyName(e.name))}_friendlyName(e){return e.replace(/_/g," ").replace(/(^|\s)\w/g,e=>e.toUpperCase()).replace(/Id\b/gi,"ID").replace(/Ip\b/gi,"IP").replace(/Url\b/gi,"URL").replace(/Api\b/gi,"API")}_getFieldDescription(e){const t=this._translateField(`data.${e.name}.description`);if(t)return t;const i=e.description;return"string"==typeof i?i:""}_getFieldPlaceholder(e){const t=this._translateField(`data.${e.name}.placeholder`);return t||(e.placeholder||"")}_getOptionLabel(e,t){const i=this._translateField(`data.${e.name}.options.${t}`);return i||null}_getFlowErrorMessage(e){const t=e?.message||"";return t.includes("404")?this._isSubentry?this._getSubentryTypeLabel(this._subentryType)+" "+ge("flowHandlerNotFound"):this._isOptions?ge("flowOptionsNotSupported"):ge("flowHandlerNotFound"):t.includes("401")||t.includes("403")?ge("flowAuthError"):t||(this._isOptions?ge("flowStartFailedOptions"):ge("flowStartFailed"))}_renderField(e){const t=e.name,i=this._getFieldLabel(e),o=e.type||"string",r=!1!==e.required,a=e.description?.suggested_value,s=void 0!==e.default&&null!==e.default||null!=a,n=void 0!==e.default&&null!==e.default?e.default:void 0!==a?a:"",l=this._getFieldPlaceholder(e),c=this._getFieldDescription(e),d=this._errors?.[t]||"",p=!0===e.multiline,h=!0===e.password||"password"===e.type||/token|secret|password|key|api_key|apiKey/i.test(t)&&"string"===o,g=e.selector||{},u=Object.keys(g)[0];if("select"===o||"multi_select"===o||e.options||e.enum||"select"===u){let a=e.options||e.enum||[];!a.length&&g.select?.options&&(a=g.select.options);const l="multi_select"===o||!0===g.select?.multiple;a.length?console.debug(`HACS Vision: select field "${t}" options:`,JSON.stringify(a).slice(0,200)):console.warn(`HACS Vision: select field "${t}" has empty options`,e);let p=[];return Array.isArray(a)?p=a:a&&"object"==typeof a&&(p=Object.entries(a).map(([e,t])=>({value:e,label:t}))),p=p.filter(Boolean).map(e=>{if("string"==typeof e)return{value:e,label:e};if(Array.isArray(e))return{value:e[0],label:e[1]||e[0]};if(e&&"object"==typeof e){const t=e.value??e.val??e.id??Object.values(e)[0]??"",i=e.label??e.name??e.description??Object.values(e)[1]??t;return{value:String(t),label:String(i)}}return{value:String(e),label:String(e)}}),H`
        <div class="form-field">
          <label>${i}${r?" *":""}</label>
          ${c?H`<div class="field-desc">${c}</div>`:""}
          <select name=${t} ?multiple=${l} ?required=${r}>
            ${r||l?"":H`<option value="">${ge("flowSelectOption")}</option>`}
            ${p.map(t=>{const i=this._getOptionLabel(e,t.value)||t.label,o=s&&(Array.isArray(n)?n.includes(t.value):n===t.value);return H`<option value=${t.value} ?selected=${o}>${i}</option>`})}
          </select>
          ${d?H`<div class="form-error">${d}</div>`:""}
        </div>
      `}if("boolean"===o||"boolean"===u)return"back"!==t||r?H`
        <div class="form-field">
          <label class="checkbox-label">
            <input type="checkbox" name=${t} ?checked=${!0===n||"true"===n}>
            <span>${i!==e.name.replace(/_/g," ")?i:c||i}</span>
          </label>
          ${d?H`<div class="form-error">${d}</div>`:""}
        </div>
      `:H`
          <div class="form-field">
            <button type="button" class="btn" @click=${this._cancelFlow}>${ge("flowBack")}</button>
          </div>
        `;if("integer"===o||"number"===o||"number"===u||"integer"===u){const e=g.number?.step||("integer"===o?1:"any"),a=g.number?.min,s=g.number?.max;return H`
        <div class="form-field">
          <label>${i}${r?" *":""}</label>
          ${c?H`<div class="field-desc">${c}</div>`:""}
          <input type="number" name=${t} .value=${n}
                 ?required=${r} placeholder=${l}
                 step=${e} min=${a??""} max=${s??""}>
          ${d?H`<div class="form-error">${d}</div>`:""}
        </div>
      `}return p||"text"===u&&g.text?.multiline?H`
        <div class="form-field">
          <label>${i}${r?" *":""}</label>
          ${c?H`<div class="field-desc">${c}</div>`:""}
          <textarea name=${t} .value=${n}
                    ?required=${r} placeholder=${l}></textarea>
          ${d?H`<div class="form-error">${d}</div>`:""}
        </div>
      `:H`
      <div class="form-field">
        <label>${i}${r?" *":""}</label>
        ${c&&c!==l?H`<div class="field-desc">${c}</div>`:""}
        <input type=${h?"password":"text"} name=${t}
               .value=${n} ?required=${r} placeholder=${l}>
        ${d?H`<div class="form-error">${d}</div>`:""}
      </div>
    `}_renderResult(){if(!this._result)return"";const e=this._result;if("create_entry"===e.type)return H`
        <div class="result">
          <svg class="result-icon success" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"/>
            <polyline points="22 4 12 14.01 9 11.01"/>
          </svg>
          <div class="result-title">${ge("flowResultCreated")}</div>
          <div class="result-desc">${e.title||ge("flowResultCreatedDesc")}</div>
          <div class="actions">
            <button class="btn primary" @click=${this._close}>${ge("flowDone")}</button>
          </div>
        </div>
      `;if("abort"===e.type){const t={already_configured:ge("flowAbortAlreadyConfigured"),single_instance_allowed:ge("flowAbortSingleInstance"),no_devices_found:ge("flowAbortNoDevices"),already_in_progress:ge("flowAbortInProgress")};return H`
        <div class="result">
          <svg class="result-icon abort" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <circle cx="12" cy="12" r="10"/>
            <line x1="12" y1="8" x2="12" y2="12"/>
            <line x1="12" y1="16" x2="12.01" y2="16"/>
          </svg>
          <div class="result-title">${ge("flowResultAborted")}</div>
          <div class="result-desc">${t[e.reason]||e.reason||ge("flowResultAbortedDesc")}</div>
          <div class="actions">
            <button class="btn primary" @click=${this._close}>${ge("flowGotIt")}</button>
          </div>
        </div>
      `}return"external"===e.type?H`
        <div class="result">
          <svg class="result-icon external" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"/>
            <polyline points="15 3 21 3 21 9"/>
            <line x1="10" y1="14" x2="21" y2="3"/>
          </svg>
          <div class="result-title">${ge("flowResultExternal")}</div>
          <div class="result-desc">${e.message||ge("flowResultExternalDesc")}</div>
          ${e.url?H`<a href=${e.url} target="_blank" class="btn external">${ge("flowOpenAuthPage")}</a>`:""}
          <div class="actions">
            <button class="btn primary" @click=${this._close}>${ge("flowClose")}</button>
          </div>
        </div>
      `:H`
      <div class="result">
        <svg class="result-icon error" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
          <circle cx="12" cy="12" r="10"/><line x1="15" y1="9" x2="9" y2="15"/>
          <line x1="9" y1="9" x2="15" y2="15"/>
        </svg>
        <div class="result-title">${ge("flowResultFailed")}</div>
        <div class="result-desc">${e.message||ge("flowResultFailedDesc")}</div>
        <div class="actions">
          <button class="btn primary" @click=${this._close}>${ge("flowClose")}</button>
        </div>
      </div>
    `}}customElements.define("config-flow-dialog",Kt),customElements.define("hacs-vision-panel",Et)}();
